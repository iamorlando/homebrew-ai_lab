"""Safe, bounded diagnostics for a single model startup attempt."""
import os
from pathlib import Path
import re
import stat


MAX_LOG_BYTES = 16 * 1024
_MEMORY_FAILURE = re.compile(
    r'out[ -]of[ -]memory|not enough (?:available |device |system |gpu )?memory|'
    r'insufficient (?:available |device |system |gpu )?memory|'
    r'cannot allocate memory|memory allocation (?:of .{0,80} )?failed|'
    r'(?:failed|unable) to allocate (?:.{0,80} )?(?:memory|buffer)|'
    r'(?:metal|mps|cuda).{0,80}(?:allocation failed|allocation failure)|'
    r'exceeds? (?:the )?(?:maximum|available|recommended).{0,40}memory|'
    r'model does not fit on (?:this system|the devices)|'
    r'primary device .{0,60}cannot fit its fixed model components|'
    r'MTLCommandBufferErrorOutOfMemory', re.IGNORECASE)


class ModelStartupError(ValueError):
    """A safe runtime startup message that service layers must preserve."""


def log_position(root, log_name):
    """Record the append position before spawning; older failures are irrelevant."""
    try:
        return (Path(root) / '.state' / log_name).stat().st_size
    except OSError:
        return 0


def _attempt_tail(root, log_name, offset):
    path = Path(root) / '.state' / log_name
    try:
        # Never follow a replacement symlink or publish arbitrary log content.
        fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as stream:
            if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                return ''
            size = stream.seek(0, os.SEEK_END)
            start = min(max(0, offset), size)
            stream.seek(max(start, size - MAX_LOG_BYTES))
            return stream.read(MAX_LOG_BYTES).decode('utf-8', errors='replace')
    except (OSError, ValueError):
        return ''


def startup_failure(root, *, label, family, log_name, log_offset=0,
                    returncode=None, timed_out=False):
    """Classify log evidence without returning prompts, keys or native log text."""
    if _MEMORY_FAILURE.search(_attempt_tail(root, log_name, log_offset)):
        message = f'{label} could not start because the runtime reported insufficient memory. '
        if family == 'contrastive' and os.environ.get('AI_LAB_CLM_ISQ', '').strip().lower() != 'q4k':
            message += ('To try the CLM encoder in 4-bit mode, stop this AI Lab launcher and run '
                        '`AI_LAB_CLM_ISQ=q4k ai-lab web`, then retry the decision. '
                        'Keep the same --root and other launcher options. '
                        'For MCP, set AI_LAB_CLM_ISQ=q4k in the MCP server environment and restart it. ')
        message += ('Close other model servers or memory-heavy applications and retry, or use a machine '
                    'with more available memory. Existing downloaded weights are unchanged; no download is needed. ')
    elif timed_out:
        message = f'{label} took too long to load. Retry after checking runtime readiness. '
    else:
        status = f' (exit status {returncode})' if returncode is not None else ''
        message = f'{label} exited before it became ready{status}. '
        if returncode in {-9, 137}:
            message += 'The process was killed; memory pressure is possible but was not confirmed by its log. '
        message += 'Check the runtime log before retrying. '
    return message + f'Log: .state/{log_name}.'
