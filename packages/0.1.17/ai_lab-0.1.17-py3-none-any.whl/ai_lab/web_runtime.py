"""Persistent local APIs shared by all supported website operations."""
import asyncio
from contextlib import asynccontextmanager
import os

from ai_lab.service_manager import NativeServices, ServiceError


class WebLifecycle:
    @property
    def LOCAL_APIS(self):
        from harness.generation_models import GENERATION_BACKENDS, UNDERLYING_MODELS
        return tuple(backend.family for backend in GENERATION_BACKENDS
                     if backend.underlying_model in UNDERLYING_MODELS) + ('contrastive',)

    def __init__(self, root, *, services=None, allow_start=True):
        # Setup is explicit: even a missing runtime must not trigger a download
        # merely because somebody opened the website or selected a model.
        self.services = services or NativeServices(root, repair_runtime=False)
        self.lock = asyncio.Lock()
        self.allow_start = allow_start

    async def _inventory(self):
        # Only a confirmed exited child may be forgotten. Preserve any newer
        # owner's receipt and never signal APIs merely to change UI selection.
        async with self.services.lock:
            for name, identity in list(self.services.created.items()):
                self.services._retire_exited(name, identity)
        return await self.services.snapshot()

    @staticmethod
    def _check(inventory, name):
        row = next(row for row in inventory['services'] if row['name'] == name)
        if row['status'] not in {'running', 'stopped'}:
            family = 'clm' if name == 'contrastive' else name
            if row['ownership'] == 'none':
                raise ValueError(f'{row["label"]} needs setup. Run ai-lab setup install {family} --yes '
                                 '(verified existing weights are reused), then retry.')
            raise ValueError(f'{row["label"]} API is unavailable or its launch settings changed. '
                             'Close its original launcher and retry; the website leaves that process untouched.')
        return row

    async def start(self):
        """Opening the website never loads a model; execution starts its selection.

        Setup and hosted decisions stay available when any local model is absent
        or cannot fit in memory. Existing APIs remain owned by their launcher.
        """

    async def _ensure(self, name):
        row = self._check(await self._inventory(), name)
        if row['status'] != 'running':
            await self.services.perform('start', name)

    @asynccontextmanager
    async def operation(self, name):
        if name not in {*self.LOCAL_APIS, 'jev'}:
            raise ValueError('Choose a supported conversational model, native CLM or Jev.')
        async with self.lock:
            if name != 'jev':
                if not self.allow_start:
                    raise ValueError('This fixture website requires an explicitly injected runtime or HTTP fixture for this API.')
                await self._ensure(name)
            yield

    async def close(self):
        async with self.lock:
            await self.services.close()


class WebGenerationRuntime:
    """WatermarkRuntime's interface with shared ownership around the whole call.

    The delegate is read-only with respect to lifecycle; the website controller
    owns startup and shutdown, including cancellation and backend switching.
    """
    allow_start = False
    web_managed = True

    def __init__(self, lifecycle, runtime=None):
        self.lifecycle = lifecycle
        if runtime is None:
            from watermark_runtime import WatermarkRuntime
            runtime = WatermarkRuntime(allow_start=False)
        self.runtime = runtime

    async def _call(self, method, route_model, *args, **kwargs):
        from harness.generation_models import supported_generation_backend
        family = supported_generation_backend(route_model).family
        if family in getattr(self.runtime, 'fixture_endpoints', {}):
            # An explicit fixture is never a grant to load a native model. The
            # delegate checks its fixture identity and performs only local HTTP.
            async with self.lifecycle.lock:
                return await getattr(self.runtime, method)(*args, **kwargs)
        async with self.lifecycle.operation(family):
            return await getattr(self.runtime, method)(*args, **kwargs)

    async def ensure_server(self, model=None):
        return await self._call('ensure_server', model, model)

    async def complete_next(self, prompt, watermark=None, **kwargs):
        return await self._call('complete_next', kwargs.get('model'), prompt, watermark, **kwargs)

    async def generate(self, profile, watermark, prompt, **kwargs):
        return await self._call('generate', profile, profile, watermark, prompt, **kwargs)

    async def detect(self, text, candidates, **kwargs):
        return await self._call('detect', kwargs.get('model'), text, candidates, **kwargs)

    async def inspect_response(self, prompt, prefix, watermark, **kwargs):
        return await self._call('inspect_response', kwargs.get('model'), prompt, prefix, watermark, **kwargs)


class WebDecisionRuntime:
    def __init__(self, root, lifecycle):
        from decisions import DecisionRuntime
        self.lifecycle = lifecycle
        self.runtime = DecisionRuntime(root, allow_start=False)

    def __getattr__(self, name):
        return getattr(self.runtime, name)

    async def decide(self, body):
        from fastapi import HTTPException
        try:
            if not self.lifecycle.allow_start and 'AI_LAB_DECISIONS_URL' in os.environ:
                # A fixture app may call its explicit decision HTTP endpoint;
                # the delegate refuses startup if that endpoint is unavailable.
                async with self.lifecycle.lock:
                    return await self.runtime.decide(body)
            async with self.lifecycle.operation(body.get('model', 'jev')):
                return await self.runtime.decide(body)
        except (ValueError, ServiceError) as error:
            raise HTTPException(503, str(error)) from error

    async def close(self):
        # The delegate never creates children; the common lifespan owns cleanup.
        await self.runtime.close()
