import {percent, number, piece, explanation} from './watermark-trace-data.mjs';
import {distributionBar} from './distribution-bars.js';
import {textgrainRows, transportCell} from './textgrain-data.mjs';

const el = (tag, text = '', cls = '') => { const node = document.createElement(tag); node.textContent = text; node.className = cls; return node; };
const heading = (title, help) => { const section = el('section'); section.append(el('h3', title), el('p', help, 'field-help')); return section; };
function metrics(values) {
  const list = el('dl', '', 'tg-metrics');
  for (const [label, value] of values) { const row = el('div'); row.append(el('dt', label), el('dd', value)); list.append(row); }
  return list;
}
function table(headers, rows) {
  const node = el('table'), head = el('thead'), tr = el('tr'), body = el('tbody');
  for (const label of headers) tr.append(el('th', label));
  head.append(tr);
  for (const values of rows) { const row = el('tr'); for (const value of values) row.append(el('td', value)); body.append(row); }
  node.append(head, body); const wrap = el('div', '', 'trace-table-wrap'); wrap.append(node); return wrap;
}
function transportView(trace) {
  const section = heading('02 / Transport coupling', 'Rows are vocabulary blocks; columns are keyed alternatives. The highlighted column supplies this step’s conditional block probabilities.');
  if (!trace.transport) {
    section.append(el('p', 'Full transport table was not captured. Block probabilities and solver diagnostics remain available; the solve itself is unchanged.', 'trace-notice'));
    return section;
  }
  const transport = trace.transport, label = el('label', 'Heatmap values'), select = el('select');
  select.id = 'textgrain-matrix-mode'; label.htmlFor = select.id;
  for (const [value, name] of [['coupling', 'Coupling probability'], ['cost', 'Cost · negative standardized Gumbel']]) {
    const option = el('option', name); option.value = value; select.append(option);
  }
  const controls = el('div', '', 'tg-controls'); controls.append(label, select);
  const scroll = el('div', '', 'tg-matrix-scroll'), matrix = el('table', '', 'tg-matrix');
  const caption = el('caption', `${transport.block_count} blocks × ${transport.column_count} columns · column ${trace.selected_column + 1} selected`);
  matrix.append(caption);
  const head = el('thead'), header = el('tr'); header.append(el('th', 'Block'));
  for (let col = 0; col < transport.column_count; col++) {
    const th = el('th', String(col + 1), col === trace.selected_column ? 'selected-column' : ''); th.scope = 'col'; header.append(th);
  }
  head.append(header); matrix.append(head);
  const body = el('tbody'), cells = [];
  for (let block = 0; block < transport.block_count; block++) {
    const row = el('tr'), th = el('th', String(block + 1)); th.scope = 'row'; row.append(th);
    for (let col = 0; col < transport.column_count; col++) {
      const data = transportCell(trace, block, col), td = el('td', '', data.selected ? 'selected-column' : '');
      td.title = `Block ${block + 1}, column ${col + 1}${data.selected ? ' (selected)' : ''}: coupling ${percent(data.coupling)}, cost ${number(data.cost)}`;
      td.setAttribute('aria-label', td.title);
      td.append(el('span', td.title, 'tg-sr-only')); cells.push({td, ...data}); row.append(td);
    }
    body.append(row);
  }
  matrix.append(body); scroll.append(matrix);
  const legend = el('p', '', 'field-help');
  const paint = () => {
    const cost = select.value === 'cost', values = cells.map(c => cost ? c.cost : c.coupling);
    const low = Math.min(...values), high = Math.max(...values);
    for (const [index, cell] of cells.entries()) {
      const fraction = high === low ? .5 : (values[index] - low) / (high - low);
      cell.td.style.backgroundColor = `hsl(191 48% ${13 + (cost ? 1 - fraction : fraction) * 54}%)`;
    }
    legend.textContent = cost ? `Brighter = lower cost. Range ${number(low)} to ${number(high)}. Costs are not probabilities.` : `Brighter = more joint probability. Range ${percent(low)} to ${percent(high)}. Each column sums to ${percent(1 / transport.column_count)}.`;
  };
  select.onchange = paint; paint();
  const exact = el('details', '', 'trace-values'); exact.append(el('summary', 'Transport numeric values'));
  exact.addEventListener('toggle', () => {
    if (!exact.open || exact.childElementCount > 1) return;
    const rows = [];
    for (let b = 0; b < transport.block_count; b++) for (let c = 0; c < transport.column_count; c++) {
      const cell = transportCell(trace, b, c); rows.push([b + 1, `${c + 1}${cell.selected ? ' · selected' : ''}`, number(cell.cost), percent(cell.coupling)]);
    }
    exact.append(table(['Block', 'Column', 'Cost', 'Joint probability'], rows));
  });
  section.append(controls, scroll, legend, exact); return section;
}
function entropyView(trace) {
  const solver = trace.solver;
  const section = heading('Entropy calibration', 'The loss is averaged across keyed columns, not the entropy loss of this single selected column.');
  const bars = el('div', '', 'tg-budget');
  for (const [label, value] of [['Requested', solver.requested_fraction], ['Capped target', solver.target_fraction], ['Achieved', solver.achieved_fraction]]) {
    const row = el('div'); row.append(el('span', label), distributionBar(value, 'after')); bars.append(row);
  }
  section.append(bars, metrics([
    ['Solver', solver.status.replaceAll('_', ' ')], ['Iterations', String(solver.iterations)],
    ['Budget satisfied', solver.budget_satisfied ? 'Yes' : 'No'], ['Entropy loss', `${number(solver.entropy_loss)} nats`],
    ['Token entropy', `${number(solver.token_entropy)} nats`], ['Block entropy', `${number(solver.block_entropy)} nats`],
    ['Regularization λ', number(solver.regularization)], ['Row / column residual', `${number(solver.row_residual)} / ${number(solver.column_residual)}`],
  ]));
  if (solver.status === 'iteration_limit' || !solver.budget_satisfied) section.append(el('p', 'The solver did not certify the requested budget. These are its recorded achieved values, not a guarantee from the settings.', 'trace-notice'));
  const progress = el('details', '', 'trace-values');
  progress.append(el('summary', `Solver progress · ${trace.iterations.length} captured / ${trace.omitted_iterations} omitted`));
  if (trace.iterations.length) progress.append(table(['Iteration', 'λ', 'Achieved fraction', 'Row residual', 'Column residual'], trace.iterations.map(i => [i.iteration, number(i.regularization), percent(i.achieved_fraction), number(i.row_residual), number(i.column_residual)])));
  else progress.append(el('p', 'No iteration history was captured.', 'field-help'));
  section.append(progress); return section;
}
function drawView(trace, step) {
  const section = heading('03 / Token selection', trace.status === 'applied' ? 'Within a block, tokens retain their original relative probabilities.' : 'Watermarking was skipped; sampling uses the original distribution.');
  const generation = trace.generation;
  if (!generation) {
    section.append(el('p', trace.status !== 'applied' ? 'The host used ordinary categorical sampling. No transport or block assignment was applied.' : 'Probability-update policy: the host sampled the emitted token from the transformed distribution. Separate block/token draws were not recorded.', 'field-help'));
    return section;
  }
  section.append(el('p', `${generation.selected_block == null ? 'Ordinary categorical draw' : `Block ${generation.selected_block + 1} → token #${generation.selected_token_id}`} · actual production selection · ${generation.rng_draws} RNG draw${generation.rng_draws === 1 ? '' : 's'}`, 'tg-selection'));
  for (const [name, draw] of [['Block draw', generation.block_draw], ['Token draw', generation.token_draw]]) {
    if (!draw) continue;
    const track = el('div', '', 'tg-draw-track'), interval = el('span', '', 'tg-draw-interval'), marker = el('span', '', 'tg-draw-marker');
    interval.style.left = `${draw.cdf_lower * 100}%`; interval.style.width = `${(draw.cdf_upper - draw.cdf_lower) * 100}%`;
    marker.style.left = `${draw.uniform * 100}%`; track.append(interval, marker);
    track.setAttribute('aria-label', `${name}: uniform ${draw.uniform}, interval [${draw.cdf_lower}, ${draw.cdf_upper})`);
    section.append(el('h4', name), track, el('p', `u = ${number(draw.uniform)} ∈ [${number(draw.cdf_lower)}, ${number(draw.cdf_upper)})`, 'field-help'));
  }
  const provenance = el('details', '', 'trace-values'); provenance.append(el('summary', 'Sampling provenance'));
  provenance.append(metrics([['Sampling version', generation.sampling_version], ['RNG version', generation.rng_version], ['RNG provenance', generation.rng_provenance], ['Seed', generation.effective_seed ?? 'Shared host stream']]));
  section.append(provenance); return section;
}
export function textgrainView(step, chosen, choose) {
  const root = el('div', '', 'textgrain-view'), trace = step.textgrain;
  root.append(el('h3', 'TextGrain / entropy-calibrated transport'));
  if (!trace) {
    root.append(el('p', step.watermark.status === 'greedy' ? explanation(step) : 'Native TextGrain trace unavailable. Inspect again with a TextGrain-capable runtime.', 'trace-notice'));
    return root;
  }
  if (trace.status !== 'applied') {
    root.append(el('p', explanation(step), 'trace-notice'), drawView(trace, step)); return root;
  }
  const rows = textgrainRows(step);
  const blocks = heading('01 / Vocabulary blocks', `Column ${trace.selected_column + 1} selected by the key and context. Bars use all vocabulary tokens: before → conditional on this column. Token lists show only ${rows.length} captured alternatives of ${step.candidate_count.toLocaleString()} tokens.`);
  const list = el('div', '', 'tg-blocks');
  trace.block_masses.forEach((mass, block) => {
    const card = el('div', '', 'tg-block'), title = el('h4', `Block ${block + 1}${trace.generation?.selected_block === block ? ' · drawn' : ''}`);
    card.append(title, distributionBar(mass, 'before'), distributionBar(trace.conditional_block_probabilities[block], 'after'));
    const tokens = el('div', '', 'tg-tokens');
    for (const row of rows.filter(row => row.block === block)) {
      const button = el('button', piece(row), row.token_id === chosen.token_id ? 'active' : ''); button.type = 'button';
      button.setAttribute('aria-label', `Inspect ${piece(row)}, token ${row.token_id}, block ${block + 1}`);
      button.setAttribute('aria-pressed', String(row.token_id === chosen.token_id));
      if (row.token_id === step.selected_token_id) button.append(el('small', ' · emitted'));
      button.onclick = () => { choose(row); document.querySelector(`.tg-tokens button[aria-pressed="true"]`)?.focus({preventScroll: true}); }; tokens.append(button);
    }
    if (!tokens.childElementCount) tokens.append(el('small', mass === 0 ? 'Zero input mass' : 'No captured tokens'));
    card.append(tokens); list.append(card);
  });
  blocks.append(list); root.append(blocks, transportView(trace), entropyView(trace), drawView(trace, step));
  const row = rows.find(row => row.token_id === chosen.token_id);
  if (row) {
    const inspected = heading(`Inspected token / ${piece(chosen)}`, 'The detection score is a keyed per-token signal, not a p-value or a probability of authorship.');
    inspected.append(metrics([['Block', String(row.block + 1)], ['Before → after', `${percent(row.before)} → ${percent(row.after)}`], ['Selected-column cost', number(row.cost)], ['Detection score', number(row.detectionScore)]]));
    root.append(inspected);
  }
  return root;
}
