// Projections of the recorded native trace, never a transport solver or sampler.
export function textgrainRows(step) {
  const trace = step.textgrain;
  if (!trace || trace.status !== 'applied') return [];
  return step.candidates.map((candidate, index) => ({...candidate,
    block: trace.blocks[index], before: trace.input_probabilities[index],
    after: trace.output_probabilities[index], cost: trace.selected_costs[index],
    detectionScore: trace.detection_scores[index]}));
}
export function transportCell(trace, block, column) {
  const table = trace.transport, index = block * table.column_count + column;
  return {cost: table.costs[index], coupling: table.coupling[index],
    selected: column === trace.selected_column};
}
