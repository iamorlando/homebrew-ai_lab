"""Bounded, key-free TextGrain native transport and production-draw contract.

Mistral edc4950d31f1247ed641176e1cf0c9d8ce4d0274; no reconstructed evidence.
"""
import math

MAX_OBSERVATIONS = 65536
MAX_TRANSPORT_CELLS = 4096
# Native f64 cumulative sums / marginal correction may overshoot one by a few
# ULPs per addition across the full model vocabulary. Validate with bounded
# accumulation tolerance, but retain the original trace bytes.
ROUNDING_TOLERANCE = 1e-9
PROBABILITY_CEILING = 1 + ROUNDING_TOLERANCE


def capture_limits(watermark, limits):
    """Bound diagnostics, never the solver, token count, policy or RNG stream."""
    blocks, columns = watermark['block_count'], watermark['column_count']
    iterations = min(16, watermark['max_iterations'])
    transport = blocks * columns <= MAX_TRANSPORT_CELLS
    # Match native TextGrainTraceConfig::records plus generic candidate records.
    records = limits['max_candidates'] * 13 + blocks * 3 + iterations * 6 + 32
    if transport:
        records += blocks * columns * 2
    return {**limits, 'max_layers': 0,
            'max_steps': min(limits['max_steps'], MAX_OBSERVATIONS // records),
            'textgrain': {'max_iterations': iterations, 'transport': transport}}


def public_textgrain(source, step, limits):
    def require(ok):
        if not ok:
            raise ValueError('Mistral returned an invalid TextGrain trace.')

    def subset(value, names):
        require(isinstance(value, dict))
        return {key: value[key] for key in names.split() if key in value}

    def integer(value, low=0, high=10000):
        return type(value) is int and low <= value <= high

    def finite(value, low=-math.inf, high=math.inf):
        return type(value) in (int, float) and math.isfinite(value) and low <= value <= high

    def vector(value, size, low=-math.inf, high=math.inf):
        require(isinstance(value, list) and len(value) == size and all(finite(x, low, high) for x in value))

    def same(a, b):
        return math.isclose(a, b, rel_tol=2e-5, abs_tol=2e-6)

    require((step.get('watermark') or {}).get('scheme') == 'textgrain' and not step['layers'])
    require('generation_tournament' not in step and 'teaching_tournament' not in step)
    result = subset(source, 'status token_ids input_probabilities output_probabilities output_log_probabilities blocks selected_column block_masses conditional_block_probabilities selected_costs detection_scores solver iterations omitted_iterations transport generation')
    status = result.get('status')
    require(status in {'applied', 'warmup', 'repeated_context'} and status == step['watermark']['status'])
    ids = [c['token_id'] for c in step['candidates']]
    count = len(ids)
    require(result.get('token_ids') == ids)
    for key in ('input_probabilities', 'output_probabilities'):
        vector(result.get(key), count, 0, 1)
        require(sum(result[key]) <= 1.00002)
    logs = result.get('output_log_probabilities')
    require(isinstance(logs, list) and len(logs) == count)
    for index, candidate in enumerate(step['candidates']):
        before, after = result['input_probabilities'][index], result['output_probabilities'][index]
        require(finite(candidate.get('pre_watermark_probability'), 0, 1) and same(before, candidate['pre_watermark_probability']))
        require(finite(candidate.get('post_watermark_probability'), 0, 1) and same(after, candidate['post_watermark_probability']))
        require((logs[index] is None and after == 0) or (finite(logs[index], high=0) and same(math.exp(logs[index]), after)))
    require(integer(result.get('omitted_iterations')))
    iterations = result.get('iterations')
    require(isinstance(iterations, list) and len(iterations) <= limits.get('textgrain', {}).get('max_iterations', 16))
    result['iterations'] = []
    previous = -1
    for item in iterations:
        row = subset(item, 'iteration regularization achieved_fraction row_residual column_residual')
        require(integer(row.get('iteration'), 1) and row['iteration'] > previous)
        previous = row['iteration']
        require(all(finite(row.get(key), 0) for key in ('regularization', 'row_residual', 'column_residual')))
        require(finite(row.get('achieved_fraction'), -ROUNDING_TOLERANCE))
        result['iterations'].append(row)
    if status == 'applied':
        masses = result.get('block_masses')
        require(isinstance(masses, list) and 1 <= len(masses) <= 256)
        blocks = len(masses)
        vector(masses, blocks, 0, PROBABILITY_CEILING)
        vector(result.get('conditional_block_probabilities'), blocks, 0, PROBABILITY_CEILING)
        require(same(sum(masses), 1) and same(sum(result['conditional_block_probabilities']), 1))
        require(isinstance(result.get('blocks'), list) and len(result['blocks']) == count and all(integer(x, 0, blocks - 1) for x in result['blocks']))
        require(integer(result.get('selected_column'), 0, 255))
        vector(result.get('selected_costs'), count)
        vector(result.get('detection_scores'), count, 0)
        solver = subset(result.get('solver'), 'status iterations token_entropy block_entropy requested_fraction target_fraction achieved_fraction entropy_loss regularization row_residual column_residual budget_satisfied')
        require(solver.get('status') in {'independent', 'converged', 'iteration_limit'})
        require(integer(solver.get('iterations')) and len(iterations) + result['omitted_iterations'] == solver['iterations'])
        require(all(finite(solver.get(key), 0) for key in ('requested_fraction', 'row_residual', 'column_residual')))
        require(all(finite(solver.get(key), -ROUNDING_TOLERANCE) for key in ('token_entropy', 'block_entropy', 'target_fraction', 'achieved_fraction', 'entropy_loss')))
        require(solver.get('regularization') is None or finite(solver['regularization'], 0))
        require(type(solver.get('budget_satisfied')) is bool)
        result['solver'] = solver
        transport = result.get('transport')
        if transport is not None:
            require(limits.get('textgrain', {}).get('transport', True))
            transport = subset(transport, 'block_count column_count costs coupling')
            columns = transport.get('column_count')
            require(transport.get('block_count') == blocks and integer(columns, 1, 256) and blocks * columns <= MAX_TRANSPORT_CELLS)
            require(result['selected_column'] < columns)
            vector(transport.get('costs'), blocks * columns)
            vector(transport.get('coupling'), blocks * columns, 0, PROBABILITY_CEILING)
            for block in range(blocks):
                require(same(sum(transport['coupling'][block * columns:(block + 1) * columns]), masses[block]))
                require(same(columns * transport['coupling'][block * columns + result['selected_column']], result['conditional_block_probabilities'][block]))
            for column in range(columns):
                require(same(sum(transport['coupling'][column::columns]), 1 / columns))
            result['transport'] = transport
    else:
        require(all(result.get(key) is None for key in ('blocks', 'selected_column', 'selected_costs', 'detection_scores', 'solver', 'transport')))
        require(result.get('block_masses') == [] and result.get('conditional_block_probabilities') == [] and not iterations and result['omitted_iterations'] == 0)

    generation = result.get('generation')
    if step['selection_rule'] == 'textgrain_block_then_token':
        generation = subset(generation, 'origin used_for_generation selected_token_id selected_block block_draw token_draw rng_draws sampling_version rng_version effective_seed rng_provenance')
        require(generation.get('origin') == 'production' and generation.get('used_for_generation') is True)
        require(generation.get('selected_token_id') == step['selected_token_id'])
        require(generation.get('rng_draws') == (2 if status == 'applied' else 1))
        if status == 'applied':
            require(generation.get('selected_block') == result['blocks'][ids.index(step['selected_token_id'])])
        else:
            require(generation.get('selected_block') is None and generation.get('block_draw') is None)
        for name in ('block_draw', 'token_draw'):
            if name == 'block_draw' and status != 'applied':
                continue
            draw = subset(generation.get(name), 'uniform cdf_lower cdf_upper')
            require(finite(draw.get('uniform'), 0, 1) and draw['uniform'] < 1)
            require(all(finite(draw.get(k), 0, PROBABILITY_CEILING) for k in ('cdf_lower', 'cdf_upper')))
            require(draw['cdf_lower'] <= draw['uniform'] < draw['cdf_upper'])
            generation[name] = draw
        require(all(isinstance(generation.get(k), str) and 0 < len(generation[k]) <= 200 for k in ('sampling_version', 'rng_version')))
        seed = generation.get('effective_seed')
        require((generation.get('rng_provenance') == 'sequence_seed' and isinstance(seed, str) and seed.isascii() and seed.isdigit() and len(seed) <= 20 and int(seed) <= 2**64 - 1) or
                (generation.get('rng_provenance') == 'shared_host_stream' and seed is None))
        result['generation'] = generation
    else:
        require(step['selection_rule'] == 'categorical' and generation is None)
    return result


def validate_request(trace, watermark):
    for step in trace['steps']:
        if (step.get('watermark') or {}).get('scheme') != 'textgrain':
            raise ValueError('Mistral returned a mismatched TextGrain watermark.')
        native = step.get('textgrain')
        if step['watermark']['status'] == 'greedy':
            continue
        if not native:
            raise ValueError('Mistral returned no native TextGrain trace. Use a TextGrain-capable Mistral runtime.')
        direct = watermark['generation_policy'] == 'block_then_token'
        if direct != (step['selection_rule'] == 'textgrain_block_then_token'):
            raise ValueError('Mistral did not execute the requested TextGrain generation policy.')
        if native['status'] == 'applied':
            transport = native.get('transport')
            if (len(native['block_masses']) != watermark['block_count'] or native['selected_column'] >= watermark['column_count']
                    or not math.isclose(native['solver']['requested_fraction'], watermark['entropy_loss'], abs_tol=1e-6)
                    or (transport and transport['column_count'] != watermark['column_count'])):
                raise ValueError('Mistral returned mismatched TextGrain configuration diagnostics.')
