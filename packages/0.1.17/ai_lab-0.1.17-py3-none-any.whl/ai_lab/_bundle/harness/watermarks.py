"""The token-generation watermark contract of the local mistral.rs fork.

Field metadata drives both the configuration form and server-side validation.
SemStamp needs an embedding/rejection pipeline and is not a token scheme.
"""
import math
import re
from copy import deepcopy

VOCAB_SIZE = 151936  # DeepSeek GGUF output rows, including padding.


def field(name, label, kind, default=None, **limits):
    return {"name": name, "label": label, "type": kind, "default": default, **limits}


KEY = field("key", "Watermark key", "key", help="64 hexadecimal characters. Generate a random key or supply your own.")
VOCAB = field("vocab_size", "Output vocabulary size", "integer", VOCAB_SIZE, min=VOCAB_SIZE, max=VOCAB_SIZE,
              help="Fixed to this model’s padded output vocabulary.")
CONTEXT = field("context_width", "Context width", "integer", 1, min=1, max=32)
FRACTION = field("green_fraction", "Green fraction", "number", 0.5, min=1 / VOCAB_SIZE, max=(VOCAB_SIZE - 1) / VOCAB_SIZE, step="any")
DELTA = field("delta", "Logit bias (delta)", "number", 2, min=0, step="any")
REPEAT = field("ignore_repeated_ngrams", "Ignore repeated n-grams", "boolean", True)
POSITION = [field("sequence_len", "Key sequence length", "integer", 1024, min=1, max=65536),
            field("start_position", "Starting position", "integer", 0, min=0, max=9007199254740991)]
SCHEMES = [
    {"id": "synthid", "name": "SynthID-Text",
     "description": "Uses tournament-style sampling to favor tokens with high scores derived from the secret key and recent context. Detection checks for those scores across the response.",
     "paper": {"title": "Scalable watermarking for identifying large language model outputs", "url": "https://www.nature.com/articles/s41586-024-08025-4"},
     "fields": [KEY, field("ngram_len", "N-gram length", "integer", 5, min=2, max=32),
                field("generation_policy", "Generation policy", "enum", "probability_updates",
                      options=[{"value": "tournament", "label": "Tournament · actual bracket"},
                               {"value": "probability_updates", "label": "Probability updates · no bracket"}],
                      help="Tournament sampling emits the bracket winner. Probability updates sample from a reweighted distribution."),
                field("depth", "Tournament depth", "integer", 30, min=1, max=256,
                      help="Actual tournaments support depth 1–20 and perform up to 2^depth draws per token. A depth of 4 gives 16 contestants.")]},
    {"id": "kgw", "name": "KGW",
     "description": "Uses the secret key and recent context to choose a green list of tokens, then boosts their logits. Detection looks for more green-list tokens than expected by chance.",
     "paper": {"title": "A Watermark for Large Language Models", "url": "https://arxiv.org/abs/2301.10226"},
     "fields": [KEY, VOCAB, CONTEXT, FRACTION, DELTA, REPEAT]},
    {"id": "unigram", "name": "Unigram",
     "description": "Boosts a fixed green list of tokens chosen by the secret key, independent of recent context. Detection measures how often those tokens appear in the response.",
     "paper": {"title": "Provable Robust Watermarking for AI-Generated Text", "url": "https://arxiv.org/abs/2306.17439"},
     "fields": [KEY, VOCAB, FRACTION, DELTA, field("ignore_repeated_tokens", "Ignore repeated tokens", "boolean", True)]},
    {"id": "exponential", "name": "Exponential race",
     "description": "Combines model probabilities with random values derived from the secret key and token position in an exponential race. Detection checks how well the response matches that keyed sequence.",
     "paper": {"title": "Robust Distortion-free Watermarks for Language Models", "url": "https://arxiv.org/abs/2307.15593"},
     "fields": [KEY, VOCAB, *POSITION]},
    {"id": "inverse_transform", "name": "Inverse transform",
     "description": "Selects tokens from cumulative model probabilities using a secret-key token ordering and random values for each position. Detection checks how well the response matches that keyed sequence.",
     "paper": {"title": "Robust Distortion-free Watermarks for Language Models", "url": "https://arxiv.org/abs/2307.15593"},
     "fields": [KEY, VOCAB, *POSITION]},
    {"id": "mpac", "name": "MPAC",
     "description": "Embeds a multi-symbol message by assigning each context to a payload position and boosting the token group for its symbol. Detection can recover the message or score a known payload.",
     "paper": {"title": "Advancing Beyond Identification: Multi-bit Watermark for Large Language Models", "url": "https://aclanthology.org/2024.naacl-long.224/"},
     "fields": [KEY, VOCAB, field("radix", "Payload radix", "integer", 2, min=2, max=256), field("payload", "Payload symbols", "symbols", [1, 0, 1, 1], help="Comma-separated integers, each smaller than the radix."), CONTEXT, DELTA, REPEAT]},
    {"id": "textgrain", "name": "TextGrain",
     "description": "Partitions tokens into keyed blocks and uses optimal transport to redistribute their probabilities under an entropy-loss budget. Detection tests the resulting keyed scores with a Gamma tail.",
     "paper": {"title": "textGrain: Entropy-Calibrated Watermarking for Language Model Text", "url": "https://cdn.openai.com/pdf/e9508624-d767-41b6-a26d-e34ca798ada6/textgrain-entropy-calibrated-watermarking-for-language-model-text.pdf"},
     "fields": [KEY, field("context_width", "Context width", "integer", 4, min=1, max=32),
                field("block_count", "Vocabulary blocks", "integer", 16, min=1, max=256),
                field("column_count", "Transport columns", "integer", 32, min=1, max=256),
                field("entropy_loss", "Entropy-loss budget (fraction)", "number", 0.1, min=0, max=1, step="any",
                      help="Requested fraction of token entropy removed, averaged across columns. Inspect the achieved loss and solver status in the trace."),
                field("max_iterations", "Solver iteration limit", "integer", 128, min=1, max=10000),
                field("entropy_tolerance", "Entropy fraction tolerance", "number", 0.0001, min=0, exclusive_min=True, step="any",
                      help="Positive absolute tolerance on the target entropy fraction."),
                field("generation_policy", "Generation policy", "enum", "probability_updates",
                      options=[{"value": "probability_updates", "label": "Probability updates"},
                               {"value": "block_then_token", "label": "Block then token · recorded draws"}],
                      help="Probability updates use ordinary categorical sampling. Block then token records the actual block and within-block token draws.")]},
]
BY_ID = {scheme["id"]: scheme for scheme in SCHEMES}


def schemes_for_model(model=None):
    """Model-specific field bounds without mutating the shared scheme catalog."""
    from harness.generation_models import generation_backend
    vocab_size = generation_backend(model).vocab_size
    schemes = deepcopy(SCHEMES)
    for scheme in schemes:
        for item in scheme['fields']:
            if item['name'] == 'vocab_size':
                item.update(default=vocab_size, min=vocab_size, max=vocab_size)
            elif item['name'] == 'green_fraction':
                item.update(min=1 / vocab_size, max=(vocab_size - 1) / vocab_size)
    return schemes


def validate_watermark(value, model=None):
    if value is None:
        return None
    if not isinstance(value, dict) or not isinstance(value.get("scheme"), str) or value["scheme"] not in BY_ID:
        raise ValueError("Choose a supported text watermark scheme.")
    scheme = next(scheme for scheme in schemes_for_model(model) if scheme['id'] == value['scheme'])
    if set(value) - {"scheme", *(f["name"] for f in scheme["fields"])}:
        raise ValueError("The watermark configuration contains fields from another scheme.")
    result = {"scheme": scheme["id"]}
    for f in scheme["fields"]:
        item = value.get(f["name"], f["default"])
        kind = f["type"]
        valid = True
        if kind == "key":
            valid = isinstance(item, str) and re.fullmatch(r"[0-9a-fA-F]{64}", item)
            if valid:
                item = item.lower()
        elif kind == "boolean":
            valid = isinstance(item, bool)
        elif kind == "symbols":
            valid = (isinstance(item, list) and 1 <= len(item) <= 65536
                     and all(type(x) is int and 0 <= x < result["radix"] for x in item))
        elif kind == "enum":
            valid = isinstance(item, str) and item in {option["value"] for option in f["options"]}
        else:
            valid = (type(item) in (int, float) and math.isfinite(item)
                     and (kind != "integer" or type(item) is int)
                     and item >= f.get("min", -math.inf) and item <= f.get("max", math.inf))
            if valid and f.get("exclusive_min"):
                valid = item > f["min"]
        if not valid:
            raise ValueError(f"Invalid watermark {f['label'].lower()}.")
        result[f["name"]] = item
    if result.get("generation_policy") == "tournament" and result["depth"] > 20:
        raise ValueError("Actual tournament generation requires depth 1–20. Choose a depth explicitly; it is never reduced automatically.")
    return result
