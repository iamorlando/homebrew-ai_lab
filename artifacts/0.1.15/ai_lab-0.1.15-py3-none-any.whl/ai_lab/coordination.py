"""Coordinate website and private-service processes without a second session owner."""
import asyncio
import fcntl
from pathlib import Path

import httpx
from fastapi.responses import JSONResponse, Response

from ai_lab.client import socket_path
from ai_lab.paths import require_owned_path


class WorkspaceLock:
    """Async process-local serialization plus a shared advisory file lock."""
    def __init__(self, root):
        self.path = require_owned_path(root, '.state/ai-lab/configuration.lock')
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.local = asyncio.Lock()
        self.stream = None

    async def __aenter__(self):
        await self.local.acquire()
        stream = None
        try:
            stream = self.path.open('a')
            while True:
                try:
                    fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    self.stream = stream
                    return self
                except BlockingIOError:
                    await asyncio.sleep(.05)
        except BaseException:
            if stream:
                stream.close()
            self.local.release()
            raise

    async def __aexit__(self, *args):
        stream, self.stream = self.stream, None
        try:
            if stream:
                fcntl.flock(stream, fcntl.LOCK_UN)
                stream.close()
        finally:
            self.local.release()


def proxy_private_sessions(app, root):
    """If the private daemon is alive, it remains the session owner."""
    path = socket_path(root)

    @app.middleware('http')
    async def existing_service(request, call_next):
        if not request.url.path.startswith('/api/lab/') or not path.exists():
            return await call_next(request)
        try:
            async with httpx.AsyncClient(transport=httpx.AsyncHTTPTransport(uds=str(path)),
                                         base_url='http://localhost', timeout=35, trust_env=False) as client:
                identity = await client.get('/api/lab/health')
                identity.raise_for_status()
                value = identity.json()
                if value.get('application') != 'ai-lab' or value.get('root') != str(Path(root).resolve()):
                    return JSONResponse({'detail': 'AI Lab socket belongs to a different workspace.'}, status_code=503)
                local = app.state.ai_lab
                if any(not task.done() for task in local.tasks.values()):
                    return JSONResponse({'detail': 'A website-owned completion is still finishing.'}, status_code=409)
                local.records.clear()
                local.loaded = False
                # Preserve Origin so the private server applies its own write policy.
                headers = {key: value for key, value in request.headers.items() if key.lower() in {'content-type', 'origin'}}
                response = await client.request(request.method, request.url.path, params=request.query_params,
                                                content=await request.body(), headers=headers)
                return Response(response.content, status_code=response.status_code,
                                media_type=response.headers.get('content-type'))
        except (httpx.HTTPError, ValueError):
            # Never fall back to a second mutable store during a transient failure.
            return JSONResponse({'detail': 'The existing AI Lab service is temporarily unavailable. Retry shortly.'}, status_code=503)


async def website_model_write(root, method, key=None, body=None):
    """Publish through the live website so its OpenCode aliases stay in sync."""
    import os
    from urllib.parse import urlparse
    url = os.environ.get('AI_LAB_SERVER', 'http://127.0.0.1:8080')
    parsed = urlparse(url)
    if parsed.scheme != 'http' or parsed.hostname not in {'127.0.0.1', 'localhost'}:
        return None
    async with httpx.AsyncClient(base_url=url, timeout=35, trust_env=False) as client:
        try:
            identity = await client.get('/api/workspace', timeout=.7)
            value = identity.json() if identity.status_code == 200 else {}
        except (httpx.HTTPError, ValueError):
            return None
        if value.get('kind') != 'deepseek-comparison' or value.get('root') != str(Path(root).resolve()):
            return None
        response = await client.request(method, '/api/models' + (f'/{key}' if key else ''), json=body)
        # Once the workspace is identified, do not retry a failed write locally.
        return Response(response.content, status_code=response.status_code,
                        media_type=response.headers.get('content-type'))
