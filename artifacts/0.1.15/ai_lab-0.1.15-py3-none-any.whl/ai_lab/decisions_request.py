"""Terminal drafts, using the shared Decisions schema and web request rules."""
from copy import deepcopy
import importlib
import json
from pathlib import Path
import shlex
import sys

from pydantic import ValidationError

from ai_lab.paths import RESOURCES


PROVIDERS = {
    'contrastive': 'Contrastive (Mistral)',
    'clm-upstream': 'CLM upstream',
    'laya': 'Laya (ONNX)',
    'jev': 'Jev',
}
ALIASES = {
    **{name: name for name in PROVIDERS},
    **{label.casefold(): name for name, label in PROVIDERS.items()},
    'native contrastive clm': 'contrastive', 'upstream contrastive clm': 'clm-upstream',
}


def provider_name(value):
    try:
        return ALIASES[value.strip().casefold()]
    except (KeyError, AttributeError):
        raise ValueError('Choose contrastive, clm-upstream, laya, or jev (or its discovery label).') from None


def shared_api():
    # Identical source in checkouts and the wheel's bundled harness.
    for path in (RESOURCES, RESOURCES / 'harness'):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    return importlib.import_module('decisions')


def json_text(value):
    return json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)


def parse_json(text, field='JSON'):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('Duplicate object keys are not allowed.')
            result[key] = value
        return result

    def constant(_):
        raise ValueError('Nonfinite numbers are not JSON.')

    try:
        return json.loads(text, object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, RecursionError):
        raise ValueError(f'{field} must be valid JSON with unique keys and finite numbers.') from None


def validate_request(mode, body):
    api = shared_api()
    schema = api.RankInput if mode == 'rank' else api.DecisionInput
    try:
        validated = schema.model_validate(body).model_dump(exclude_none=True)
    except ValidationError as error:
        # Pydantic's default str(error) includes the user's input values.
        messages = []
        for issue in error.errors(include_input=False, include_url=False):
            location = '.'.join(str(part) for part in issue['loc']) or 'request'
            messages.append(f"{location}: {issue['msg']}")
        raise ValueError('; '.join(messages)) from None
    try:
        size = len(json.dumps(validated, ensure_ascii=False, allow_nan=False).encode())
    except (ValueError, RecursionError):
        raise ValueError('Request must contain finite JSON values.') from None
    if size > api.MAX_REQUEST_BYTES:
        raise ValueError('Decision requests must be at most 100 KB.')
    return validated


def rank_candidate_list(text):
    return [line for line in text.splitlines() if line.strip()]


def rank_editor_text(answers):
    """Reject imports that cannot preserve candidate identities in the line editor."""
    text = '\n'.join(answers)
    if rank_candidate_list(text) != answers:
        raise ValueError('Terminal rank imports require candidates that round-trip unchanged through the one-per-line editor.')
    return text


def build_request(model, mode, state, state_json, questions, rank_question='', candidates=''):
    if not state.strip():
        raise ValueError('Add a state: the context the questions are asked about.')
    context = parse_json(state, 'State') if state_json else state
    if mode == 'rank':
        answers = rank_candidate_list(candidates)
        if len(answers) < 2:
            raise ValueError('Add at least two candidates, one per line.')
        body = {'model': model, 'context': context, 'question': rank_question or None, 'answers': answers}
    else:
        if not questions:
            raise ValueError('Add at least one question.')
        wire = {}
        for item in questions:
            name = item['id'].strip()
            if not name:
                raise ValueError('Every question needs an ID.')
            if name in wire:
                raise ValueError('Duplicate question IDs: every question needs a unique ID.')
            instructions = item['instructions']
            if not instructions.strip():
                raise ValueError(f'Question {name} needs instructions.')
            instructions = parse_json(instructions, f'{name} instructions') if item.get('instructions_json') else instructions
            question = {'type': item['type'], 'instructions': instructions}
            criteria = item.get('criteria', '').strip()
            if criteria:
                question['criteria'] = parse_json(criteria, f'{name} criteria')
            if item['type'] == 'choice' and isinstance(question.get('criteria'), dict) and len(question['criteria']) < 2:
                raise ValueError(f'Choice question {name} needs at least two named options.')
            wire[name] = question
        body = {'model': model, 'state': context, 'questions': wire}
    return validate_request(mode, body)


def snippets(mode, body):
    endpoint = 'http://127.0.0.1:8080/api/decisions/' + ('rank' if mode == 'rank' else 'systemone')
    data = json_text(body)
    curl = f"curl --fail-with-body -sS {shlex.quote(endpoint)} \\\n  -H 'Content-Type: application/json' \\\n  --data-binary {shlex.quote(data)}"
    python = ('import json\nimport urllib.request\n\n'
              f'payload = json.loads({data!r})\n'
              f'request = urllib.request.Request({endpoint!r},\n'
              '    data=json.dumps(payload).encode(),\n'
              '    headers={"Content-Type": "application/json"}, method="POST")\n'
              'with urllib.request.urlopen(request, timeout=130) as response:\n'
              '    print(json.dumps(json.load(response), indent=2))')
    return {'curl': curl, 'python': python}


def _q(name, kind, instructions, criteria=None):
    return {'id': name, 'type': kind, 'instructions': instructions,
            'instructions_json': False, 'criteria': json_text(criteria) if criteria is not None else ''}


PRESETS = {
    'support': {'label': 'Support ticket triage', 'mode': 'ask',
                'state': 'Customer: my invoice was charged twice and nobody answers the phone!',
                'questions': [_q('urgency', 'noul', 'Is this urgent?'),
                              _q('department', 'choice', 'Which team should handle this?',
                                 {'billing': 'Charges, invoices, refunds', 'technical': 'Bugs and outages'}),
                              _q('frustration', 'score', 'How frustrated is the customer?',
                                 ['Calm', 'Frustrated', 'Very angry'])]},
    'trajectory': {'label': 'Agent trajectory verifier', 'mode': 'ask',
                   'state': 'Task: the test suite fails with "ModuleNotFoundError: No module named \'yaml\'".\n\n'
                            'Agent trajectory:\n  $ pytest -q\n  ModuleNotFoundError: No module named \'yaml\'\n'
                            '  $ pip install pyyaml\n  Successfully installed pyyaml-6.0.2\n'
                            '  $ pytest -q\n  34 passed in 4.21s',
                   'questions': [_q('solved', 'noul', 'Did the agent actually solve the task?'),
                                 _q('failure_mode', 'choice', 'If it went wrong, how?',
                                    {'none': 'Nothing went wrong; the task is complete',
                                     'gave_up': 'The agent stopped before finishing',
                                     'faked_it': 'The agent edited or skipped the tests instead of fixing the code',
                                     'wrong_fix': 'The agent changed something unrelated to the failure'}),
                                 _q('quality', 'score', 'How good is this trajectory?',
                                    ['Broken — the task is not done', 'Works but is sloppy', 'Clean, minimal and correct'])]},
    'review': {'label': 'Pull-request risk review', 'mode': 'ask',
               'state': 'diff --git a/auth/session.py b/auth/session.py\n@@\n'
                        '-    if token and verify(token):\n-        return load_user(token)\n-    return None\n'
                        '+    if token:\n+        return load_user(token)\n+    return None',
               'questions': [_q('safe_to_merge', 'noul', 'Is this change safe to merge as-is?'),
                             _q('area', 'choice', 'Which area does this touch?',
                                {'security': 'Authentication, authorization, secrets, crypto',
                                 'performance': 'Latency, memory, throughput', 'style': 'Formatting, naming, comments',
                                 'feature': 'New user-visible behaviour'}),
                             _q('risk', 'score', 'How risky is this change?',
                                ['Trivial', 'Worth a second pair of eyes', 'Do not merge without a test'])]},
    'bestofn': {'label': 'Best-of-N answers', 'mode': 'rank', 'state': 'What causes tides on Earth?',
                'rank_question': '', 'candidates': "The Moon's gravitational pull.\nPhotosynthesis in plants.\n"
                'Because the Earth is round.\nThe gravitational pull of the Moon and, to a lesser extent, the Sun.'},
    'tools': {'label': 'Tool routing', 'mode': 'rank',
              'state': "User: I'm in Berlin until Friday — will I need an umbrella?",
              'rank_question': 'Which tool should the agent call next?',
              'candidates': 'get_weather_forecast(city, days) — multi-day forecast for a city\n'
                            "search_web(query) — general web search\nsend_email(to, subject, body) — send an email on the user's behalf\n"
                            'book_flight(origin, destination, date) — search and book flights\n'
                            "get_calendar_events(start, end) — the user's calendar"},
}


def preset(name):
    return deepcopy(PRESETS[name])
