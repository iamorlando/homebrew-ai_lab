"""The shared session API, mounted in either the website or the private daemon."""
import asyncio
from contextlib import asynccontextmanager
from copy import deepcopy
import json
from pathlib import Path
import secrets
import time
import uuid

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, StrictInt, StrictStr

API_VERSION = 1


class Input(BaseModel):
    model_config = ConfigDict(extra='forbid')


class ModelInput(Input):
    name: StrictStr = Field(min_length=1, max_length=80)
    seed: StrictStr | StrictInt | None = None
    underlying_model: StrictStr = 'DeepSeekR1'
    watermark: dict | None = None


class WatermarkUpdateInput(Input):
    underlying_model: StrictStr | None = None
    scheme: StrictStr | None = None
    key: StrictStr | None = None
    settings: dict | None = None


class SessionInput(Input):
    """Select exactly one model ID/legacy exact name or model_name; name labels the session."""
    model_config = ConfigDict(extra='forbid', json_schema_extra={'oneOf': [
        {'required': ['model'], 'properties': {'model': {'type': 'string'}, 'model_name': {'type': 'null'}}},
        {'required': ['model_name'], 'properties': {'model_name': {'type': 'string'}, 'model': {'type': 'null'}}},
    ]})
    model: StrictStr | None = Field(default=None, description='Saved profile ID or legacy exact profile name; mutually exclusive with model_name.')
    model_name: StrictStr | None = Field(default=None, min_length=1, max_length=80, description='Exact saved profile name, including case; mutually exclusive with model. Never interpreted as an ID.')
    scheme: StrictStr = 'model'
    watermark: dict | None = None
    name: StrictStr = Field(default='', max_length=80, pattern=r'^[^\x00-\x1f]*$')
    temperature: float = Field(default=1, ge=0, le=2)


class CompletionInput(Input):
    prompt: StrictStr = Field(min_length=1, max_length=24000)
    max_tokens: StrictInt = Field(default=1, ge=1, le=256)
    expected_revision: StrictInt | None = None


class SelectionInput(Input):
    step: StrictInt = Field(ge=0)
    token_id: StrictInt | None = Field(default=None, ge=0)
    expected_revision: StrictInt
    layer: StrictInt | None = Field(default=None, ge=-1)


class AppendInput(Input):
    expected_revision: StrictInt


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(f'.{path.name}.{uuid.uuid4().hex}.tmp')
    try:
        with temporary.open('x', encoding='utf-8') as stream:
            temporary.chmod(0o600)
            json.dump(value, stream, ensure_ascii=False, allow_nan=False)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def public_session(value):
    value = deepcopy(value)
    for config in (value.get('watermark'), value.get('profile', {}).get('watermark')):
        if config:
            config.pop('key', None)
    return value


def token_text(step, token_id):
    for candidate in step.get('candidates', []):
        if candidate['token_id'] == token_id:
            return candidate['text']
    for draw in (step.get('generation_tournament') or {}).get('draws', []):
        if draw['token_id'] == token_id and draw.get('text_status') == 'decoded':
            return draw['text']
    raise ValueError('The selected token has no captured decoded text; it cannot be appended.')


class Sessions:
    def __init__(self, root, registry, runtime, lock, require_idle, publish):
        self.root, self.registry, self.runtime = Path(root), registry, runtime
        self.lock, self.require_idle, self.publish = lock, require_idle, publish
        self.directory = self.root / '.state/ai-lab/sessions'
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.directory.chmod(0o700)
        self.records, self.tasks = {}, {}
        self.loaded = False

    def load(self):
        if self.loaded:
            return
        self.loaded = True
        for path in self.directory.glob('*.json'):
            record = json.loads(path.read_text())
            self.records[record['id']] = record
            if record['status'] == 'running':
                record.update(status='interrupted', error='The service stopped during this run. Submit the prompt again.')
                self.save(record)

    def save(self, record):
        record['revision'] += 1
        record['updated_at'] = time.time()
        atomic_json(self.directory / f"{record['id']}.json", record)

    def get(self, session):
        self.load()
        if session not in self.records:
            raise HTTPException(404, 'Session not found. Open Completion to select a saved session.')
        return self.records[session]

    def idle(self):
        self.load()
        if any(not task.done() for task in self.tasks.values()):
            raise HTTPException(409, 'A completion is already running. Wait or stop it first.')

    async def create(self, body):
        from watermarks import BY_ID, validate_watermark
        async with self.lock:
            self.load()
            profiles = self.registry.supported_profiles()
            if (body.model is None) == (body.model_name is None):
                raise HTTPException(422, 'Select exactly one of model (ID) or model_name (exact saved name). Open Models for names and IDs.')
            selector = body.model_name if body.model_name is not None else body.model
            matches = [key for key, p in profiles.items()
                       if p['name'] == selector or (body.model_name is None and key == selector)]
            if not matches:
                raise HTTPException(422, 'Unknown model name or ID. Open Models; model_name requires the exact saved name, including case.')
            if len(matches) > 1:
                raise HTTPException(422, 'Ambiguous model selection. Open Models and select a unique model_name or a distinct model ID.')
            key = matches[0]
            profile = deepcopy(profiles[key])
            if body.scheme not in {'none', 'model', *BY_ID}:
                raise HTTPException(422, 'Unknown watermark scheme. Open Models to choose a supported watermark scheme.')
            if body.watermark is not None and body.scheme in {'none', 'model'}:
                raise HTTPException(422, 'A watermark override requires its explicit scheme.')
            watermark = deepcopy(profile.get('watermark')) if body.scheme == 'model' else None
            if body.scheme in BY_ID:
                existing = profile.get('watermark') or {}
                watermark = deepcopy(existing) if existing.get('scheme') == body.scheme else {'scheme': body.scheme, 'key': secrets.token_hex(32)}
                if body.scheme == 'synthid' and existing.get('scheme') != 'synthid':
                    watermark.update(generation_policy='tournament', depth=4)
                if body.watermark:
                    if body.watermark.get('scheme', body.scheme) != body.scheme:
                        raise HTTPException(422, 'Watermark configuration and scheme disagree.')
                    watermark.update(body.watermark)
                watermark = validate_watermark(watermark)
            record = dict(id=str(uuid.uuid4()), name=body.name or profile['name'], model=key, profile=profile,
                          watermark=watermark, temperature=body.temperature, prompt='', answer='', results=[],
                          selected_step=0, selected_token_id=None, selected_layer=-1, position=0, revision=0,
                          status='idle', error=None, created_at=time.time())
            self.records[record['id']] = record
            self.save(record)
            return public_session(record)

    def check_revision(self, record, revision):
        if revision is not None and record['revision'] != revision:
            raise HTTPException(409, 'Session changed in another pane. Refresh and try again.')

    async def start(self, session, body, *, position=0):
        record = self.get(session)
        async with self.lock:
            self.idle()
            await self.require_idle()
            self.check_revision(record, body.expected_revision)
            # A deleted profile cannot be used by an older saved session.
            if record['model'] not in self.registry.supported_profiles():
                raise HTTPException(409, 'This model was deleted. Create a session with an existing model.')
            record.update(prompt=body.prompt, answer='', results=[], selected_step=0,
                          selected_token_id=None, selected_layer=-1, position=position, status='running', error=None)
            self.save(record)
            self.tasks[session] = asyncio.create_task(self.generate(record, body.max_tokens))
        return public_session(record)

    async def generate(self, record, count):
        # Keep the same lock as the website's model changes and live experiments.
        async with self.lock:
            try:
                for index in range(count):
                    if record.get('stop_requested'):
                        record['status'] = 'stopped'
                        break
                    watermark = deepcopy(record['watermark'])
                    if watermark and 'start_position' in watermark:
                        watermark['start_position'] += record['position'] + index
                    prefix = record['prompt'] + record['answer']
                    if len(prefix) > 24000:
                        raise ValueError('The prefix has reached the 24,000-character inspection limit.')
                    result = await self.runtime.complete_next(prefix, watermark, temperature=record['temperature'], seed=record['profile']['seed'], **({'model': record['profile']} if record['profile'].get('underlying_model', 'DeepSeekR1') != 'DeepSeekR1' else {}))
                    step = result['step']
                    selected = step['selected_token_id']
                    emitted = token_text(step, selected)
                    record['answer'] += emitted
                    record['results'].append(result)
                    record.update(selected_step=index, selected_token_id=selected)
                    self.save(record)
                    if result.get('finish_reason') == 'stop':
                        break
                record['status'] = 'stopped' if record.get('stop_requested') else 'complete'
            except asyncio.CancelledError:
                record.update(status='interrupted', error='Service shutting down; submit the prompt again.')
                raise
            except Exception as error:
                record.update(status='error', error=str(error))
            finally:
                record.pop('stop_requested', None)
                self.save(record)

    async def close(self):
        tasks = list(self.tasks.values())
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


def register(app, root, registry, runtime, lock, require_idle, publish, *, forward_models=False):
    sessions = Sessions(root, registry, runtime, lock, require_idle, publish)
    app.state.ai_lab = sessions

    @app.get('/api/lab/health')
    def health():
        return {'application': 'ai-lab', 'api_version': API_VERSION, 'root': str(Path(root).resolve())}

    @app.get('/api/lab/schema')
    def schema():
        return app.openapi()

    @app.get('/api/lab/models')
    def models():
        from watermarks import SCHEMES
        from harness.generation_models import UNDERLYING_MODELS
        return {'models': [{'key': key, **value} for key, value in registry.supported_profiles().items()],
                'underlying_models': list(UNDERLYING_MODELS), 'watermark_schemes': SCHEMES}

    @app.post('/api/lab/models', status_code=201)
    async def add_model(body: ModelInput):
        sessions.idle()
        if forward_models:
            from ai_lab.coordination import website_model_write
            response = await website_model_write(root, 'POST', body=body.model_dump())
            if response is not None:
                return response
        async with lock:
            await require_idle()
            key, profiles = registry.added(body.name, body.seed, body.underlying_model, body.watermark)
            await publish(profiles)
            return {'key': key, **profiles[key]}

    @app.patch('/api/lab/models/{key}')
    async def update_watermark(key: str, body: WatermarkUpdateInput):
        sessions.idle()
        if forward_models:
            from ai_lab.coordination import website_model_write
            response = await website_model_write(root, 'PATCH', key=key, body=body.model_dump(exclude_none=True))
            if response is not None:
                return response
        async with lock:
            await require_idle()
            profiles = registry.watermarked(key, scheme=body.scheme, watermark_key=body.key, settings=body.settings, underlying_model=body.underlying_model)
            await publish(profiles)
            return {'key': key, **profiles[key]}

    @app.delete('/api/lab/models/{key}')
    async def delete_model(key: str):
        sessions.idle()
        if forward_models:
            from ai_lab.coordination import website_model_write
            response = await website_model_write(root, 'DELETE', key=key)
            if response is not None:
                return response
        async with lock:
            await require_idle()
            profiles = registry.removed(key)
            await publish(profiles)
            return {'removed': key}

    @app.get('/api/lab/sessions')
    def list_sessions():
        sessions.load()
        return [dict((k, r[k]) for k in ('id', 'name', 'model', 'status', 'revision', 'updated_at'))
                for r in sorted(sessions.records.values(), key=lambda r: r['updated_at'], reverse=True)]

    @app.post('/api/lab/sessions', status_code=201)
    async def create_session(body: SessionInput):
        return await sessions.create(body)

    @app.get('/api/lab/sessions/{session}')
    async def get_session(session: str, after: int = -1, timeout: float = 0):
        deadline = time.monotonic() + min(max(timeout, 0), 30)
        record = sessions.get(session)
        while record['revision'] <= after and time.monotonic() < deadline:
            await asyncio.sleep(.1)
        return public_session(record)

    @app.post('/api/lab/sessions/{session}/complete')
    async def complete(session: str, body: CompletionInput):
        sessions.idle()
        return await sessions.start(session, body)

    @app.post('/api/lab/sessions/{session}/select')
    async def select(session: str, body: SelectionInput):
        record = sessions.get(session)
        sessions.check_revision(record, body.expected_revision)
        if body.step >= len(record['results']):
            raise HTTPException(422, 'That step has no captured result.')
        step = record['results'][body.step]['step']
        token = step['selected_token_id'] if body.token_id is None else body.token_id
        token_text(step, token)
        layer = -1 if body.layer is None else body.layer
        if layer >= len(step.get('layers', [])):
            raise HTTPException(422, 'That probability round was not captured.')
        record.update(selected_step=body.step, selected_token_id=token, selected_layer=layer)
        sessions.save(record)
        return public_session(record)

    @app.post('/api/lab/sessions/{session}/append')
    async def append(session: str, body: AppendInput):
        sessions.idle()
        record = sessions.get(session)
        sessions.check_revision(record, body.expected_revision)
        if not record['results']:
            raise HTTPException(422, 'Inspect a prefix before appending a token.')
        index = record['selected_step']
        result = record['results'][index]
        prefix = result['prompt'] + token_text(result['step'], record['selected_token_id'])
        return await sessions.start(session, CompletionInput(prompt=prefix, expected_revision=body.expected_revision), position=record['position'] + index + 1)

    @app.post('/api/lab/sessions/{session}/stop')
    async def stop(session: str):
        record = sessions.get(session)
        if record['status'] == 'running':
            # Finish the in-flight native decision before releasing the model lock.
            record['stop_requested'] = True
            sessions.save(record)
        return public_session(record)

    return sessions


def create_app(root, runtime=None):
    root = Path(root).resolve()
    from model_profiles import ModelProfiles
    from watermark_runtime import WatermarkRuntime
    registry = ModelProfiles(root)
    if not registry.path.exists():
        atomic_json(registry.path, {'version': 1, 'models': []})
    async def idle():
        return None
    async def publish(profiles):
        atomic_json(registry.path, registry.document(profiles))
    @asynccontextmanager
    async def lifespan(app):
        yield
        await app.state.ai_lab.close()
    app = FastAPI(title='AI Lab', version='1.0', lifespan=lifespan)
    @app.middleware('http')
    async def local_only(request: Request, call_next):
        if request.method not in {'GET', 'HEAD', 'OPTIONS'} and request.headers.get('origin'):
            return JSONResponse({'detail': 'Browser writes are not accepted by the private AI Lab service.'}, status_code=403)
        return await call_next(request)
    @app.exception_handler(ValueError)
    async def invalid(request, error):
        return JSONResponse({'detail': str(error)}, status_code=422)
    from ai_lab.coordination import WorkspaceLock
    register(app, root, registry, runtime or WatermarkRuntime(), WorkspaceLock(root), idle, publish, forward_models=True)
    return app
