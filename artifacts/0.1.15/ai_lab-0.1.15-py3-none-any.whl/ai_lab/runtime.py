"""Install the checksum-pinned native runtime without a compiler or Xcode."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request

from ai_lab.service import atomic_json
from ai_lab.download_ui import copy_download, phase


def descriptor():
    return json.loads(Path(__file__).with_name('runtime.json').read_text())


def decisions_descriptor():
    return json.loads(Path(__file__).with_name('decisions-runtime.json').read_text())


def decisions_sources(release):
    return {'runtime': {key: release[key] for key in ('repository', 'commit', 'features')},
            'watermark_library': release['watermark_library']}


def decisions_ready(root):
    override = os.environ.get('AI_LAB_DECISIONS_BINARY')
    if override:
        binary = Path(override).expanduser()
        return binary.is_file() and os.access(binary, os.X_OK)
    return published_decisions_ready(root)


def published_decisions_ready(root):
    """Verify the shipped native runtime independently of custom overrides."""
    try:
        release = decisions_descriptor()
        build = json.loads((Path(root) / '.runtime/decisions/build.json').read_text())
        binary = Path(root) / '.runtime/decisions/mistralrs'
        return (release.get('decision_support') is True and build.get('decision_support') is True
                and compatible(decisions_sources(release), build)
                and build['binary_sha256'] == release['binary_sha256']
                and os.access(binary, os.X_OK) and sha256(binary) == release['binary_sha256'])
    except (OSError, ValueError, KeyError, TypeError):
        return False


def install_decisions(root, release=None):
    root = Path(root)
    if os.environ.get('AI_LAB_DECISIONS_BINARY'):
        if not decisions_ready(root):
            raise ValueError('AI_LAB_DECISIONS_BINARY must point to an executable native CLM server. '
                             'Unset it to use the automatically installed Metal server.')
        return {'binary': str(Path(os.environ['AI_LAB_DECISIONS_BINARY']).expanduser()),
                'distribution': 'user-configured'}
    release = decisions_descriptor() if release is None else release
    if release.get('decision_support') is not True:
        raise ValueError('The published Contrastive runtime must include native CLM decision support.')
    return _install(root, release, decisions_sources(release), root / '.runtime/decisions',
                    root / '.runtime/decisions/build.json', 'Contrastive CLM Metal server',
                    decision=True)


def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def compatible(sources, release):
    return (sources['runtime']['repository'] == release['repository']
            and sources['runtime']['commit'] == release['commit']
            and sources['runtime']['features'] == release['features']
            and sources['watermark_library']['repository'] == release['watermark_library']['repository']
            and sources['watermark_library']['commit'] == release['watermark_library']['commit'])


def supported(release):
    version = tuple(int(n) for n in (platform.mac_ver()[0] or '0').split('.')[:2])
    minimum = tuple(int(n) for n in release['minimum_macos'].split('.')[:2])
    return platform.system() == 'Darwin' and platform.machine() == 'arm64' and version >= minimum


def install(root, release=None):
    release = descriptor() if release is None else release
    sources = json.loads((root / 'sources.json').read_text())
    if not compatible(sources, release):
        raise ValueError('No published runtime matches this custom source manifest. Use ai-lab weights --setup --build-from-source.')
    return _install(root, release, sources, root / '.runtime/mistral',
                    root / '.state/mistral-build.json', 'DeepSeek Metal server')


def _install(root, release, sources, parent, previous, label, *, decision=False):
    if not supported(release):
        raise ValueError(f"The published runtime requires Apple Silicon and macOS {release['minimum_macos']} or newer.")
    parent.mkdir(parents=True, exist_ok=True)
    try:
        build = json.loads(previous.read_text())
        if (compatible(sources, build) and build.get('distribution') == 'prebuilt'
                and (not decision or build.get('decision_support') is True)
                and build['binary'] == str(parent / 'mistralrs')
                and build['binary_sha256'] == release['binary_sha256']
                and os.access(Path(build['binary']), os.X_OK)
                and sha256(Path(build['binary'])) == release['binary_sha256']):
            return build
    except (OSError, ValueError, KeyError):
        pass
    with tempfile.TemporaryDirectory(prefix='.install-', dir=parent) as temporary:
        stage = Path(temporary)
        archive = stage / 'runtime.tar.gz'
        # HTTPS plus the hash shipped with the application pins the executable.
        if not release['url'].startswith('https://'):
            raise ValueError('The runtime download must use HTTPS.')
        request = urllib.request.Request(release['url'], headers={'User-Agent': 'AI-Lab'})
        with urllib.request.urlopen(request, timeout=60) as response, archive.open('wb') as target:
            copy_download(response, target, label, expected_size=release['bytes'],
                          size_error='Runtime download exceeds its pinned size.')
        phase(f'Verifying the {label}')
        if archive.stat().st_size != release['bytes'] or sha256(archive) != release['sha256']:
            raise ValueError('Runtime archive checksum mismatch. No runtime was replaced; retry ai-lab weights --setup --yes.')
        with tarfile.open(archive, 'r:gz') as tar:
            # Extract only known regular files, never archive paths or links.
            for name in ('mistralrs', 'build.json', 'LICENSE-mistral',
                         'LICENSE-llm_watermarking', 'THIRD_PARTY_NOTICES.txt'):
                members = [m for m in tar.getmembers() if m.name == name]
                if len(members) != 1 or not members[0].isfile():
                    raise ValueError(f'Invalid runtime archive entry: {name}')
                with tar.extractfile(members[0]) as source, (stage / name).open('wb') as target:
                    shutil.copyfileobj(source, target)
        build = json.loads((stage / 'build.json').read_text())
        if not compatible(sources, build) or build['binary_sha256'] != release['binary_sha256']:
            raise ValueError('Runtime provenance does not match the pinned forks.')
        if decision and build.get('decision_support') is not True:
            raise ValueError('Runtime archive has no native CLM decision support.')
        binary = stage / 'mistralrs'
        if sha256(binary) != release['binary_sha256']:
            raise ValueError('Runtime binary checksum mismatch.')
        binary.chmod(0o755)
        version = subprocess.check_output([str(binary), '--version'], text=True).strip()
        if version != release['version']:
            raise ValueError('Runtime version does not match its release.')
        binary.replace(parent / 'mistralrs')
        for name in ('LICENSE-mistral', 'LICENSE-llm_watermarking', 'THIRD_PARTY_NOTICES.txt'):
            (stage / name).replace(parent / name)
        build.update(binary=str(parent / 'mistralrs'), distribution='prebuilt',
                     archive_sha256=release['sha256'], download_url=release['url'])
        atomic_json(previous, build)
        phase(f'{label} ready')
    return build
