"""Web launcher, MCP integration, and explicit model setup."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

from ai_lab import __version__
from ai_lab.client import LabError
from ai_lab.paths import root_path

SKILL = '''# AI Lab web and MCP guide

Public commands are web, mcp, and setup. `ai-lab` or `ai-lab --help` prints
help; `ai-lab --json` discovers the complete public command surface.
`ai-lab --completions bash|zsh|fish` prints offline shell completion scripts.
Long flags require their full spellings.

`ai-lab web` opens Completion. The website also provides saved Models, Decisions
(native CLM and hosted Jev), and Decoder. `--browser` opens a regular browser tab;
`--no-browser` prints the URL and `--port` selects a loopback port.
Starting the website starts both DeepSeek and native CLM APIs using installed
weights. Both APIs stay running for the web process lifetime, including while
idle or switching pages/models; CLM remains available to Python clients.
Opening the website does not download models. Ctrl+C stops processes owned by that website launch; existing
foreign APIs and saved user data are preserved.

`ai-lab setup` or `ai-lab setup list --json` lists DeepSeek and native CLM
installation status. `ai-lab setup --doctor --json` reports prerequisites.
`ai-lab setup install deepseek --yes` explicitly downloads and verifies DeepSeek weights
and its runtime. `setup download` and `setup repair` accept the same model
selectors: deepseek, clm. `--model deepseek` is also accepted; `--with-models`
selects all supported local backends. Installation defaults to both when no
model is selected. `setup repair-runtime --model deepseek --yes` repairs only the
selected runtime without downloading weights. `--yes` is required for installation/repair; there is no
terminal application or keyboard picker. Compatible verified weights are reused,
partial downloads can resume, and model setup preserves saved profiles and data.

`ai-lab mcp install --codex` configures client-launched stdio tools; supported
clients also include --claude, --claude-desktop, --cursor, and --opencode.
`mcp config --codex --json` prints a reviewable configuration. `--scope project`,
`--config-file`, `--package`, and `--force` control installation. Other client
settings are preserved and replaced configs are backed up. `mcp serve` runs the
JSON-RPC stdio server. Model operations automatically start the selected installed
local backend, reuse compatible weights, and report a setup action when needed;
there are no manual service commands or implicit downloads. Read-only model lists
and configuration do not load native models. Closing MCP stops only its owned
backend processes. No interactive terminal app is involved.

`--root` or AI_LAB_ROOT selects the data root; AI_LAB_HOME configures the installed
default. Successful JSON output goes to stdout, structured errors to stderr.
Usage errors exit 2, request errors exit 1, and cancellation exits 130.
'''


class Parser(argparse.ArgumentParser):
    def __init__(self, *args, **kwargs):
        # Child command parsers use this class too; explicit flags must never
        # normalize from an abbreviation that bypasses a pre-dispatch guard.
        kwargs['allow_abbrev'] = False
        super().__init__(*args, **kwargs)

    def _check_value(self, action, value):
        # Keep invalid-command suggestions aligned with discovery.
        if (isinstance(action, argparse._SubParsersAction) and hasattr(action, 'public_names')
                and value not in action.choices):
            choices = ', '.join(action.public_names)
            raise argparse.ArgumentError(action, f'invalid choice: {value!r} (choose from {choices})')
        return super()._check_value(action, value)

    def parse_args(self, args=None, namespace=None):
        args = list(sys.argv[1:] if args is None else args)
        def configure(parser):
            parser.json_errors = '--json' in args
            for action in parser._actions:
                if isinstance(action, argparse._SubParsersAction):
                    for child in action.choices.values():
                        configure(child)
        configure(self)
        return super().parse_args(args, namespace)

    def error(self, message):
        if getattr(self, 'json_errors', False):
            print(json.dumps({'ok': False, 'error': {'code': 'usage', 'message': message, 'status': None}}), file=sys.stderr)
            raise SystemExit(2)
        super().error(message)


PUBLIC_COMMANDS = ('web', 'mcp', 'setup')
SETUP_MODELS = ('deepseek', 'clm')


def parser():
    p = Parser(prog='ai-lab', description='AI Lab · Completion, Decisions, and Decoder on the web.',
               epilog='Open the app: ai-lab web\nInstall a model: ai-lab setup install deepseek --yes\nGuide: ai-lab --skill | ai-lab --json',
               formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--root', help='Workspace containing models and runtime (or AI_LAB_ROOT)')
    p.add_argument('--json', action='store_true', help='Structured output; errors are JSON on stderr')
    p.add_argument('--version', action='version', version=f'AI Lab {__version__}')
    p.add_argument('--skill', action='store_true', help='Print the integration guide')
    p.add_argument('--completions', choices=('bash', 'zsh', 'fish'), help='Print an offline shell completion script')
    sub = p.add_subparsers(dest='command')
    def command(group, name, help):
        q = group.add_parser(name, help=help, description=help)
        q.add_argument('--json', action='store_true', default=argparse.SUPPRESS)
        return q
    w = command(sub, 'web', 'Open the website and keep DeepSeek and CLM APIs running')
    w.add_argument('--port', type=int, default=8080, help='Local website port (default: 8080)')
    launch = w.add_mutually_exclusive_group()
    launch.add_argument('--browser', action='store_true', help='Open a regular tab in your default browser')
    launch.add_argument('--no-browser', action='store_true', help='Print the URL without opening an app or browser')
    # Old launch scripts remain valid; setup/downloads now belong to setup only.
    for flag in ('yes', 'with-models', 'no-models', 'no-setup'):
        w.add_argument('--' + flag, action='store_true', help=argparse.SUPPRESS)
    mcp = command(sub, 'mcp', 'Configure client-launched stdio MCP tools using uvx')
    mcps = mcp.add_subparsers(dest='action', required=True)
    for action in ('install', 'config'):
        target = command(mcps, action, 'Install MCP into a target client' if action == 'install' else 'Print a reviewable uvx client configuration')
        clients = target.add_mutually_exclusive_group(required=True)
        for client in ('codex', 'claude', 'claude-desktop', 'cursor', 'opencode'):
            clients.add_argument('--' + client, dest='mcp_client', action='store_const', const=client)
        target.add_argument('--scope', choices=['user', 'project'], default='user', help='Client configuration scope (default: user)')
        target.add_argument('--config-file', help='Use an explicit client configuration file')
        target.add_argument('--package', help='Override the uvx --from package; default a private snapshot of this installed CLI')
        target.add_argument('--force', action='store_true', help='Replace a differing ai-lab entry; preserve other client settings')
    command(mcps, 'serve', 'Run MCP on stdio (normally launched by the target client through uvx)')
    s = command(sub, 'setup', 'List installation status, or explicitly download and repair supported local models')
    s.add_argument('action', nargs='?', choices=('list', 'install', 'download', 'repair', 'repair-runtime', 'doctor'), help='Default: list; install/download/repair default to all supported models')
    s.add_argument('models', nargs='*', metavar='MODEL', help='One or more of: deepseek, clm')
    s.add_argument('--model', dest='selected_models', action='append', choices=SETUP_MODELS, help='Select a local model; may be repeated')
    s.add_argument('--with-models', action='store_true', help='Select all supported local models')
    s.add_argument('--doctor', action='store_true', help='Inspect platform and runtime prerequisites')
    s.add_argument('--yes', action='store_true', help='Accept explicit model/runtime downloads and repairs')
    sub.public_names = PUBLIC_COMMANDS
    return p


def discovery(p):
    data = {'description': p.description, 'options': [], 'commands': {}}
    for action in p._actions:
        if isinstance(action, argparse._SubParsersAction):
            data['commands'] = {name: discovery(child) for name, child in action.choices.items()}
        elif action.help != argparse.SUPPRESS:
            data['options'].append({'flags': action.option_strings or [action.dest], 'required': action.required,
                                    'choices': action.choices, 'help': action.help})
    return data


def read_file(path):
    return sys.stdin.read() if path == '-' else Path(path).read_text(encoding='utf-8')


def json_file(path):
    return json.loads(read_file(path)) if path else None


def output(value, structured=False):
    if structured:
        print(json.dumps(value, ensure_ascii=False, indent=2))
    elif isinstance(value, str):
        print(value)
    else:
        from rich.console import Console
        from rich.table import Table
        console = Console()
        rows = value.get('models') if isinstance(value, dict) and 'models' in value else value
        if isinstance(rows, list) and rows and isinstance(rows[0], dict):
            keys = [k for k in ('key', 'id', 'name', 'underlying_model', 'status', 'seed_literal') if k in rows[0]]
            if keys:
                table = Table(*keys, title='AI Lab', border_style='blue')
                for row in rows:
                    table.add_row(*[str(row.get(k) if row.get(k) is not None else 'default') for k in keys])
                console.print(table)
                return
        console.print_json(json.dumps(value, ensure_ascii=False))


def shell_completion(shell):
    commands = ' '.join(PUBLIC_COMMANDS)
    flags = '--help --json --root --version --skill --completions'
    if shell == 'bash':
        return '''_ai_lab() {
  local cur="${COMP_WORDS[COMP_CWORD]}" word command="" choices
  for word in "${COMP_WORDS[@]:1}"; do
    case "$word" in web|mcp|setup) command="$word"; break ;; esac
  done
  case "$command" in
    web) choices="--port --browser --no-browser --json --help" ;;
    mcp) choices="install config serve --codex --claude --claude-desktop --cursor --opencode --scope --config-file --package --force --json --help" ;;
    setup) choices="list install download repair repair-runtime doctor deepseek clm --model --with-models --doctor --yes --json --help" ;;
    *) choices="''' + commands + ' ' + flags + '''" ;;
  esac
  COMPREPLY=( $(compgen -W "$choices" -- "$cur") )
}
complete -F _ai_lab ai-lab
'''
    if shell == 'zsh':
        return '''#compdef ai-lab
_ai_lab() {
  local word command=""
  local -a choices
  for word in "${words[@]:1}"; do
    case "$word" in web|mcp|setup) command="$word"; break ;; esac
  done
  case "$command" in
    web) choices=(--port --browser --no-browser --json --help) ;;
    mcp) choices=(install config serve --codex --claude --claude-desktop --cursor --opencode --scope --config-file --package --force --json --help) ;;
    setup) choices=(list install download repair repair-runtime doctor deepseek clm --model --with-models --doctor --yes --json --help) ;;
    *) choices=(''' + commands + ' ' + flags + ''') ;;
  esac
  compadd -- "${choices[@]}"
}
compdef _ai_lab ai-lab
'''
    if shell != 'fish':
        raise ValueError('Choose bash, zsh, or fish.')
    return '''complete -c ai-lab -f
complete -c ai-lab -n 'not __fish_seen_subcommand_from ''' + commands + '''' -a '''' + commands + ''''
complete -c ai-lab -n '__fish_seen_subcommand_from setup' -a 'list install download repair repair-runtime doctor deepseek clm'
complete -c ai-lab -n '__fish_seen_subcommand_from mcp' -a 'install config serve'
complete -c ai-lab -n '__fish_seen_subcommand_from web' -l port -r
complete -c ai-lab -n '__fish_seen_subcommand_from web' -l browser
complete -c ai-lab -n '__fish_seen_subcommand_from web' -l no-browser
complete -c ai-lab -n '__fish_seen_subcommand_from setup' -l model -r -a 'deepseek clm'
complete -c ai-lab -n '__fish_seen_subcommand_from setup' -l with-models
complete -c ai-lab -n '__fish_seen_subcommand_from setup' -l doctor
complete -c ai-lab -n '__fish_seen_subcommand_from setup' -l yes
complete -c ai-lab -l root -r -a '(__fish_complete_directories)'
complete -c ai-lab -l json
complete -c ai-lab -l help
'''


def setup_operation(args, root):
    from ai_lab.downloads import install, status
    selected = list(dict.fromkeys([*args.models, *(args.selected_models or [])]))
    if any(model not in SETUP_MODELS for model in selected):
        raise ValueError('Choose supported local models: deepseek, clm.')
    if args.with_models:
        if selected:
            raise ValueError('Choose --with-models or explicit model selectors, not both.')
        selected = list(SETUP_MODELS)
    action = args.action or ('install' if args.yes else 'list')
    if args.doctor:
        if args.action not in (None, 'doctor') or selected or args.yes:
            raise ValueError('--doctor is a read-only prerequisite check; omit other setup actions and model selectors.')
        action = 'doctor'
    if action == 'doctor':
        if selected or args.yes:
            raise ValueError('Doctor is a read-only prerequisite check; omit model selectors and --yes.')
        from ai_lab.setup import doctor
        return doctor(root)
    if action == 'list':
        if args.yes:
            raise ValueError('Listing does not install models. Use setup install MODEL --yes.')
        return status(root, models=tuple(selected or SETUP_MODELS))
    if not args.yes:
        raise ValueError('Model downloads and repairs need --yes. Inspect ai-lab setup list --json first.')
    if action == 'repair-runtime':
        if not selected:
            raise ValueError('Runtime repair requires --model deepseek or --model clm.')
        from ai_lab.downloads import missing_weights_message
        from ai_lab.setup import repair_generation_runtime
        from ai_lab.runtime import install_decisions
        # Validate every selected weight set before changing any runtime. Runtime
        # repair never converts a missing-weight state into an implicit download.
        rows = status(root, models=tuple(selected))
        for row in rows:
            if not row['weights_present']:
                raise ValueError(missing_weights_message(root, row['name'], row))
        repairs = {}
        for name in selected:
            if name == 'clm':
                row = next(row for row in rows if row['name'] == name)
                repairs[name] = ({'repaired': False, 'reason': 'runtime-ready'} if row['dependencies_ready']
                                 else {'repaired': True, 'build': install_decisions(root)})
            else:
                repairs[name] = repair_generation_runtime(root, name)
        return {'root': str(root), 'runtimes': repairs}
    # The shared installer verifies existing files before downloading and handles
    # interrupted installs and runtime repair without replacing verified weights.
    return install(root, selected or list(SETUP_MODELS), yes=True)


def main(argv=None):
    p = parser()
    args = p.parse_args(argv)
    try:
        if args.skill:
            print(SKILL)
            return 0
        if args.completions:
            print(shell_completion(args.completions), end='')
            return 0
        if args.command is None:
            output(discovery(p), True) if args.json else p.print_help()
            return 0
        root = root_path(args.root)
        if args.command == 'setup':
            output(setup_operation(args, root), args.json)
            return 0
        if args.command == 'web':
            from ai_lab.web import run
            return run(root, args.port, args.no_browser, False, True, args.json, browser=args.browser)
        if args.action == 'serve':
            if args.json:
                raise ValueError('MCP serve uses JSON-RPC on stdio; omit --json.')
            from ai_lab.mcp_server import main as serve_mcp
            return serve_mcp(['--root', str(root)])
        from ai_lab.mcp_install import configure
        value = configure(root, args.mcp_client, config_file=args.config_file, scope=args.scope,
                          package=args.package, force=args.force, dry_run=args.action == 'config')
        output(value, args.json)
        return 0
    except (LabError, ValueError, OSError, subprocess.CalledProcessError) as error:
        if args.json:
            print(json.dumps({'ok': False, 'error': {'code': getattr(error, 'code', 'invalid_request'), 'message': str(error), 'status': getattr(error, 'status', None)}}), file=sys.stderr)
        else:
            print(f'AI Lab: {error}', file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        message = ('Partial downloads are kept; repeat the same setup command to resume.'
                   if args.command == 'setup' else 'Saved models, settings, and sessions are preserved.')
        print(f'AI Lab: interrupted. {message}', file=sys.stderr)
        return 130
