"""AI Lab: local completions, decisions, and watermark inspection on the web."""
__version__ = '0.1.15'
