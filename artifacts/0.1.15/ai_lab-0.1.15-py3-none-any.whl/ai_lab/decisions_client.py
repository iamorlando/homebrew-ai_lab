"""Async HTTP adapter for the existing Decisions routes, with startup disabled."""
from dataclasses import dataclass
import os
from pathlib import Path
import time

from fastapi import FastAPI
import httpx

from ai_lab.credentials import jev_key
from ai_lab.decisions_request import shared_api, validate_request
from ai_lab.paths import load_backend


class DecisionError(ValueError):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


@dataclass(frozen=True)
class DecisionResult:
    body: dict
    latency_ms: float | None
    round_trip_ms: float


class DecisionsClient:
    def __init__(self, root, *, runtime=None, transport=None):
        self.root = Path(root).resolve()
        load_backend(self.root)
        api = shared_api()
        self.runtime = runtime or api.DecisionRuntime(self.root, transport=transport, allow_start=False)
        if self.runtime.allow_start:
            raise ValueError('The Decisions terminal requires model startup disabled.')
        self.app = FastAPI()
        api.register_decisions(self.app, lambda _: '', self.root, self.runtime)
        self.closed = False

    def redact(self, value):
        """Protect against provider errors or metadata accidentally echoing a key."""
        secrets = {jev_key(self.root)}
        for key in ('AI_LAB_DECISIONS_API_KEY', 'AI_LAB_CLM_UPSTREAM_API_KEY', 'AI_LAB_LAYA_API_KEY',
                    'JEV_API_KEY', 'TYPESAFE_API_KEY'):
            secrets.add(os.environ.get(key, '').strip())
        secrets.discard('')

        def clean(item):
            if isinstance(item, str):
                for secret in sorted(secrets, key=len, reverse=True):
                    item = item.replace(secret, '[redacted]')
                return item
            if isinstance(item, list):
                return [clean(child) for child in item]
            if isinstance(item, dict):
                return {clean(key): clean(child) for key, child in item.items()}
            return item
        return clean(value)

    async def _request(self, method, path, body=None):
        if self.closed:
            raise DecisionError('Decisions client is closed.')
        started = time.monotonic()
        try:
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=self.app),
                                        base_url='http://decisions.internal', trust_env=False) as client:
                response = await client.request(method, path, json=body)
            data = self.redact(response.json())
        except (httpx.HTTPError, ValueError):
            raise DecisionError('The Decisions API returned an unreadable response. Refresh providers and retry explicitly.') from None
        if response.is_error:
            detail = data.get('detail', 'Decision request failed.')
            if isinstance(detail, list):
                # FastAPI validation responses can include full submitted data.
                detail = '; '.join('.'.join(map(str, issue.get('loc', ()))) + ': ' + issue.get('msg', 'invalid')
                                   for issue in detail)
            raise DecisionError(str(detail), response.status_code)
        latency = response.headers.get('X-Decision-Latency-Ms')
        return DecisionResult(data, float(latency) if latency is not None else None,
                              (time.monotonic() - started) * 1000)

    async def discover(self):
        return (await self._request('GET', '/api/decisions/models')).body['models']

    async def submit(self, mode, body):
        # Shared validation before routing also protects callers outside the UI.
        body = validate_request(mode, body)
        return await self._request('POST', '/api/decisions/' + ('rank' if mode == 'rank' else 'systemone'), body)

    async def aclose(self):
        if not self.closed:
            self.closed = True
            await self.runtime.close()
