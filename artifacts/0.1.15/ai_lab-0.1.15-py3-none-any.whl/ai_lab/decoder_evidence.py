"""Presentation parity with harness/ui/decoder-evidence.mjs; no detector scoring."""
from copy import deepcopy
import math
import re

CONFIDENCE_DEFINITION = ('1 - p_value from a known-key test or conservative bound against unwatermarked text; '
                         'not a posterior probability of authorship.')
NATIVE_FIELDS = ('mean_g_value', 'z_score', 'mean_cost', 'green_count', 'green_fraction', 'trials', 'votes')


def probability(value):
    return type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1


def numeric(value):
    return (type(value) in (int, float) and math.isfinite(value) or
            isinstance(value, list) and len(value) <= 1024 and all(numeric(item) for item in value))


def present(result, profile, scheme):
    if not isinstance(result, dict) or any(result.get(key) != expected for key, expected in
            (('profile_key', profile['id']), ('underlying_model', profile['underlying_model']), ('scheme', scheme))):
        raise ValueError('The profile model or scheme changed. Reload profiles and decode again.')
    n, minimum, threshold = (result.get(key) for key in ('tokens_scored', 'min_tokens', 'p_value_threshold'))
    if (result.get('verdict') not in ('match', 'no_match', 'insufficient') or type(n) is not int or not 0 <= n <= 9007199254740991
            or type(minimum) is not int or not 1 <= minimum <= 9007199254740991 or not probability(threshold) or threshold == 0):
        raise ValueError('The detector returned invalid evidence.')
    p, confidence = result.get('p_value'), result.get('confidence')
    if any(value is not None and not probability(value) for value in (p, confidence)):
        raise ValueError('The detector returned invalid evidence.')
    if p is not None and confidence is not None and abs(confidence - (1 - p)) > 1e-10:
        raise ValueError('The detector returned inconsistent confidence.')
    insufficient = result['verdict'] == 'insufficient' or n < minimum or p is None or confidence is None
    if not insufficient:
        passes = p <= threshold
        if (result['verdict'] == 'match') != passes or ('matches' in result and result['matches'] is not passes):
            raise ValueError('The detector returned a verdict inconsistent with its p-value cutoff.')
    elif result.get('matches') is True:
        raise ValueError('The detector returned a match without sufficient evidence.')
    verdict = 'insufficient' if insufficient else result['verdict']
    stats = result.get('stats') if isinstance(result.get('stats'), dict) else {}
    public = {'profile_key': profile['id'], 'model': profile['name'], 'underlying_model': profile['underlying_model'],
              'scheme': scheme, 'verdict': verdict, 'matches': verdict == 'match',
              'tokens_scored': n, 'min_tokens': minimum, 'p_value_threshold': threshold,
              'p_value': None if insufficient else p, 'confidence': None if insufficient else confidence,
              'strength': result.get('strength') if numeric(result.get('strength')) and not isinstance(result.get('strength'), list) else None,
              'method': result.get('method') if isinstance(result.get('method'), str) else 'No valid known-key test',
              'confidence_definition': CONFIDENCE_DEFINITION,
              'stats': {key: deepcopy(stats[key]) for key in NATIVE_FIELDS if numeric(stats.get(key))}}
    if result.get('fixture') is True:
        public['fixture'] = True
    return public


def redacted(value, key=''):
    """Sanitize ordinary copy/raw views, including echoed keys in strings."""
    if isinstance(value, dict):
        return {name: '[private key]' if name == 'key' else redacted(child, key) for name, child in value.items()}
    if isinstance(value, list):
        return [redacted(child, key) for child in value]
    if isinstance(value, str):
        if key:
            value = value.replace(key, '[private key]')
        return re.sub(r'(?i)(?<![0-9a-f])[0-9a-f]{64}(?![0-9a-f])', '[private key]', value)
    return value


def p_label(value):
    return 'Unavailable' if value is None else '<1e-300' if value == 0 else f'{value:.3e}' if value < .001 else f'{value:.6f}'


def confidence_label(value):
    return 'Unavailable' if value is None else '>99.9999%' if value > .999999 else f'{value * 100:.4f}%'
