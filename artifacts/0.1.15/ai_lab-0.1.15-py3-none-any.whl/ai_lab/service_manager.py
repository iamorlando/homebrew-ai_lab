"""Saved-profile-aware, foreground supervision of existing inference APIs.

Opening discovers only. Native startup stays in ModelServers / DecisionRuntime;
this module adds conservative ownership checks and foreground supervision.
"""
import argparse
import asyncio
from dataclasses import dataclass
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import sys
import time
import uuid

from rich.text import Text

from ai_lab.herdr import HerdrReporter
from ai_lab import decision_processes
from ai_lab.decision_processes import process_fingerprint

LOCAL = ('deepseek', 'qwen', 'contrastive', 'laya')
ACTIONS = ('start', 'stop', 'restart', 'interrupt')
STOP_SECONDS = 10
SHUTDOWN_ACK_SECONDS = 2
SHUTDOWN_ACK_TTL = 60
SHUTDOWN_ACK_LIMIT = 32
SHUTDOWN_ACK_BYTES = 16384
SLOTS = {
    'deepseek': ('deepseek_process', 'deepseek_log'),
    'qwen': ('qwen_process', 'qwen_log'),
    'contrastive': ('process', 'log'),
    'clm-upstream': ('upstream_process', 'upstream_log'),
    'laya': ('laya_process', 'laya_log'),
}
LOGS = {'deepseek': 'mistral-server.log', 'qwen': 'qwen-server.log',
        'contrastive': 'decisions-mistral.log', 'clm-upstream': 'clm-upstream.log',
        'laya': 'laya.log'}


class ServiceError(ValueError):
    """Only controlled, nonprivate messages cross the terminal/JSON boundary."""


@dataclass(frozen=True)
class Identity:
    pid: int
    fingerprint: str
    state: dict | None = None


def _pid_exists(pid):
    """A changed command/group is not evidence that this PID's lifetime ended."""
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    return True  # Permission/inspection failures propagate, never prove exit.


def endpoint_available(endpoint):
    from urllib.parse import urlsplit
    import socket
    parsed = urlsplit(endpoint)
    with socket.socket(socket.AF_INET6 if ':' in parsed.hostname else socket.AF_INET) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind((parsed.hostname, parsed.port or 80))
            return True
        except OSError:
            return False


def safe_workspace(root):
    """Do not let existing preparation write through foreign storage links."""
    for name in ('.state', '.state/ai-lab', 'harness', 'harness/models.json',
                 'sources.json', 'deepseek-chat.jinja', 'qwen-chat.jinja', 'offline.sb'):
        path = root / name
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ServiceError('Workspace configuration/state links require manual review. '
                               'Choose a workspace with its own state and saved profiles using --root.')


def profile_rows(profiles):
    """Project only the fields a manager needs; private settings never leave."""
    from harness.generation_models import generation_backend
    return [{'key': key, 'name': value['name'], 'service': generation_backend(value).family,
             'underlying_model': generation_backend(value).underlying_model,
             'watermark_enabled': bool(value.get('watermark')),
             'scheme': (value.get('watermark') or {}).get('scheme') or 'off'}
            for key, value in profiles.items()]


def select_service(inventory, *, name=None, model=None):
    if name is not None:
        matches = [row for row in inventory['profiles'] if row['name'] == name]
        if len(matches) != 1:
            raise ServiceError('The exact saved generation name was not found. Open ai-lab models '
                               'to inspect names, then retry with --name (case-sensitive).')
        return matches[0]['service']
    if model is not None:
        if model not in (*LOCAL, 'jev') or model not in {row['name'] for row in inventory['services']}:
            raise ServiceError('That API/provider is not available in this workspace.')
        return model
    raise ServiceError('A scripted service action needs --name EXACT_SAVED_NAME or --model BACKEND.')


class NativeServices:
    """Single-loop controller; never delegates unchecked cleanup to ModelServers.close."""
    def __init__(self, root, *, repair_runtime=True):
        self.root = Path(root).resolve()
        self.repair_runtime = repair_runtime
        self.manager = None
        self.decision_managers = {}
        self.created = {}
        self.pending = {}
        self.native_origin = None
        self.lock = asyncio.Lock()

    async def _initialize(self):
        if self.manager is not None:
            return
        safe_workspace(self.root)
        loaded = sys.modules.get('inference')
        if loaded is not None and Path(loaded.ROOT).resolve() != self.root:
            raise ServiceError('Native routing is already bound to another workspace. '
                               'Run a fresh ai-lab process with the selected --root.')
        from ai_lab.model_servers import ModelServers
        self.manager = await asyncio.to_thread(ModelServers, self.root)
        import inference
        if Path(inference.ROOT).resolve() != self.root:
            # Native modules have process-global root routing. Never act at a different root.
            self.manager = None
            raise ServiceError('Native routing is already bound to another workspace. '
                               'Run a fresh ai-lab process with the selected --root.')

    def _holder(self, name):
        return self.manager if name in {'deepseek', 'qwen'} else self.decision_managers.get(name, self.manager).decisions

    def _process(self, name):
        return getattr(self._holder(name), SLOTS[name][0], None)

    def _generation_identity(self, name):
        import inference
        saved = inference.owned_state(name)
        if saved and (fingerprint := process_fingerprint(saved['pid'])):
            return Identity(saved['pid'], fingerprint, saved)
        return None

    def _identity(self, name):
        if name in {'deepseek', 'qwen'}:
            return self._generation_identity(name)
        if name in {'contrastive', 'laya'}:
            if saved := decision_processes.owned_state(self.root, process_fingerprint, family=name):
                return Identity(saved['pid'], saved['fingerprint'], saved)
        identity = self.created.get(name)
        process = self._process(name)
        if (identity and process and process.pid == identity.pid and process.returncode is None
                and process_fingerprint(identity.pid) == identity.fingerprint):
            return identity
        if name == 'contrastive':
            endpoint = getattr(self.manager.decisions, 'url', os.environ.get('AI_LAB_DECISIONS_URL', 'http://127.0.0.1:11436'))
            if saved := decision_processes.native_state(self.root, endpoint, process_fingerprint):
                return Identity(saved['pid'], saved['fingerprint'], saved)
        return None

    def _capture(self, name):
        """Read identity only; worker threads never register ownership receipts."""
        process = self._process(name)
        if not process or process.returncode is not None:
            return None
        if name in {'deepseek', 'qwen'}:
            identity = self._generation_identity(name)
            expected = getattr(self.manager, name + '_state', None)
            if not identity or identity.pid != process.pid or identity.state != expected:
                return None
        else:
            fingerprint = process_fingerprint(process.pid)
            if not fingerprint:
                return None
            origin = Path(getattr(self._holder(name), 'root', self.root)).resolve()
            saved = decision_processes.owned_state(origin, process_fingerprint, family=name) if name in {'contrastive', 'laya'} else None
            identity = Identity(process.pid, fingerprint, saved if saved and saved['pid'] == process.pid else None)
        return identity

    async def _capture_created(self, name, process):
        identity = await asyncio.to_thread(self._capture, name)
        # Registration happens on the event loop, under the caller's operation
        # lock. A result can apply only to the exact handle that began capture.
        if (identity and self._process(name) is process and process.returncode is None
                and identity.pid == process.pid):
            self.created[name] = identity
            if self.pending.get(name) is process:
                self.pending.pop(name)
            return identity
        return None

    @staticmethod
    async def _settle(task):
        """Defer repeated caller cancellation until an ownership phase finishes."""
        while True:
            try:
                return await asyncio.shield(task)
            except asyncio.CancelledError:
                if task.done():
                    return task.result()

    async def snapshot(self):
        async with self.lock:
            try:
                await self._initialize()
                from ai_lab.model_servers import available_models
                from model_profiles import ModelProfiles
                # Existing discovery verifies files and probes only local APIs. Keep disk
                # verification off the UI loop; the discovery loop has no launch tasks.
                rows = await asyncio.to_thread(lambda: asyncio.run(available_models(self.root)))
                profiles = await asyncio.to_thread(lambda: ModelProfiles(self.root).profiles())
                result = []
                for source in rows:
                    name = source['name']
                    if name not in (*LOCAL, 'jev'):
                        # Keep legacy adapters available internally without
                        # offering them as managed inference servers here.
                        continue
                    if not source['local']:
                        result.append({'name': name, 'label': source['label'], 'status': 'hosted',
                                       'ownership': 'hosted', 'endpoint': source['endpoint'],
                                       'detail': 'Hosted provider; no local start/stop. '
                                                 + ('Configured.' if source['configured'] else 'Set TYPESAFE_API_KEY or JEV_API_KEY before opening ai-lab web.'),
                                       'actions': dict.fromkeys(ACTIONS, False)})
                        continue
                    identity = await asyncio.to_thread(self._identity, name)
                    process = self._process(name)
                    active = bool(source['running'])
                    if name in {'deepseek', 'qwen'}:
                        import inference
                        occupied = not await asyncio.to_thread(inference.port_available, name)
                    elif name == 'contrastive':
                        occupied = not await asyncio.to_thread(decision_processes.port_available, source['endpoint'])
                    else:
                        occupied = not await asyncio.to_thread(endpoint_available, source['endpoint'])
                    custom_endpoint = name == 'laya' and not self.manager.decisions.laya_managed
                    origin = self.root
                    if name == 'contrastive':
                        if identity and identity.state:
                            self.native_origin = Path(identity.state['root'])
                        origin = self.native_origin or self.root
                    if name == 'contrastive' and origin != self.root:
                        from ai_lab.downloads import status as download_status
                        from ai_lab.runtime import decisions_ready
                        weights = (await asyncio.to_thread(download_status, origin, models=('clm',)))[0]
                        source = {**source, 'weights_present': bool(weights['weights_present']),
                                  'installed': bool(weights['weights_present']) and await asyncio.to_thread(decisions_ready, origin),
                                  'missing_bytes': weights['missing_bytes']}
                    if identity:
                        stale = (name in {'contrastive', 'laya'} and identity.state is not None
                                 and not decision_processes.launch_matches(identity.state, origin, source['endpoint'], family=name))
                        status = 'running' if active and not stale else 'stale / not ready'
                        ownership = 'this manager' if self.created.get(name) == identity else 'workspace'
                    elif occupied or active or custom_endpoint or (process and process.returncode is None):
                        status = ('running' if active else 'configured API unavailable' if custom_endpoint
                                  else 'external / identity unverified')
                        ownership = 'external'
                    else:
                        status = 'stopped' if source['installed'] else (
                            'runtime setup required' if source.get('weights_present') else 'weights missing')
                        ownership = 'none'
                    repair = name in LOCAL and bool(source.get('weights_present'))
                    ready = bool(source['installed'] or repair)
                    detail = ('All saved profiles on this backend share one API. Profile generation '
                              'and watermark settings are applied by each request. '
                              if name in {'deepseek', 'qwen'} else 'Decision provider API. ')
                    if name == 'contrastive' and identity:
                        detail += f'Verified native CLM from {origin}. '
                        if identity.state and identity.state.get('recovered'):
                            detail += 'Recovered the legacy launcher identity without changing its process or writing a receipt. '
                    if ownership == 'external':
                        if active:
                            detail += 'The API is running and available for inference. '
                        detail += 'Use the original launcher to stop it; this manager cannot prove process ownership.'
                        if name == 'contrastive':
                            detail += ' Once the loopback endpoint is free, retry the selected operation in ai-lab web or MCP.'
                        elif name == 'laya' and custom_endpoint:
                            detail += ' Managed Laya binds IPv4 loopback; set AI_LAB_LAYA_URL to a 127.0.0.1 or localhost HTTP origin.'
                    elif identity and status != 'running':
                        detail += 'The owned API is not ready or its launch settings are stale. Stop it or Restart '
                        detail += f'when prerequisites are ready. Check .state/{LOGS[name]}.'
                    elif not source.get('weights_present'):
                        family = 'clm' if name == 'contrastive' else name
                        detail += f'Weights are missing ({source.get("missing_bytes", 0)} bytes). Run ai-lab setup install {family} --yes.'
                    elif not source['installed']:
                        if name == 'laya':
                            detail += 'Existing weights are present. Start sets up the local Node/ONNX server through the existing Laya installer.'
                        else:
                            detail += ('Existing weights are present. Start verifies and repairs only the published runtime. '
                                       'Custom runtime/source overrides require explicit setup through ai-lab setup.'
                                       if repair else 'Existing weights are present. Runtime setup is required through ai-lab setup.')
                    else:
                        detail += 'Start is explicit; exiting stops only APIs launched by this manager.'
                    result.append({'name': name, 'label': source['label'], 'status': status,
                                   'ownership': ownership, 'endpoint': source['endpoint'], 'detail': detail,
                                   'log_path': str(origin / '.state' / LOGS[name]),
                                   **({'origin_root': str(origin)} if name == 'contrastive' else {}),
                                   'weights_present': bool(source.get('weights_present')), 'ready': ready,
                                   'actions': {'start': ready and ownership == 'none', 'stop': bool(identity),
                                               'restart': bool(identity) and ready, 'interrupt': bool(identity)}})
                result.sort(key=lambda row: (*LOCAL, 'jev').index(row['name']))
                return {'root': str(self.root), 'profiles': profile_rows(profiles), 'services': result}
            except ServiceError:
                raise
            except Exception as error:
                raise ServiceError('Service discovery failed. Inspect workspace configuration and runtime '
                                   'readiness through ai-lab setup, then Refresh to retry.') from error

    def _matches(self, name, identity):
        return self._identity(name) == identity

    def _shutdown_key(self, name, identity):
        # The receipt's launch timestamp distinguishes even identical commands
        # started under a reused PID within ps's one-second clock resolution.
        if (name not in LOCAL or not identity.state
                or type(identity.state.get('started_at_ns')) is not int
                or identity.state['started_at_ns'] <= 0):
            return None
        origin = Path(identity.state.get('root', self.root)).resolve()
        value = [str(origin), name, identity.pid, identity.fingerprint, identity.state]
        return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()

    def _shutdown_directory(self, identity, *, create=False):
        origin = Path(identity.state.get('root', self.root)).resolve()
        safe_workspace(origin)
        directory = origin / '.state' / 'service-shutdown'
        if create:
            directory.parent.mkdir(mode=0o700, exist_ok=True)
            directory.mkdir(mode=0o700, exist_ok=True)
        info = directory.lstat()
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) & 0o077):
            raise OSError('Unsafe shutdown acknowledgement directory')
        return directory

    @staticmethod
    def _private_shutdown_file(fd):
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or info.st_nlink != 1 or stat.S_IMODE(info.st_mode) & 0o077
                or info.st_size > SHUTDOWN_ACK_BYTES):
            raise OSError('Unsafe shutdown acknowledgement file')

    def _read_shutdowns(self, path, *, strict=False):
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(fd, 'r') as stream:
                self._private_shutdown_file(stream.fileno())
                value = json.loads(stream.read(SHUTDOWN_ACK_BYTES + 1))
            if (type(value) is dict and set(value) == {'version', 'completed'}
                    and type(value['version']) is int and value['version'] == 1
                    and type(value.get('completed')) is list
                    and len(value['completed']) <= SHUTDOWN_ACK_LIMIT):
                return value['completed']
            if strict:
                raise OSError('Invalid shutdown acknowledgement history')
        except FileNotFoundError:
            pass
        except (OSError, ValueError, RecursionError):
            if strict:
                raise
        return []

    @staticmethod
    def _valid_shutdown(record, name):
        return (type(record) is dict and set(record) == {
                    'launch', 'backend', 'status', 'signal', 'completed_at_ns'}
                and record['backend'] == name and record['status'] == 'completed'
                and type(record['launch']) is str and len(record['launch']) == 64
                and all(c in '0123456789abcdef' for c in record['launch'])
                and type(record['signal']) is int
                and record['signal'] in (signal.SIGTERM, signal.SIGINT)
                and type(record['completed_at_ns']) is int
                and 0 <= time.time_ns() - record['completed_at_ns'] <= SHUTDOWN_ACK_TTL * 10**9)

    def _write_shutdowns(self, path, records, temporary):
        """Atomically sync one private history; the caller holds its writer lock."""
        staged = False
        replaced = False
        try:
            fd = os.open(temporary, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
            with os.fdopen(fd, 'r+') as stream:
                self._private_shutdown_file(stream.fileno())
                staged = True
                stream.truncate(0)
                json.dump({'version': 1, 'completed': records}, stream)
                stream.flush()
                os.fsync(stream.fileno())
            temporary.replace(path)
            replaced = True
            fd = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
        finally:
            if staged and not replaced:
                temporary.unlink(missing_ok=True)

    @staticmethod
    def _lock_shutdowns(lock):
        deadline = time.monotonic() + SHUTDOWN_ACK_SECONDS
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise OSError('Shutdown acknowledgement is busy')
                time.sleep(.01)

    def _publish_shutdown(self, name, identity, sig):
        key = self._shutdown_key(name, identity)
        if key is None:
            return  # Unreceipted legacy processes cannot acknowledge a launch.
        directory = self._shutdown_directory(identity, create=True)
        path = directory / (name + '.json')
        committed = directory / (name + '.committed.json')
        # Fixed, bounded histories and staging file per backend/origin. Only
        # hashes of private commands/settings reach this store.
        flags = os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK
        fd = os.open(directory / (name + '.writer.lock'), flags, 0o600)
        with os.fdopen(fd, 'r+') as writer:
            self._private_shutdown_file(writer.fileno())
            self._lock_shutdowns(writer)
            fd = os.open(directory / (name + '.lock'), flags, 0o600)
            with os.fdopen(fd, 'r+') as lock:
                self._private_shutdown_file(lock.fileno())
                self._publish_shutdown_locked(name, key, sig, path, committed, lock)

    def _publish_shutdown_locked(self, name, key, sig, path, committed, lock):
        # Retain the complete last committed history before risking a new
        # replacement. A pending/failed writer's candidate is never copied
        # into this backup, even across repeated failures or recovery.
        prior = committed if lock.read(1) else path
        records = [r for r in self._read_shutdowns(prior, strict=True) if self._valid_shutdown(r, name)]
        temporary = path.parent / ('.' + name + '.tmp')
        self._write_shutdowns(committed, records, temporary)
        # Until this backup is durable, readers can still take the shared
        # guard and consume the previous main history. Afterward contending
        # readers can safely fall back to the completed backup.
        self._lock_shutdowns(lock)
        lock.seek(0)
        lock.write('pending\n')
        lock.truncate()
        lock.flush()
        os.fsync(lock.fileno())
        # Pruning becomes effective only when this candidate commits; a
        # failed append cannot evict the oldest still-valid prior receipt.
        records = [r for r in records if r['launch'] != key]
        records = records[-(SHUTDOWN_ACK_LIMIT - 1):] + [{
            'launch': key, 'backend': name, 'status': 'completed',
            'signal': int(sig), 'completed_at_ns': time.time_ns()}]
        self._write_shutdowns(path, records, temporary)
        # Visibility commit point after data and directory entry sync. On
        # any earlier failure, readers still consume the committed backup.
        # Losing this final guard clear on power loss fails closed for the
        # new record without invalidating prior committed completions.
        lock.truncate(0)

    def _completed_shutdown(self, name, identity):
        key = self._shutdown_key(name, identity)
        if key is None:
            return False
        try:
            directory = self._shutdown_directory(identity)
            fd = os.open(directory / (name + '.lock'), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(fd, 'r') as lock:
                self._private_shutdown_file(lock.fileno())
                try:
                    fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
                except BlockingIOError:
                    # A later writer must not hold an earlier foreground's
                    # completion hostage. This atomic backup contains only
                    # previously committed records, never its new candidate.
                    history = name + '.committed.json'
                else:
                    history = name + ('.committed.json' if lock.read(1) else '.json')
                return any(self._valid_shutdown(r, name) and r['launch'] == key
                           and r['completed_at_ns'] >= identity.state['started_at_ns']
                           for r in self._read_shutdowns(directory / history))
        except (OSError, ServiceError):
            return False

    async def _stop(self, name, identity, sig):
        if not await asyncio.to_thread(self._matches, name, identity):
            raise ServiceError('Process identity changed. No signal was sent; Refresh and use the current launcher.')
        try:
            os.killpg(identity.pid, sig)
        except ProcessLookupError:
            raise ServiceError('The owned process disappeared before signal dispatch. '
                               'No completed shutdown was recorded.') from None
        # Once a signal has been sent, cancellation must not release the caller's
        # operation lock while stop/receipt cleanup/publication is still running.
        finishing = asyncio.create_task(self._finish_stop(name, identity, sig))
        try:
            await asyncio.shield(finishing)
        except asyncio.CancelledError:
            await self._settle(finishing)
            raise

    async def _finish_stop(self, name, identity, sig):
        deadline = asyncio.get_running_loop().time() + STOP_SECONDS
        process = self._process(name)
        if process and process.pid == identity.pid:
            try:
                await asyncio.wait_for(process.wait(), STOP_SECONDS)
            except asyncio.TimeoutError:
                raise ServiceError('The owned service has not stopped yet. Check its launcher/log, then Refresh. '
                                   'No forced kill was sent.') from None
        else:
            while await asyncio.to_thread(_pid_exists, identity.pid):
                if await asyncio.to_thread(process_fingerprint, identity.pid) != identity.fingerprint:
                    # Exit can occur between the existence probe and ps. Only
                    # another actual absence observation closes that race.
                    if not await asyncio.to_thread(_pid_exists, identity.pid):
                        break
                    raise ServiceError('Process identity changed before completed stop could be verified. '
                                       'No further signal or completed shutdown was recorded.')
                if asyncio.get_running_loop().time() >= deadline:
                    raise ServiceError('The owned service has not stopped yet. Check its launcher/log, then Refresh. '
                                       'No forced kill was sent.')
                await asyncio.sleep(.05)
        if identity.state:
            if name in {'contrastive', 'laya'}:
                decision_processes.forget_state(Path(identity.state['root']), identity.state, family=name)
            else:
                from harness.generation_models import generation_backend
                path = self.root / '.state' / (generation_backend(name).state_name + '.json')
                try:
                    if json.loads(path.read_text()) == identity.state:
                        path.unlink()
                except (FileNotFoundError, ValueError):
                    pass
        if self.created.get(name) == identity:
            self.created.pop(name)
        self._forget(name, identity.pid)
        if sig in (signal.SIGTERM, signal.SIGINT):
            await asyncio.to_thread(self._publish_shutdown, name, identity, sig)

    def _retire_exited(self, name, identity):
        """Drop a confirmed exited child under the operation lock, without signals.

        A missing/mismatched process fingerprint is not proof of exit. Only the
        exact retained subprocess handle's return code authorizes retirement.
        Keep disk receipts intact: another owner may already have replaced one.
        """
        process = self._process(name)
        if (self.created.get(name) != identity or process is None
                or process.pid != identity.pid or process.returncode is None):
            return False
        self.created.pop(name)
        self._forget(name, identity.pid)
        return True

    def _forget(self, name, pid):
        holder = self._holder(name)
        slot, log_slot = SLOTS[name]
        process = getattr(holder, slot, None)
        if process and process.pid == pid:
            if self.pending.get(name) is process:
                self.pending.pop(name)
            setattr(holder, slot, None)
            log = getattr(holder, log_slot, None)
            if log:
                log.close()
                setattr(holder, log_slot, None)
            if name in {'deepseek', 'qwen'}:
                setattr(holder, name + '_state', None)
            elif name == 'contrastive':
                holder.process_state = None
            elif name == 'laya':
                holder.laya_state = None

    async def _launch(self, name, origin=None):
        origin = Path(origin or self.root).resolve()
        if origin != self.root:
            safe_workspace(origin)
        if name in LOCAL and self.repair_runtime:
            from ai_lab.setup import repair_generation_runtime
            from ai_lab.runtime import install_decisions
            from ai_lab.laya import setup as setup_laya
            repair_call = (asyncio.to_thread(install_decisions, origin) if name == 'contrastive' else
                           asyncio.to_thread(setup_laya, self.root) if name == 'laya' else
                           asyncio.to_thread(repair_generation_runtime, self.root, name))
            repair = asyncio.create_task(repair_call)
            try:
                await asyncio.shield(repair)
            except asyncio.CancelledError:
                # File verification / atomic runtime installation cannot be stopped
                # mid-thread. Settle it under the operation lock, then do not launch.
                await self._settle(repair)
                raise
        launcher = self.manager
        if name not in {'deepseek', 'qwen'}:
            if name not in self.decision_managers or Path(getattr(self.decision_managers[name], 'root', self.root)).resolve() != origin:
                from ai_lab.model_servers import ModelServers
                # DecisionRuntime.ensure_local closes its own runtime on timeout.
                # Isolate each provider so that selected startup failure cannot
                # stop another API successfully started earlier in this manager.
                def decision_manager():
                    from ai_lab.paths import load_backend
                    try:
                        return ModelServers(origin)
                    finally:
                        # A native CLM origin does not reroute the manager's
                        # unrelated generation profiles or future imports.
                        load_backend(self.root)
                self.decision_managers[name] = await asyncio.to_thread(decision_manager)
            launcher = self.decision_managers[name]
        previous = self._process(name)
        task = asyncio.create_task(launcher.start([name]))
        capture = None
        try:
            await asyncio.shield(task)
            process = self._process(name)
            if not process or process is previous:
                return  # Existing/borrowed API; no new child belongs to this action.
            self.pending[name] = process
            if process.returncode is not None:
                self._forget(name, process.pid)
                raise ServiceError('The launched service exited before it became usable. Inspect its .state log, then Refresh.')
            capture = asyncio.create_task(self._capture_created(name, process))
            if not await asyncio.shield(capture):
                raise ServiceError('The launched process identity could not be verified. No signal was sent. '
                                   'Inspect the service log and its original launcher.')
        except BaseException:
            # Include final identity capture in the protected ownership phase.
            # Neither cancellation nor Exit may release this operation's lock
            # before its worker/registration and scoped cleanup have settled.
            cleanup = asyncio.create_task(self._abort_launch(name, previous, task, capture))
            await self._settle(cleanup)
            raise

    async def _abort_launch(self, name, previous, task, capture):
        # Subprocess creation may still be delivering its handle. Only a new
        # handle, never a borrowed service or the prior selected child, is ours.
        while not task.done() and self._process(name) is previous:
            await asyncio.sleep(.01)
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        # A capture that already started must settle even if the child exits or
        # its handle disappears while the worker is delayed. No old worker may
        # read a later operation's holder after this lock is released.
        identity = await capture if capture is not None else None
        process = self._process(name)
        if not process or process is previous:
            return
        if process.returncode is not None:
            self._forget(name, process.pid)
            return
        self.pending[name] = process
        if capture is None:
            capture = asyncio.create_task(self._capture_created(name, process))
            identity = await capture
        if not identity:
            raise ServiceError('New service cleanup could not verify process identity. No signal was sent. '
                               'Inspect its launcher/log and retry Exit; cleanup is still pending.')
        await self._stop(name, identity, signal.SIGTERM)

    async def perform(self, action, name):
        if action not in ACTIONS or name not in (*LOCAL, 'jev'):
            raise ServiceError('Choose a supported service action and API/provider.')
        inventory = await self.snapshot()  # Never trust an earlier UI status before a mutation.
        row = next(row for row in inventory['services'] if row['name'] == name)
        async with self.lock:
            try:
                origin = (self.native_origin or self.root) if name == 'contrastive' else self.root
                if action == 'start' and row['status'] == 'running' and row['ownership'] != 'external':
                    return {'service': name, 'action': action, 'status': 'already running', 'spawned': False}
                if action == 'stop' and row['ownership'] == 'none':
                    return {'service': name, 'action': action, 'status': 'already stopped'}
                if not row['actions'][action]:
                    raise ServiceError(row['detail'])
                if action in {'stop', 'restart', 'interrupt'}:
                    identity = await asyncio.to_thread(self._identity, name)
                    if not identity:
                        raise ServiceError('Process identity changed. Refresh before retrying; nothing was signalled.')
                    if name == 'contrastive' and identity.state:
                        origin = Path(identity.state['root'])
                    await self._stop(name, identity, signal.SIGINT if action == 'interrupt' else signal.SIGTERM)
                if action in {'start', 'restart'}:
                    await self._launch(name, origin)
                return {'service': name, 'action': action,
                        'status': 'running' if action in {'start', 'restart'} else 'stopped',
                        'effect': 'Entire shared service stopped (Ctrl+C).' if action == 'interrupt' else action}
            except (ServiceError, asyncio.CancelledError):
                raise
            except Exception as error:
                raise ServiceError(f'{name} action failed. Check .state/{LOGS.get(name, "service.log")} '
                                   + ('and .state/clm-upstream-encoder.log ' if name == 'clm-upstream' else '')
                                   + 'and runtime readiness through ai-lab setup, then Refresh and retry.') from error

    async def close(self):
        async with self.lock:
            errors = []
            for name, process in list(self.pending.items()):
                if process.returncode is not None:
                    self._forget(name, process.pid)
                    continue
                try:
                    capture = asyncio.create_task(self._capture_created(name, process))
                    if not await self._settle(capture):
                        errors.append(name)
                except Exception:
                    errors.append(name)
            for name, identity in list(self.created.items()):
                if await asyncio.to_thread(process_fingerprint, identity.pid) != identity.fingerprint:
                    # Exited/replaced children are never signalled and receipts are retained.
                    self.created.pop(name)
                    self._forget(name, identity.pid)
                    continue
                try:
                    await self._stop(name, identity, signal.SIGTERM)
                except Exception:
                    errors.append(name)
            if errors:
                raise ServiceError('Owned cleanup could not finish for ' + ', '.join(errors)
                                   + '. Inspect their launchers/logs; no unverified process was signalled.')


def add_parser(subparsers):
    parser = subparsers.add_parser('services', help='Run an explicit shared API lifecycle action',
                                  description='Internal scripted service supervision; no terminal screen. '
                                              'Saved profiles share their backend server; interrupt stops the entire service.')
    parser.add_argument('--action', choices=('list', *ACTIONS), help='Script an explicit action; start/restart stay in the foreground')
    target = parser.add_mutually_exclusive_group()
    target.add_argument('--name', help='Exact saved generation profile name (case-sensitive)')
    target.add_argument('--model', choices=(*LOCAL, 'jev'), help='Underlying generation API or decision provider')
    parser.add_argument('--json', action='store_true', default=argparse.SUPPRESS, help='Machine output for --action only')
    return parser


async def _script(args, root):
    backend = NativeServices(root)
    reporter = HerdrReporter('services-' + uuid.uuid4().hex)
    try:
        await reporter.report('working')
        inventory = await backend.snapshot()
        if args.action == 'list':
            if args.name is not None or args.model is not None:
                selected = select_service(inventory, name=args.name, model=args.model)
                inventory['services'] = [row for row in inventory['services'] if row['name'] == selected]
                inventory['profiles'] = [row for row in inventory['profiles'] if row['service'] == selected]
            value = inventory
        else:
            selected = select_service(inventory, name=args.name, model=args.model)
            value = await backend.perform(args.action, selected)
        # Keep this invocation's child and launch identity even if an independent
        # manager removes its receipt or starts a healthy replacement.
        process = backend._process(selected) if args.action in {'start', 'restart'} else None
        identity = backend.created.get(selected) if process is not None else None
        if getattr(args, 'json', False):
            print(json.dumps(value, ensure_ascii=False), flush=True)
        elif args.action == 'list':
            from rich.console import Console
            from rich.table import Table
            table = Table('API', 'Status', 'Ownership', 'Saved generation names')
            for row in value['services']:
                names = ', '.join(p['name'] for p in value['profiles'] if p['service'] == row['name']) or '—'
                table.add_row(Text(row['label']), row['status'], row['ownership'], Text(names))
            console = Console()
            console.print(Text(str(root)))
            console.print(table)
        else:
            print(f'{selected}: {value["status"]}.', flush=True)
        await reporter.report('idle')
        if args.action in {'start', 'restart'}:
            print('Keep this terminal open. Ctrl+C stops only APIs launched by this invocation.', file=sys.stderr, flush=True)
            if process is not None and identity is not None:
                await process.wait()
                # The independent stopper may still be observing exit before
                # publishing completion. A missing receipt/exit code/healthy
                # replacement alone never makes an unexpected exit successful.
                deadline = asyncio.get_running_loop().time() + SHUTDOWN_ACK_SECONDS
                while True:
                    if await asyncio.to_thread(backend._completed_shutdown, selected, identity):
                        value = {'event': 'service_stopped', 'service': selected, 'status': 'stopped'}
                        if getattr(args, 'json', False):
                            print(json.dumps(value), flush=True)
                        else:
                            print(f'{selected}: stopped.', flush=True)
                        await reporter.report('idle')
                        return 0
                    if asyncio.get_running_loop().time() >= deadline:
                        raise ServiceError('The managed API exited. Inspect its .state log and runtime readiness.')
                    await asyncio.sleep(.05)
            # An already running, borrowed API is not this invocation's child.
            while True:
                await asyncio.sleep(1)
        return 0
    finally:
        try:
            await backend.close()
        finally:
            await reporter.close()


def run(args, root):
    if not args.action:
        raise ServiceError('Terminal screens have been removed. Launch ai-lab web to start the local APIs.')
    elif args.action != 'list' and args.name is None and args.model is None:
        raise ServiceError('A scripted service action needs --name EXACT_SAVED_NAME or --model BACKEND.')
    try:
        return asyncio.run(_script(args, root))
    except KeyboardInterrupt:
        return 130
