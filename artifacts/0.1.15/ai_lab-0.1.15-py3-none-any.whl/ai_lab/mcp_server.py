"""Client-launched stdio MCP entry point; no website or CLI daemon is required."""
import argparse
from contextlib import asynccontextmanager
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict

from ai_lab.decision_descriptions import PUBLIC_DECISION_DESCRIPTIONS
from ai_lab.mcp_tools import LabTools
from ai_lab.paths import root_path

Provider = Literal['jev', 'contrastive']
Source = Literal['inspection', 'session', 'watermark']
Generation = Literal['deepseek', 'DeepSeekR1']
Scheme = Literal['synthid', 'kgw', 'unigram', 'exponential', 'inverse_transform', 'mpac']


class DecisionQuestion(BaseModel):
    model_config = ConfigDict(extra='forbid')
    type: Literal['choice', 'score', 'noul']
    instructions: str | dict[str, Any] | list[Any] | None = None
    criteria: dict[str, Any] | list[Any] | None = None


def create_server(root, tools=None):
    from mcp.server.fastmcp import FastMCP
    from mcp.types import ToolAnnotations
    tools = tools or LabTools(root)

    @asynccontextmanager
    async def lifespan(server):
        try:
            yield {}
        finally:
            await tools.close()

    mcp = FastMCP('ai-lab', lifespan=lifespan, instructions=(
        'Compare real model outputs and inspect captured native watermark evidence. '
        'Jev is the default decision provider and sends questions to the hosted TypeSafe API. '
        'Execution tools automatically start the selected installed local API and stop only APIs they own on exit. No model is downloaded implicitly. '
        'Use list_models even before downloads, and explain_watermarks for schemes and paper links. '
        'Watermark detection uses the selected DeepSeek tokenizer and a supplied key or saved profile; '
        'confidence is a known-key statistical test, not an authorship probability. '
        'get_model_config can explicitly return saved watermark keys. Per-call overrides do not persist; '
        'use update_watermarked_model to save them for future sessions. '
        'Create a DeepSeek profile before inspect_next_token. Do not invent missing probabilities, '
        'green/red membership or tournament matches. Downloading models does not start APIs.'))
    read = ToolAnnotations(readOnlyHint=True, destructiveHint=False, idempotentHint=True, openWorldHint=False)
    write = ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=False)
    decision = ToolAnnotations(readOnlyHint=True, destructiveHint=False, idempotentHint=False, openWorldHint=True)

    @mcp.tool(annotations=read)
    async def list_models() -> dict:
        """List Jev, DeepSeek and native CLM, including undownloaded/stopped models, download sizes, run commands and saved seeded/watermarked profiles. Starts no model or service."""
        return await tools.list_models()

    @mcp.tool(annotations=write)
    async def create_seeded_model(name: str, seed: int | str, underlying_model: Generation = 'deepseek') -> dict:
        """Create a named DeepSeek profile with a deterministic seed (decimal or 0x hex, 0–9007199254740991). Does not download weights or start an API."""
        return await tools.create_model(name, seed, underlying_model=underlying_model)

    @mcp.tool(annotations=write)
    async def create_watermarked_model(name: str, scheme: Scheme, seed: int | str | None = None,
                                       settings: dict[str, Any] | None = None, key: str | None = None,
                                       underlying_model: Generation = 'deepseek') -> dict:
        """Create a persistent DeepSeek watermark profile. All supported scheme settings are overridable via settings; see explain_watermarks. Optional key is 64 hex characters and overrides settings.key. If neither is supplied, generate and save a key. New SynthID defaults to tournament sampling, depth 4. No API is started. Saved settings/keys are reused across client sessions."""
        return await tools.create_watermarked_model(name, scheme, seed, settings, key=key, underlying_model=underlying_model)

    @mcp.tool(annotations=read)
    def get_model_config(model: str, include_watermark_key: bool = False) -> dict:
        """Read a persistent model profile by key or exact name, including its seed and every watermark setting. Set include_watermark_key=true to retrieve its saved watermark key explicitly; otherwise the key is hidden. Does not return Jev/API credentials or start any service."""
        return tools.get_model_config(model, include_watermark_key)

    @mcp.tool(annotations=write)
    async def update_watermarked_model(model: str, scheme: Scheme | None = None,
                                       key: str | None = None, settings: dict[str, Any] | None = None,
                                       underlying_model: Generation | None = None) -> dict:
        """Persist key/scheme/setting overrides on an existing generation profile, keeping its ID, name and seed. All supported watermark settings are overridable. Omitted fields retain saved values; a scheme change retains the key and resets scheme-specific settings. Explicit key overrides settings.key. New sessions inherit the saved configuration; existing session snapshots remain intact. Starts no API."""
        return await tools.update_watermarked_model(model, scheme, key, settings, underlying_model=underlying_model)

    @mcp.tool(annotations=decision)
    async def generate_text(prompt: str, model: str = 'deepseek', scheme: Scheme | Literal['none'] | None = None,
                            key: str | None = None, settings: dict[str, Any] | None = None,
                            seed: int | str | None = None, max_tokens: int = 1024,
                            temperature: float = .8, capture_trace: bool = False) -> dict:
        """Generate real text with DeepSeek or a saved profile key/exact name. Omitted scheme/key/settings inherit the profile watermark; scheme=none disables it for this call. Optional overrides and seed never change the saved profile. Plain backend selection is unwatermarked unless explicit scheme/key are supplied. Keys are hidden in all ordinary results. Returns actual answer, usage and optional native sampling trace with selected backend identity. Automatically starts the selected installed API when needed; never downloads models. decision encoders do not generate text."""
        return await tools.generate_text(prompt, model, scheme, key, settings, seed=seed,
                                        max_tokens=max_tokens, temperature=temperature, capture_trace=capture_trace)

    @mcp.tool(annotations=read)
    async def detect_watermark(text: str, model: str = 'deepseek', scheme: Scheme | None = None,
                               key: str | None = None, settings: dict[str, Any] | None = None,
                               prompt_len: int = 0, eos_token_ids: list[int] | None = None,
                               add_special_tokens: bool = False, p_value_threshold: float = .001,
                               min_tokens: int = 20) -> dict:
        """Detect a watermark in supplied text. Choose model=deepseek with explicit scheme/key/settings, or a saved profile key/name to reuse its persisted settings and key. Every watermark/detector setting can be overridden for this call; explicit key wins over settings.key and the saved key. Returns native stats, match/no_match/insufficient verdict, p-value, confidence, scored-token count and test method. Confidence is 1-p_value from a known-key test/bound, not authorship probability. Short/unscorable text is insufficient; no confidence is invented. Automatically starts the selected installed API when needed. Does not save overrides or download any model."""
        return await tools.detect_watermark(text, model, scheme, key, settings,
                     prompt_len=prompt_len, eos_token_ids=eos_token_ids, add_special_tokens=add_special_tokens,
                     p_value_threshold=p_value_threshold, min_tokens=min_tokens)

    @mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=True, openWorldHint=True))
    async def download_models(models: list[Literal['deepseek', 'clm', 'contrastive', 'jev']] | None = None) -> dict:
        """Download missing local weights and install their server dependencies; reuse verified files and resume interrupted downloads. Omit models for all families. Native CLM uses the clm weights. Jev needs no download. Can be large: inspect list_models first. Does not start model APIs."""
        return await tools.download_models(models)

    @mcp.tool(annotations=read)
    def explain_watermarks(scheme: str | None = None) -> dict:
        """Explain supported watermark schemes with paper titles/links and exact configuration fields. Omit scheme to compare all six. Explains green/red membership and production versus teaching tournaments."""
        return tools.explain_watermarks(scheme)

    @mcp.tool(annotations=decision, description=PUBLIC_DECISION_DESCRIPTIONS['answer_decisions'])
    async def answer_decisions(state: str | dict[str, Any] | list[Any], questions: dict[str, DecisionQuestion], model: Provider = 'jev') -> dict:
        return await tools.answer_decisions(state, {name: question.model_dump(exclude_none=True) for name, question in questions.items()}, model)

    @mcp.tool(annotations=decision, description=PUBLIC_DECISION_DESCRIPTIONS['rank_decisions'])
    async def rank_decisions(context: str | dict[str, Any] | list[Any], answers: list[str], question: str | None = None, model: Provider = 'jev') -> dict:
        return await tools.rank_decisions(context, answers, question, model)

    @mcp.tool(annotations=write)
    async def inspect_next_token(model: str, prompt: str, temperature: float = 1, scheme: Scheme | None = None,
                                 key: str | None = None, settings: dict[str, Any] | None = None) -> dict:
        """Inspect one exact raw prefix with a saved DeepSeek profile key/name. Optional scheme/key/settings override the saved watermark only for this call; use update_watermarked_model to persist changes. Automatically starts the selected installed API when needed without downloading models. Saves the native trace and returns an inspection_id for green/red lists and tournament results. Never applies a chat template to your prefix."""
        return await tools.inspect_next_token(model, prompt, temperature, scheme=scheme, key=key, settings=settings)

    @mcp.tool(annotations=read)
    def list_results() -> dict:
        """List saved MCP inspections, CLI sessions and website watermark experiments. Returns source IDs for get_green_red_lists/get_tournament_results. No model API is needed."""
        return tools.list_results()

    @mcp.tool(annotations=read)
    def get_green_red_lists(source_id: str, source: Source = 'inspection', step: int = 0,
                            layer: int | None = None, agent_id: str | None = None) -> dict:
        """Show native green/red membership. For SynthID probability updates, layer selects a captured probability layer; for production tournaments, it selects a captured round and returns entrant draw IDs and g scores. Defaults to the last captured layer/round. Reports capture limits and never claims full-vocabulary membership. source can be inspection, session or watermark; watermark requires its agent_id."""
        return tools.green_red_lists(source_id, source, step, layer, agent_id)

    @mcp.tool(annotations=read)
    def get_tournament_results(source_id: str, source: Source = 'inspection', step: int = 0, agent_id: str | None = None) -> dict:
        """Show the saved production tournament, winner, draws, matches, collapsed subtrees and capture limits. Keeps any teaching simulation separate. Short-prefix warmup and omitted brackets have no winner and are reported explicitly. source can be inspection, session or watermark; watermark requires agent_id."""
        return tools.tournament_results(source_id, source, step, agent_id)

    return mcp


def main(argv=None):
    parser = argparse.ArgumentParser(prog='ai-lab-mcp', description='AI Lab stdio MCP server, launched on demand by your agent client.')
    parser.add_argument('--root', help='AI Lab workspace (defaults to AI_LAB_ROOT or the CLI workspace)')
    args = parser.parse_args(argv)
    try:
        create_server(root_path(args.root)).run(transport='stdio')
    except ModuleNotFoundError as error:
        if error.name == 'mcp':
            parser.exit(1, 'The required MCP dependency is missing. Run ai-lab mcp install --codex or launch with uvx --from "ai-lab[mcp]" ai-lab-mcp.\n')
        raise
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
