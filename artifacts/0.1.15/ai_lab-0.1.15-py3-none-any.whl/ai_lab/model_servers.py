"""Explicit foreground supervision of local model APIs, independent of MCP/UI."""
import asyncio
import json
import os
from pathlib import Path
import signal
import sys
import time

import httpx
from fastapi import HTTPException

from ai_lab.client import LabError
from ai_lab.credentials import jev_key
from ai_lab.downloads import catalog, missing_weights_message, verified_present, status as download_status
from ai_lab.paths import RESOURCES, load_backend, root_details
from ai_lab.service import atomic_json
from ai_lab.setup import prepare, repair_generation_runtime
from ai_lab.runtime import decisions_ready, install_decisions

LOCAL_MODELS = ('deepseek', 'qwen', 'contrastive', 'clm-upstream', 'laya')
DECISION_MODELS = ('jev', 'contrastive', 'clm-upstream', 'laya')


def installed_models(root):
    rows = {row['name']: row for row in download_status(root, models=('deepseek', 'qwen', 'clm', 'laya'))}
    clm_weights = all(verified_present(root, file) for file in catalog()['clm']['files'])
    return {'deepseek': rows['deepseek']['installed'], 'qwen': rows['qwen']['installed'],
            'contrastive': clm_weights and decisions_ready(root),
            'clm-upstream': clm_weights and _upstream_ready(root), 'laya': rows['laya']['installed']}


def _upstream_ready(root):
    load_backend(root)
    from clm_upstream import installed
    return installed(root)


def prime_generation_verification(root, family):
    """Hand the unchanged shipped-weight proof to inference's process cache.

    Model start already validates weights using persistent receipts. Avoid a
    second full read in inference.verify_installation, while retaining its normal
    verification for custom model/assets or a backend loaded for another root.
    Templates are always freshly hashed by start_generation below.
    """
    import inference
    root = Path(root).resolve()
    if Path(inference.ROOT).resolve() != root:
        return
    try:
        bundled = json.loads((RESOURCES / 'sources.json').read_text())
        source_bytes = (root / 'sources.json').read_bytes()
        current = json.loads(source_bytes)
        if current != inference.SOURCES or any(inference.SOURCES.get(key) != bundled[key] for key in ('model', 'assets')):
            return
        build_bytes = (root / '.state/mistral-build.json').read_bytes()
        build = json.loads(build_bytes)
        row = download_status(root, models=(family,))[0]
        if not row['weights_present'] or not row['dependencies_ready']:
            return
        inference.verified_chat_template_sha256(family)
        if ((root / '.state/mistral-build.json').read_bytes() != build_bytes
                or (root / 'sources.json').read_bytes() != source_bytes):
            return
        if inference._verified is None:
            inference._verified = {}
        inference._verified[family] = build
    except (OSError, ValueError, KeyError, RuntimeError):
        return


async def available_models(root, decision_runtime=None):
    """Include missing weights and stopped APIs; discovery never starts a model."""
    root = Path(root).resolve()
    prepare(root); load_backend(root)
    import inference
    from decisions import DecisionRuntime
    runtime = decision_runtime or DecisionRuntime(root, allow_start=False)
    installed = installed_models(root)
    downloads = {row['name']: row for row in download_status(root, models=('deepseek', 'qwen', 'clm', 'laya'))}

    async def probe(function):
        try:
            return {'running': bool(await function())}
        except Exception as error:
            return {'running': False, 'error': str(getattr(error, 'detail', error))}

    from harness.generation_models import GENERATION_BACKENDS

    async def generation(backend):
        async with httpx.AsyncClient(timeout=2, trust_env=False) as client:
            response = await client.get(backend.base_url + '/v1/models')
            response.raise_for_status()
            matches = inference.api_model_matches(response.json(), backend)
            owned = inference.owned_state(backend)
            if owned and (not matches or not inference.launch_matches(owned, backend)):
                raise ValueError(inference.restart_guidance(backend))
            return matches

    probes = await asyncio.gather(*(probe(function) for function in
                                  (lambda: generation(GENERATION_BACKENDS[0]), lambda: generation(GENERATION_BACKENDS[1]),
                                   runtime.local_model, runtime.upstream_model, runtime.laya_model)))
    urls = (inference.BASE_URL, GENERATION_BACKENDS[1].base_url, runtime.url, runtime.upstream_url, runtime.laya_url)
    labels = ('DeepSeek R1', 'Qwen3-8B', 'Native Contrastive CLM', 'Upstream Contrastive CLM', 'Laya')
    models = [{'name': 'jev', 'label': 'Jev', 'local': False, 'available': True,
               'configured': bool(jev_key(root)), 'download_required': False,
               'status': 'hosted', 'decision': True, 'endpoint': 'https://api.typesafe.ai/v1/systemone'}]
    for name, url, label, health in zip(LOCAL_MODELS, urls, labels, probes):
        family = 'clm' if name in {'contrastive', 'clm-upstream'} else name
        ready = (decisions_ready(root) if name == 'contrastive' else
                 _upstream_ready(root) if name == 'clm-upstream' else
                 downloads[family].get('dependencies_ready', installed[name]))
        models.append({'name': name, 'label': label, 'local': True, 'decision': name not in {'deepseek', 'qwen'},
                       'installed': installed[name], 'status': 'running' if health['running'] else
                       ('stopped' if installed[name] else
                        ('runtime_missing' if downloads[family]['missing_bytes'] == 0 else 'not_installed')), 'endpoint': url,
                       'download_family': family, 'missing_bytes': downloads[family]['missing_bytes'],
                       'weights_present': downloads[family].get('weights_present', downloads[family]['missing_bytes'] == 0),
                       **root_details(root), 'missing_files': downloads[family].get('missing_files', []),
                       'other_roots': downloads[family].get('other_roots', []),
                       'dependencies_ready': ready,
                       'runtime_status': 'ready' if ready else 'setup-required',
                       'install_command': f'ai-lab setup install {family} --yes',
                       'run_command': 'ai-lab web', **health})
    return models


class ModelServers:
    def __init__(self, root):
        self.root = Path(root).resolve()
        prepare(self.root); load_backend(self.root)
        from decisions import DecisionRuntime
        self.decisions = DecisionRuntime(self.root)
        self.deepseek_process = None
        self.deepseek_log = None
        self.deepseek_state = None
        self.qwen_process = self.qwen_log = self.qwen_state = None

    async def start_deepseek(self):
        await self.start_generation('deepseek')

    async def start_qwen(self):
        await self.start_generation('qwen')

    async def start_generation(self, family):
        import inference
        from harness.generation_models import generation_backend
        backend = generation_backend(family)
        await asyncio.to_thread(prime_generation_verification, self.root, family)
        build = await asyncio.to_thread(inference.verify_installation, backend)
        expected = inference.command(backend)
        template_sha256 = await asyncio.to_thread(inference.verified_chat_template_sha256, backend)
        current = await asyncio.to_thread(inference.owned_state, backend)
        if current:
            if not inference.launch_matches(current, backend):
                raise ValueError(inference.restart_guidance(backend))
            if not inference.model_matches(await asyncio.to_thread(inference.api, '/v1/models', model=backend), backend):
                raise ValueError(f'The existing {backend.label} API reports a different generation model. {inference.restart_guidance(backend)}')
            return
        if not inference.port_available(backend):
            raise ValueError(f'{backend.label} port {backend.port} belongs to another process or workspace; leaving it untouched.')
        log = (self.root / '.state' / backend.log_name).open('a')
        setattr(self, family + '_log', log)
        env = {key: value for key, value in inference.environment().items()
               if not key.endswith(('_KEY', '_TOKEN', '_PASSWORD', '_SECRET'))}
        process = await asyncio.create_subprocess_exec(
            '/usr/bin/sandbox-exec', '-f', str(self.root / 'offline.sb'), *expected,
            cwd=self.root, env=env, stdin=asyncio.subprocess.DEVNULL,
            stdout=log, stderr=log, start_new_session=True)
        setattr(self, family + '_process', process)
        state = {'pid': process.pid, 'port': backend.port, 'family': family,
                 'model': backend.underlying_model, 'command': expected, 'offline': True,
                 'prefix_cache_n': 0, 'started_at_ns': time.time_ns(), 'build': build,
                 'chat_template_sha256': template_sha256}
        setattr(self, family + '_state', state)
        atomic_json(backend.pidfile, state)
        deadline = time.monotonic() + inference.STARTUP_TIMEOUT
        while time.monotonic() < deadline:
            if process.returncode is not None:
                raise ValueError(f'{backend.label} exited; see .state/{backend.log_name}.')
            try:
                response = await asyncio.to_thread(inference.api, '/v1/models', timeout=2, model=backend)
                if inference.model_matches(response, backend):
                    return
            except (OSError, ValueError):
                pass
            await asyncio.sleep(.25)
        raise ValueError(f'{backend.label} startup timed out; see .state/{backend.log_name}.')

    async def start(self, models):
        functions = {'deepseek': self.start_deepseek, 'qwen': self.start_qwen, 'contrastive': self.decisions.ensure_local,
                     'clm-upstream': self.decisions.ensure_upstream, 'laya': self.decisions.ensure_laya}
        async def launch(name):
            print(f'Starting {name} API…', file=sys.stderr, flush=True)
            if name == 'contrastive':
                print(f'Loading the CLM/Qwen3-8B encoder; first startup and inference may take a few minutes. '
                      f'Log: {self.root / ".state/decisions-mistral.log"}', file=sys.stderr, flush=True)
            try:
                await functions[name]()
            except HTTPException as error:
                raise LabError(str(error.detail), 'model_unavailable', error.status_code) from error
        tasks = [asyncio.create_task(launch(name)) for name in models]
        try:
            await asyncio.gather(*tasks)
        except BaseException:
            for task in tasks: task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            raise

    async def close(self):
        await self.decisions.close()
        for family, state_name in (('deepseek', 'mistral-server'), ('qwen', 'qwen-server')):
            process = getattr(self, family + '_process', None)
            state = getattr(self, family + '_state', None)
            if process and process.returncode is None:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    await asyncio.wait_for(process.wait(), 30)
                except asyncio.TimeoutError:
                    os.killpg(process.pid, signal.SIGKILL)
                    await process.wait()
            if state:
                path = self.root / '.state' / (state_name + '.json')
                try:
                    if json.loads(path.read_text()).get('pid') == state['pid']:
                        path.unlink()
                except (FileNotFoundError, ValueError):
                    pass
            log = getattr(self, family + '_log', None)
            if log:
                log.close()



async def serve(root, selected=None, structured=False):
    manager = ModelServers(root)
    try:
        catalog_rows = await available_models(root, manager.decisions)
        local = {row['name']: row for row in catalog_rows if row['local']}
        names = list(dict.fromkeys(selected or LOCAL_MODELS))
        if any(name not in {*LOCAL_MODELS, 'jev'} for name in names):
            raise ValueError('Choose deepseek, qwen, contrastive, clm-upstream, laya or jev.')
        skipped = []
        active = []
        for name in names:
            if name == 'jev': continue
            if (name in {'deepseek', 'qwen'} and not local[name]['installed'] and not local[name]['running']
                    and local[name].get('weights_present')):
                print(f'{name} weights are verified at {Path(root).resolve()}. Repairing only the published runtime…',
                      file=sys.stderr, flush=True)
                await asyncio.to_thread(repair_generation_runtime, Path(root), name)
                from ai_lab.downloads import dependencies_ready
                local[name]['installed'] = dependencies_ready(root, name)
            if (name == 'contrastive' and not local[name]['installed'] and not local[name]['running']
                    and local[name].get('weights_present')):
                print('CLM/Qwen weights are already downloaded. Installing the native Contrastive Metal server…',
                      file=sys.stderr, flush=True)
                await asyncio.to_thread(install_decisions, Path(root))
                local[name]['installed'] = decisions_ready(root)
            if not local[name]['installed'] and not local[name]['running']:
                family = local[name]['download_family']
                message = (f'{name} weights are present at {Path(root).resolve()}; runtime setup is required. '
                           f'Run ai-lab weights install {family} --yes (verified weights are reused).'
                           if local[name].get('weights_present') else missing_weights_message(root, family, local[name]))
                if name == 'contrastive':
                    message += (' Contrastive uses the CLM projection checkpoint and Qwen3-8B encoder weights '
                                'with the native Metal server. No manual binary or compiler is required.')
                if selected: raise ValueError(message)
                skipped.append(name); print(message, file=sys.stderr, flush=True)
            else:
                active.append(name)
        await manager.start(active)
        ready = {'status': 'running' if active else 'no_local_models', 'root': str(Path(root).resolve()),
                 'models': active, 'skipped': skipped, 'jev': 'hosted; no local server required',
                 'endpoints': {name: local[name]['endpoint'] for name in active}}
        if structured: print(json.dumps(ready), flush=True)
        else:
            for name in active: print(f'{name}: {local[name]["endpoint"]}', flush=True)
            print('Jev uses its hosted API; no local Jev process is needed.', flush=True)
        if not active: return 0
        if not structured: print('Keep this terminal open. Ctrl+C stops only model APIs started by this command.', flush=True)
        while True:
            await asyncio.sleep(1)
            for process in (manager.deepseek_process, getattr(manager, 'qwen_process', None), manager.decisions.process,
                            manager.decisions.upstream_process, manager.decisions.laya_process):
                if process and process.returncode is not None:
                    raise ValueError('A managed model API exited. Check its log in .state/.')
    finally:
        await manager.close()


def run(root, selected=None, structured=False):
    try:
        return asyncio.run(serve(root, selected, structured))
    except KeyboardInterrupt:
        return 130
