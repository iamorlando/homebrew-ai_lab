"""Set up the experiments checkout and its Python dependencies, without running it."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tomllib
from urllib.parse import urlsplit

from ai_lab.client import LabError
from ai_lab.credentials import jev_key

REPOSITORY = 'https://github.com/iamorlando/ai_experiments.git'
KEY_NAMES = ('TYPESAFE_API_KEY', 'CLM_API_KEY')


def add_parser(subparsers):
    parser = subparsers.add_parser('setup-python-experiments',
        help='Clone and prepare the Python experiments environment',
        description='Clone iamorlando/ai_experiments into the exact location, install its Python dependencies, and add available keys privately. Open and run notebooks yourself.')
    parser.add_argument('--location', required=True,
                        help='Exact checkout directory; reuse only a verified ai_experiments clone')
    parser.add_argument('--json', action='store_true', default=argparse.SUPPRESS,
                        help='Structured setup result; key values are never included')
    return parser


def _error(message, code='experiments_setup'):
    raise LabError(message, code)


def _environment():
    # A caller's active venv, installer overrides and provider keys must not
    # redirect dependency writes or become available to package build scripts.
    blocked = {'VIRTUAL_ENV', 'CONDA_PREFIX', 'CONDA_DEFAULT_ENV', 'PYTHONHOME',
               'PYTHONPATH', '__PYVENV_LAUNCHER__', *KEY_NAMES, 'JEV_API_KEY'}
    env = {name: value for name, value in os.environ.items()
           if name not in blocked and not name.startswith(('UV_', 'POETRY_', 'PIP_', 'AI_LAB_', 'GIT_CONFIG'))
           and name not in {'GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR'}}
    active_bins = {str(Path(value) / 'bin') for name in ('VIRTUAL_ENV', 'CONDA_PREFIX')
                   if (value := os.environ.get(name))}
    env['PATH'] = os.pathsep.join(part for part in env.get('PATH', '').split(os.pathsep)
                               if part not in active_bins)
    env.update(POETRY_VIRTUALENVS_CREATE='true', POETRY_VIRTUALENVS_IN_PROJECT='true',
               POETRY_VIRTUALENVS_OPTIONS_SYSTEM_SITE_PACKAGES='false',
               POETRY_NO_INTERACTION='1', UV_NO_CONFIG='1', UV_NO_ENV_FILE='1',
               GIT_TERMINAL_PROMPT='0')
    return env


def _call(command, cwd, env, step, *, allowed=(0,)):
    try:
        result = subprocess.run(command, cwd=cwd, env=env, capture_output=True,
                                text=True, stdin=subprocess.DEVNULL)
    except OSError:
        _error(f'{step} could not start. Check the required tool and rerun.')
    if result.returncode not in allowed:
        # Dependency and Git diagnostics may include credential-bearing URLs.
        # Keep them out of both human and JSON output, including exception text.
        _error(f'{step} failed (exit {result.returncode}). Check Git authentication, network access, and the repository requirements, then rerun.')
    return result


def _regular(path, *, absent=False):
    try:
        info = path.lstat()
    except FileNotFoundError:
        if absent:
            return None
        _error('A required checkout file is missing.')
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid():
        _error('A managed checkout file is a link, nonregular file, or owned by another user; it was left unchanged.', 'unsafe_location')
    return info


def _directory(path):
    if path.is_symlink() or not path.is_dir() or path.stat().st_uid != os.getuid():
        _error('A managed checkout directory is a link or owned by another user; it was left unchanged.', 'unsafe_location')


def _same_repository(remote):
    if remote.startswith('git@') and ':' in remote:
        host, path = remote[4:].split(':', 1)
        ssh = True
    else:
        parsed = urlsplit(remote)
        if parsed.scheme not in {'https', 'ssh'} or parsed.password or parsed.query or parsed.fragment:
            return False
        if parsed.scheme == 'https' and parsed.username:
            return False
        host, path = parsed.hostname or '', parsed.path
        ssh = parsed.scheme == 'ssh'
    # Accept a previously cloned owner's SSH host alias as well as the portable
    # GitHub origin, but never contact that origin during reuse.
    github = host == 'github.com' or (ssh and re.fullmatch(r'github\.com-[A-Za-z0-9_-]+', host))
    return bool(github) and path.strip('/').removesuffix('.git').lower() == 'iamorlando/ai_experiments'


def _checkout(location, git, env):
    raw = Path(location).expanduser().absolute()
    if raw.is_symlink():
        _error('The checkout location is a link; choose a real directory.', 'unsafe_location')
    destination = raw.resolve()
    if destination.exists() and not destination.is_dir():
        _error('The checkout location is not a directory.', 'unsafe_location')
    if destination.exists():
        _directory(destination)
    reused = destination.exists() and any(destination.iterdir())
    if not reused:
        destination.parent.mkdir(parents=True, exist_ok=True)
        _call([git, 'clone', '--', REPOSITORY, str(destination)], destination.parent, env, 'Repository clone')
    _directory(destination)
    _directory(destination / '.git')
    top = _call([git, 'rev-parse', '--show-toplevel'], destination, env, 'Checkout verification').stdout.strip()
    if Path(top).resolve() != destination:
        _error('The location belongs to another checkout; it was left unchanged.', 'unsafe_location')
    remote = _call([git, 'remote', 'get-url', 'origin'], destination, env, 'Origin verification').stdout.strip()
    if not _same_repository(remote):
        _error('The location is not an iamorlando/ai_experiments clone; it was left unchanged.', 'unsafe_location')
    return destination, reused


def _exclude_private_files(destination, git, env):
    tracked = _call([git, 'ls-files', '--', '.env', '.venv'], destination, env, 'Private-file tracking check')
    if tracked.stdout.strip():
        _error('The checkout tracks .env or .venv. Remove them from Git tracking before setup.', 'unsafe_location')
    info = destination / '.git/info'
    if not info.exists() and not info.is_symlink():
        info.mkdir()
    _directory(info)
    path = info / 'exclude'
    _regular(path, absent=True)
    with os.fdopen(os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600), 'r+', encoding='utf-8', newline='') as stream:
        old = stream.read()
        missing = [pattern for pattern in ('/.env', '/.venv', '/.venv/') if pattern not in old.splitlines()]
        if missing:
            stream.seek(0, os.SEEK_END)
            stream.write(('\n' if old and not old.endswith('\n') else '') + '\n'.join(missing) + '\n')
    for name in ('.env', '.venv/private-file'):
        result = _call([git, 'check-ignore', '--quiet', '--no-index', '--', name], destination, env,
                       'Private-file exclusion check', allowed=(0, 1))
        if result.returncode:
            _error('The checkout overrides local .env or .venv Git exclusions. Exclude both before setup.', 'unsafe_location')


def _venv_boundaries(venv):
    if not venv.exists() and not venv.is_symlink():
        return
    _directory(venv)
    for parent, dirs, files in os.walk(venv, followlinks=False):
        for name in dirs:
            _directory(Path(parent) / name)
        for name in files:
            path = Path(parent) / name
            # Standard virtualenv interpreters are read-only links to base Python.
            if path.is_symlink() and path.parent == venv / 'bin' and re.fullmatch(r'python(?:\d+(?:\.\d+)?)?', name):
                continue
            _regular(path)


def _verify_venv(venv, env):
    _venv_boundaries(venv)
    config = venv / 'pyvenv.cfg'
    _regular(config)
    settings = {name.strip(): value.strip() for line in config.read_text().splitlines() if '=' in line
                for name, value in [line.split('=', 1)]}
    if settings.get('include-system-site-packages', '').lower() != 'false':
        _error('The existing .venv exposes system packages; choose an isolated checkout environment.', 'unsafe_location')
    python = venv / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    probe = _call([str(python), '-I', '-c', 'import json,sys;print(json.dumps([sys.prefix,sys.base_prefix]))'],
                  venv.parent, env, 'Virtual environment verification')
    try:
        prefix, base = json.loads(probe.stdout)
        valid = Path(prefix).resolve() == venv and Path(base).resolve() != venv
    except (ValueError, TypeError):
        valid = False
    if not valid:
        _error('The .venv interpreter belongs to another environment; it was left unchanged.', 'unsafe_location')
    return python


def _install(destination, env):
    project_path = destination / 'pyproject.toml'
    _regular(project_path)
    try:
        project = tomllib.loads(project_path.read_text())
    except (ValueError, UnicodeError):
        _error('The checkout pyproject.toml is invalid.')
    metadata, tool = project.get('project', {}), project.get('tool', {})
    if not isinstance(metadata, dict) or not isinstance(tool, dict):
        _error('The checkout pyproject.toml has invalid project metadata.')
    requires_python = metadata.get('requires-python')
    poetry_settings = tool.get('poetry', {})
    if not isinstance(requires_python, str) or not requires_python.strip():
        _error('The checkout must declare project.requires-python.')
    if not isinstance(poetry_settings, dict) or not isinstance(poetry_settings.get('dependencies'), dict):
        _error('The experiments checkout must declare its Poetry dependencies; no environment was installed.')
    lock = destination / 'poetry.lock'
    _regular(lock, absent=True)
    uv = shutil.which('uv', path=env.get('PATH'))
    if not uv:
        _error('Python experiments setup requires uv. Install uv and rerun.', 'missing_tool')
    venv = destination / '.venv'
    _venv_boundaries(venv)
    if not venv.exists():
        _call([uv, '--no-config', 'venv', '--python', requires_python, str(venv)],
              destination, env, 'Python environment creation')
    python = _verify_venv(venv, env)
    poetry = shutil.which('poetry', path=env.get('PATH'))
    poetry_env = {**env, 'VIRTUAL_ENV': str(venv)}
    if poetry:
        command = [poetry]
    else:
        # uv's isolated tool environment sets VIRTUAL_ENV to its own location.
        # Reset it in the tool process before Poetry chooses its install target.
        wrapper = "import os,sys;os.environ['VIRTUAL_ENV']=sys.argv.pop(1);from poetry.console.application import main;sys.exit(main())"
        command = [uv, '--no-config', 'tool', 'run', '--isolated', '--no-env-file', '--from', 'poetry',
                   'python', '-c', wrapper, str(venv)]
    _call([*command, 'env', 'use', str(python)], destination, poetry_env, 'Poetry Python selection')
    selected = _call([*command, 'env', 'info', '--path'], destination, poetry_env, 'Poetry environment verification').stdout.strip()
    if Path(selected).resolve() != venv:
        _error('Poetry selected a foreign environment; dependency installation was refused.', 'unsafe_location')
    _call([*command, 'install', '--no-root', '--no-interaction'], destination, poetry_env, 'Poetry dependency installation')
    _verify_venv(venv, env)
    return {'manager': 'poetry', 'poetry_tool': 'installed' if poetry else 'isolated_uv_tool',
            'requires_python': requires_python, 'environment': str(venv), 'dependencies': 'installed'}


def _write_keys(destination, root):
    values = {'TYPESAFE_API_KEY': jev_key(root), 'CLM_API_KEY': os.environ.get('CLM_API_KEY', '').strip()}
    path = destination / '.env'
    _regular(path, absent=True)
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_CREAT | os.O_NOFOLLOW, 0o600), 'r', encoding='utf-8', newline='') as reader:
        info = os.fstat(reader.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid():
            _error('The .env file is shared or owned by another user; it was left unchanged.', 'unsafe_location')
        old = reader.read()
        names = set(re.findall(r'^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=', old, re.MULTILINE))
        additions = {name: value for name, value in values.items() if value and name not in names}
        if additions and not info.st_mode & stat.S_IWUSR:
            _error('The existing private .env does not allow owner writes. Add missing keys yourself or allow owner writes before rerunning.', 'unsafe_location')
        # Retain restrictive owner permissions; tighten group/world access.
        if info.st_mode & 0o077:
            os.fchmod(reader.fileno(), info.st_mode & 0o600)
        if additions:
            with os.fdopen(os.open(path, os.O_WRONLY | os.O_APPEND | os.O_NOFOLLOW), 'w', encoding='utf-8', newline='') as writer:
                current = os.fstat(writer.fileno())
                if (current.st_dev, current.st_ino) != (info.st_dev, info.st_ino) or current.st_nlink != 1:
                    _error('The .env file changed during setup; key writing was refused.', 'unsafe_location')
                if old and not old.endswith('\n'):
                    writer.write('\n')
                for name, value in additions.items():
                    writer.write(name + '=' + json.dumps(value, ensure_ascii=False) + '\n')
    return [{'name': name, 'present': name in names or name in additions,
             'added': name in additions, 'available': bool(values[name])} for name in KEY_NAMES]


def setup(root, location):
    env = _environment()
    git = shutil.which('git', path=env.get('PATH'))
    if not git:
        _error('Python experiments setup requires Git. Install Git and rerun.', 'missing_tool')
    destination, reused = _checkout(location, git, env)
    _regular(destination / '.env', absent=True)
    _venv_boundaries(destination / '.venv')
    _exclude_private_files(destination, git, env)
    installed = _install(destination, env)
    # Recheck tracking/exclusions after dependency build scripts have finished.
    _exclude_private_files(destination, git, env)
    keys = _write_keys(destination, root)
    return {'ok': True, 'repository': REPOSITORY, 'location': str(destination),
            'checkout': 'reused' if reused else 'cloned', **installed,
            'environment_keys': keys, 'notebooks': 'not_started'}


def run(args, root):
    result = setup(root, args.location)
    if getattr(args, 'json', False):
        print(json.dumps(result, ensure_ascii=False))
    else:
        print(f"Python experiments ready: {result['location']}\nEnvironment: {result['environment']}")
        for key in result['environment_keys']:
            print(f"{key['name']}: {'added privately' if key['added'] else 'present (preserved)' if key['present'] else 'not available'}")
        print('Open and run the notebooks yourself using this .venv.')
    return 0
