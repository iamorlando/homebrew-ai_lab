"""Opt-in model downloads, shared by source, packaged CLI, and website launches."""
import contextlib
import fcntl
import hashlib
import json
from pathlib import Path
import os
import shlex
import sys
import urllib.request

from ai_lab import __version__
from ai_lab.paths import RESOURCES, known_model_roots, load_backend, root_details, state_path
from ai_lab.runtime import sha256
from ai_lab.service import atomic_json
from ai_lab.download_ui import DownloadDisplay, phase, select_models, transfer, verification_phase

_CHECKED_FILES = {}

DEFAULT_MODELS = ('deepseek', 'clm')


def catalog():
    return json.loads(Path(__file__).with_name('model-downloads.json').read_text())


def fingerprint():
    from ai_lab.laya import resource_digest
    digest = hashlib.sha256(Path(__file__).with_name('model-downloads.json').read_bytes())
    digest.update(resource_digest().encode())
    from ai_lab.runtime import decisions_descriptor
    digest.update(json.dumps(decisions_descriptor(), sort_keys=True).encode())
    return __version__ + ':' + digest.hexdigest()


def present(root, file):
    try:
        return (Path(root) / file['path']).stat().st_size == file['bytes']
    except OSError:
        return False


def _catalog_digest():
    return hashlib.sha256(Path(__file__).with_name('model-downloads.json').read_bytes()).hexdigest()


def _verification_stamp(path, stat, file):
    return [str(path.resolve()), _catalog_digest(), stat.st_dev, stat.st_ino, stat.st_size,
            stat.st_mtime_ns, stat.st_ctime_ns, file['bytes'], file['sha256']]


def _read_receipts(root):
    record = Path(root) / '.state/ai-lab/weight-verification.json'
    try:
        directory = record.parent.lstat()
        metadata = record.lstat()
        if (record.is_symlink() or record.parent.is_symlink() or (Path(root) / '.state').is_symlink()
                or directory.st_uid != os.getuid() or directory.st_mode & 0o077
                or metadata.st_uid != os.getuid() or metadata.st_mode & 0o077
                or not record.is_file() or metadata.st_size > 512 * 1024):
            return {}
        value = json.loads(record.read_text())
        entries = value.get('entries') if isinstance(value, dict) and value.get('format') == 1 else None
        return entries if isinstance(entries, dict) and len(entries) <= 128 else {}
    except (OSError, ValueError):
        return {}


def _save_receipt(root, key, stamp):
    root = Path(root).resolve()
    directory = root / '.state/ai-lab'
    # Verification still works on read-only roots. Never follow a cache symlink
    # or write back into a discovered source root during attachment.
    if (directory.is_symlink() or directory.parent.is_symlink()
            or (directory / 'weight-verification.json').is_symlink()):
        return
    try:
        entries = _read_receipts(root)
        entries[key] = {'stamp': stamp, 'verified': True}
        while len(entries) > 128:
            del entries[next(iter(entries))]
        state_path(root)
        atomic_json(directory / 'weight-verification.json', {'format': 1, 'entries': entries})
    except OSError:
        pass


def verified_present(root, file, *, receipt_root=None):
    """Reuse private checksums across launches only while file identity is unchanged.

    A first check, a modified/replaced file, or a catalog change hashes the bytes.
    Receipts are local performance hints, not a defense against their own owner.
    """
    path = Path(root) / file['path']
    receipt_root = root if receipt_root is None else receipt_root
    try:
        stat = path.stat()
        if stat.st_size != file['bytes']:
            return False
        stamp = _verification_stamp(path, stat, file)
        key = hashlib.sha256(json.dumps(stamp).encode()).hexdigest()
        if key not in _CHECKED_FILES:
            receipt = _read_receipts(receipt_root).get(key)
            if isinstance(receipt, dict) and receipt.get('stamp') == stamp and receipt.get('verified') is True:
                _CHECKED_FILES[key] = True
            else:
                verification_phase(f'Verifying {path.name} (first check or changed file)', large=file['bytes'] >= 100_000_000)
                valid = sha256(path) == file['sha256']
                unchanged = _verification_stamp(path, path.stat(), file) == stamp
                _CHECKED_FILES[key] = valid and unchanged
                if valid and unchanged:
                    _save_receipt(receipt_root, key, stamp)
        return _CHECKED_FILES[key]
    except OSError:
        return False


def dependencies_ready(root, model):
    if model in {'deepseek', 'qwen'}:
        try:
            build = json.loads((Path(root) / '.state/mistral-build.json').read_text())
            source = Path(root) / 'sources.json'
            sources = json.loads((source if source.exists() else RESOURCES / 'sources.json').read_text())
            from ai_lab.runtime import compatible, descriptor
            binary = Path(build['binary'])
            return (compatible(sources, build) and os.access(binary, os.X_OK)
                    and (build.get('distribution') != 'prebuilt' or
                         build['binary_sha256'] == descriptor()['binary_sha256'])
                    and sha256(binary) == build['binary_sha256'])
        except (OSError, ValueError, KeyError, TypeError):
            return False
    if model == 'laya':
        from ai_lab.laya import installed
    else:
        from ai_lab.runtime import decisions_ready
        return decisions_ready(root)
    return installed(root)


def status(root, models=None):
    models = DEFAULT_MODELS if models is None else models
    details = root_details(root)
    candidates = known_model_roots(root)
    rows = []
    for name, model in catalog().items():
        if models is not None and name not in models:
            continue
        missing = [file for file in model['files'] if not verified_present(root, file)]
        ready = dependencies_ready(root, name)
        # Other roots are a size-only hint until an explicit setup verifies SHA.
        other = [{'root': str(candidate), 'size_matching_files': [f['path'] for f in missing if present(candidate, f)],
                  'verified': False, 'command': f'ai-lab --root {shlex.quote(str(candidate))} setup list --json'}
                 for candidate in candidates if any(present(candidate, f) for f in missing)]
        rows.append({'name': name, 'label': 'Native CLM' if name == 'clm' else model['label'], **details,
                     'download_bytes': sum(f['bytes'] for f in model['files']),
                     'missing_bytes': sum(f['bytes'] for f in missing),
                     'missing_files': [{'path': f['path'], 'bytes': f['bytes'],
                                        'reason': 'checksum-mismatch' if present(root, f) else 'missing-or-incomplete'}
                                       for f in missing],
                     'weights_present': not missing, 'dependencies_ready': ready,
                     'runtime_status': 'ready' if ready else 'setup-required',
                     'installed': not missing and ready, 'other_roots': other,
                     'dependencies': 'verified prebuilt native Metal server' if name == 'clm' else model['dependencies']})
        rows[-1]['status'] = ((f"{rows[-1]['missing_bytes']} weight bytes missing or invalid" if missing else
                              'weights verified') + ('; runtime ready' if ready else '; runtime setup required')
                             + f". Data root: {details['root']}"
                             + ''.join(f". Possible files at {r['root']} (unverified); inspect: {r['command']}" for r in other))
    return rows


def missing_weights_message(root, family, row=None):
    row = row or status(root, models=(family,))[0]
    files = ', '.join(f"{f['path']} ({f['bytes']} bytes; {f['reason']})" for f in row.get('missing_files', []))
    other = ' '.join(f"Possible existing files at {r['root']} (size only, unverified). Inspect: {r['command']}."
                     for r in row.get('other_roots', []))
    return (f"{family} weights missing or invalid at data root {Path(root).resolve()}: "
            f"{row.get('missing_bytes', 'unknown')} bytes. {files}. "
            f"Run ai-lab --root {shlex.quote(str(Path(root).resolve()))} setup install {family} --yes. {other}").strip()


def _model_path(root, file):
    """Catalog-only paths with no traversal or escaping symlink parents."""
    relative = Path(file['path'])
    if relative.is_absolute() or '..' in relative.parts or relative.parts[:1] != ('.models',):
        raise ValueError('Model reuse requires a catalog path below .models.')
    root = Path(root).resolve()
    target = root / relative
    if not target.resolve().is_relative_to(root):
        raise ValueError(f'Model reuse path escapes its root: {target}')
    return target


def reuse_weights(root, model):
    """Attach verified weights from one known root, without changing originals.

    Only default installed-root selection permits automatic attachment. Explicit
    roots get status guidance instead. Existing files and partials are untouched;
    multiple size-matching source roots require an explicit choice.
    """
    if not root_details(root)['automatic_reuse']:
        return []
    manifest = Path(root) / 'sources.json'
    try:
        bundled = json.loads((RESOURCES / 'sources.json').read_text())
        if manifest.is_symlink() or (manifest.exists() and json.loads(manifest.read_text()) != bundled):
            return []
        template = Path(root) / bundled['chat_template']['file']
        if template.is_symlink() or (template.exists() and sha256(template) != bundled['chat_template']['sha256']):
            return []
    except (OSError, ValueError, KeyError):
        return []
    missing = [f for f in model['files'] if not verified_present(root, f)]
    eligible = []
    for file in missing:
        target = _model_path(root, file)
        partial = target.with_name(target.name + '.part')
        if not target.exists() and not target.is_symlink() and not partial.exists() and not partial.is_symlink():
            eligible.append(file)
    candidates = [p for p in known_model_roots(root) if any(present(p, f) for f in eligible)]
    if len(candidates) > 1:
        raise ValueError('Existing model files occur under multiple known roots: ' + ', '.join(map(str, candidates))
                         + '. Choose one with ai-lab --root PATH; no files were attached.')
    if not candidates:
        return []
    source_root = candidates[0]
    # Verify every selected attachment before creating any link. An invalid
    # source is never silently replaced by a download during discovery.
    attachments = []
    for file in eligible:
        if not present(source_root, file):
            continue
        source = _model_path(source_root, file)
        if not verified_present(source_root, file, receipt_root=root):
            raise ValueError(f'Existing model checksum mismatch: {source}. Original files were preserved; '
                             'inspect that root or explicitly select the intended data root.')
        attachments.append((file, source, source.stat()))
    reused = []
    for file, source, before in attachments:
        target = _model_path(root, file)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.symlink_to(source)
        after = source.stat()
        if before != after or not verified_present(root, file):
            target.unlink()  # Only the link just created here, never its source.
            raise ValueError(f'Existing model changed during verification: {source}. Retry setup.')
        reused.append(file['path'])
    return reused


def download_file(root, file, verified):
    with transfer(Path(file['path']).name, file['bytes'], weights=True) as update:
        return _download_file(root, file, verified, update)


def _download_file(root, file, verified, update):
    target = Path(root) / file['path']
    phase(f"Checking {target.name}")
    if present(root, file):
        stat = target.stat()
        stamp = {'bytes': stat.st_size, 'mtime_ns': stat.st_mtime_ns, 'sha256': file['sha256']}
        if verified_present(root, file):
            verified[file['path']] = stamp
            update(file['bytes'])
            return
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_name(target.name + '.part')
    offset = partial.stat().st_size if partial.is_file() else 0
    if offset >= file['bytes']:
        if offset == file['bytes'] and sha256(partial) == file['sha256']:
            partial.replace(target)
            verified[file['path']] = {'bytes': target.stat().st_size, 'mtime_ns': target.stat().st_mtime_ns, 'sha256': file['sha256']}
            update(file['bytes'])
            return
        partial.unlink()
        offset = 0
    headers = {'User-Agent': 'AI-Lab'}
    if offset:
        headers['Range'] = f'bytes={offset}-'
    request = urllib.request.Request(file['url'], headers=headers)
    phase(f'Downloading {target.name}')
    with urllib.request.urlopen(request, timeout=60) as response:
        resumed = offset > 0 and response.status == 206
        if resumed and not response.headers.get('Content-Range', '').startswith(f'bytes {offset}-'):
            raise ValueError('Model download returned an invalid resume range.')
        received = offset if resumed else 0
        update(received)
        with partial.open('ab' if resumed else 'wb') as output:
            while data := response.read(1024 * 1024):
                received += len(data)
                if received > file['bytes']:
                    partial.unlink(missing_ok=True)
                    raise ValueError(f"Download exceeds the pinned size: {file['path']}")
                output.write(data)
                update(received)
    phase(f'Verifying {target.name}')
    if partial.stat().st_size != file['bytes'] or sha256(partial) != file['sha256']:
        partial.unlink(missing_ok=True)
        raise ValueError(f"Model checksum mismatch: {file['path']}. Existing weights were preserved.")
    partial.replace(target)
    verified[file['path']] = {'bytes': target.stat().st_size, 'mtime_ns': target.stat().st_mtime_ns, 'sha256': file['sha256']}


def install(root, models=DEFAULT_MODELS, yes=False):
    models = list(dict.fromkeys(models))
    selected = catalog()
    if not models or any(name not in selected for name in models):
        raise ValueError('Choose deepseek, qwen, clm, laya, or a combination.')
    if not yes:
        if not sys.stdin.isatty():
            raise ValueError('Model downloads need --yes in scripts. Inspect ai-lab setup list --json first.')
        rows = [row for row in status(root) if row['name'] in models and not row['installed']]
        if not rows:
            return {'installed': [], 'reason': 'already-installed'}
        models = select_models(rows)
        if not models:
            return {'installed': [], 'reason': 'declined'}
    directory = state_path(root)
    with DownloadDisplay() as display, (directory / 'model-downloads.lock').open('a') as lock:
        display.phase('Waiting for the download lock')
        fcntl.flock(lock, fcntl.LOCK_EX)
        if root_details(root)['automatic_reuse']:
            # The existing exact-default migration runs before deciding whether
            # a selected manifest is custom. It never merges another root's data.
            from ai_lab.setup import prepare
            prepare(Path(root))
        record = directory / 'verified-model-downloads.json'
        try:
            verified = json.loads(record.read_text())
        except (OSError, ValueError):
            verified = {}
        reused = []
        for name in models:
            reused.extend(reuse_weights(root, selected[name]))
        total = sum(f['bytes'] for name in models for f in selected[name]['files'] if not verified_present(root, f))
        display.overall.update(display.overall_id, total=total, visible=total > 0)
        for name in models:
            for file in selected[name]['files']:
                if not verified_present(root, file):
                    download_file(root, file, verified)
                    atomic_json(record, verified)
            with contextlib.redirect_stdout(sys.stderr):
                phase(f"Setting up {selected[name]['label'].split(' (')[0]} dependencies")
                if name == 'deepseek':
                    from ai_lab.setup import setup
                    setup(Path(root), yes=True)
                    continue
                elif name == 'qwen':
                    from ai_lab.setup import prepare
                    from ai_lab.runtime import install as install_runtime
                    prepare(Path(root))
                    install_runtime(Path(root))
                    load_backend(root)
                    import inference
                    inference._verified = None
                    inference.verify_installation('qwen')
                    continue
                elif name == 'laya':
                    from ai_lab.laya import setup
                else:
                    from ai_lab.runtime import install_decisions
                    install_decisions(Path(root))
                    continue
                setup(Path(root))
    return {'installed': models, 'reused_files': reused, 'root': str(root)}


def offer(root, *, yes=False, force=False):
    """Ask once per application/catalog update; leave noninteractive runs pending."""
    stamp = Path(root) / '.state/ai-lab/model-offer.json'
    token = fingerprint()
    try:
        previous = json.loads(stamp.read_text())
        if not force and previous.get('release') == token:
            return {'offered': False, 'reason': 'already-offered',
                    'selected': previous.get('selected', [])}
    except (OSError, ValueError):
        pass
    if not yes and not sys.stdin.isatty():
        return {'offered': False, 'reason': 'needs-terminal'}
    rows = status(root)
    missing = [row['name'] for row in rows if not row['weights_present']]
    repairs = [row['name'] for row in rows if row['weights_present'] and not row['dependencies_ready']]
    pending = missing + repairs
    result = install(root, pending, yes=yes) if pending else {'installed': [], 'reason': 'already-downloaded'}
    repairs = [name for name in repairs if name not in result.get('installed', [])]
    # A failed or interrupted download is retried; declining is remembered only
    # for this release. An update offers newly available models again.
    state_path(root)
    atomic_json(stamp, {'release': token, 'accepted': result.get('reason') != 'declined',
                        'selected': result.get('installed', [])})
    return {'offered': True, 'root': str(Path(root).resolve()), 'runtime_setup_required': repairs, **result}
