"""Guarded Herdr discovery, then input through the exact app-owned session socket."""
import asyncio
import json
import math
import os
from pathlib import Path
import stat
import time
import uuid

from ai_lab.agent_channel import MAX_FRAME
from ai_lab.client import LabError
from ai_lab.herdr import HerdrContext, _command, _identifier


async def agent_prompt(pane, prompt, *, session_id=None, wait=False, timeout=30,
                       environment=None, runner=None):
    """Submit once to a live UI, never terminal input or a shell fallback."""
    if not _identifier(pane):
        raise ValueError('An explicit Herdr pane ID is required.')
    if (not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 24000
            or '\x00' in prompt or len(prompt.encode('utf-8')) > MAX_FRAME - 1024):
        raise ValueError('Supply a nonempty bounded prompt up to 24,000 characters without NUL.')
    if not math.isfinite(timeout) or timeout <= 0:
        raise ValueError('Prompt timeout must be positive and finite.')
    environment = dict(os.environ if environment is None else environment)
    context = HerdrContext.from_environment(environment)
    if context is None:
        raise LabError('agent-prompt requires a valid Herdr environment.', 'herdr_unavailable')
    runner = runner or (lambda argv: _command(argv, environment))
    deadline = time.monotonic() + timeout
    submitted = False

    async def bounded(awaitable):
        return await asyncio.wait_for(awaitable, max(.001, deadline - time.monotonic()))

    async def call(*arguments):
        try:
            return await bounded(runner([context.binary, 'pane', *arguments]))
        except Exception as error:
            raise LabError('Unable to validate the Herdr target; no prompt was submitted.',
                           'herdr_unavailable') from error

    async def snapshot(expected=None):
        raw = await call('get', pane)
        try:
            info = json.loads(raw)['result']['pane']
            tokens = info['tokens']
            actual_session = tokens['ai_lab_session']
            pid = int(tokens['ai_lab_pid'])
            age = (time.time_ns() - int(tokens['ai_lab_updated'])) / 1e9
            state = tokens['ai_lab_state']
            path = Path(tokens['ai_lab_input'])
            valid = (info['pane_id'] == pane and info.get('agent') == 'ai-lab'
                     and tokens['ai_lab_protocol'] == '1' and _identifier(actual_session)
                     and pid > 0 and 0 <= age <= 5 and state in {'idle', 'working', 'blocked'}
                     and (expected is None or actual_session == expected))
            if not valid:
                raise ValueError('Invalid or stale custom session.')
            socket_stat, parent_stat = path.lstat(), path.parent.lstat()
            if (not path.is_absolute() or not stat.S_ISSOCK(socket_stat.st_mode)
                    or not stat.S_ISDIR(parent_stat.st_mode)
                    or socket_stat.st_uid != os.getuid() or parent_stat.st_uid != os.getuid()
                    or (socket_stat.st_mode | parent_stat.st_mode) & 0o077):
                raise ValueError('Session channel is not private.')
        except (KeyError, TypeError, ValueError, OSError) as error:
            raise LabError('Target is not the exact live AI Lab chat session with a private input channel.',
                           'agent_not_ready') from error
        return info, actual_session, pid, state, path

    def ready(info, state):
        if state == 'blocked' or info['agent_status'] == 'blocked':
            raise LabError('The target is waiting for a user decision; use its approval UI.', 'agent_blocked')
        if state != 'idle' or info['agent_status'] not in {'idle', 'done'}:
            raise LabError('The target is busy or not ready for a prompt.', 'agent_busy')

    info, actual_session, pid, state, path = await snapshot(session_id)
    ready(info, state)
    raw = await call('process-info', '--pane', pane)
    try:
        processes = json.loads(raw)['result']['process_info']
        if (processes['pane_id'] != pane
                or not any(process['pid'] == pid for process in processes['foreground_processes'])):
            raise ValueError('Foreground process changed.')
    except (KeyError, TypeError, ValueError) as error:
        raise LabError('AI Lab session process is no longer foreground; no input sent.', 'agent_not_ready') from error
    info, _, second_pid, state, second_path = await snapshot(actual_session)
    ready(info, state)
    if second_pid != pid or second_path != path:
        raise LabError('AI Lab session process/channel changed; no input sent.', 'agent_not_ready')
    request_id = str(uuid.uuid4())
    writer = None
    try:
        reader, writer = await bounded(asyncio.open_unix_connection(path=path, limit=MAX_FRAME))
        request = {'op': 'submit', 'session_id': actual_session, 'request_id': request_id,
                   'prompt': prompt, 'wait': bool(wait)}
        # From writing onward, delivery may be ambiguous. No automatic retries.
        submitted = True
        writer.write((json.dumps(request, ensure_ascii=False) + '\n').encode())
        await bounded(writer.drain())
        observed_working = False
        while True:
            raw = await bounded(reader.readline())
            if not raw:
                raise ValueError('Session channel closed before acknowledgement.')
            event = json.loads(raw)
            if event.get('status') == 'rejected':
                code = event.get('code', 'agent_not_ready')
                if code not in {'agent_busy', 'agent_blocked', 'agent_not_ready', 'request_already_seen', 'session_request_limit'}:
                    code = 'agent_not_ready'
                raise LabError('The live UI rejected the request; no chat turn was started.', code)
            if event.get('session_id') != actual_session or event.get('request_id') != request_id:
                raise ValueError('Session acknowledgement did not match the exact request.')
            status = event.get('status')
            if status == 'working':
                observed_working = True
            result = {**event, 'pane': pane, 'transport': 'ai-lab-session-socket',
                      'observed_working': observed_working}
            if status == 'accepted' and not wait:
                return result
            if status == 'blocked':
                return result
            if status == 'settled' and observed_working:
                return result
            if status not in {'accepted', 'working', 'settled'}:
                raise ValueError('Invalid session progress event.')
    except LabError:
        raise
    except (ValueError, TypeError, OSError, asyncio.TimeoutError) as error:
        message = ('Prompt delivery/completion is uncertain; inspect the pane before retrying.'
                   if submitted else 'The live AI Lab input channel exited; no terminal input was sent.')
        raise LabError(message, 'prompt_ambiguous' if submitted else 'agent_not_ready') from error
    finally:
        if writer is not None:
            writer.close()
            try:
                await writer.wait_closed()
            except (OSError, ConnectionError):
                pass
