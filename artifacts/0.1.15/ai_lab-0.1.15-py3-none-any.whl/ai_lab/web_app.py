"""Open the local website in an existing browser's dedicated app window."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import webbrowser

from ai_lab.paths import state_path


def app_browsers():
    """Find native Chromium browsers without installing or changing defaults."""
    if sys.platform == 'darwin':
        for folder in (Path('/Applications'), Path.home() / 'Applications'):
            for name, executable in (('Google Chrome', 'Google Chrome'),
                                     ('Microsoft Edge', 'Microsoft Edge'),
                                     ('Brave Browser', 'Brave Browser'),
                                     ('Chromium', 'Chromium')):
                path = folder / f'{name}.app/Contents/MacOS/{executable}'
                if path.is_file() and os.access(path, os.X_OK):
                    yield path
    elif sys.platform == 'win32':
        for variable in ('LOCALAPPDATA', 'PROGRAMFILES', 'PROGRAMFILES(X86)'):
            if folder := os.environ.get(variable):
                for relative in ('Google/Chrome/Application/chrome.exe',
                                 'Microsoft/Edge/Application/msedge.exe',
                                 'BraveSoftware/Brave-Browser/Application/brave.exe'):
                    path = Path(folder) / relative
                    if path.is_file():
                        yield path
    else:
        for name in ('google-chrome', 'google-chrome-stable', 'chromium',
                     'chromium-browser', 'microsoft-edge', 'brave-browser'):
            if executable := shutil.which(name):
                yield Path(executable)


def open_website(root, url, browser=False):
    """Prefer an app window; fall back to the user's normal browser."""
    if not browser:
        for executable in app_browsers():
            try:
                # This profile belongs to the workspace, survives CLI updates,
                # and never touches a user's regular browser profile.
                profile = state_path(root) / 'web-app'
                profile.mkdir(exist_ok=True, mode=0o700)
                profile.chmod(0o700)
                env = {key: value for key, value in os.environ.items()
                       if not key.endswith(('_KEY', '_TOKEN', '_PASSWORD', '_SECRET'))}
                process = subprocess.Popen(
                    [str(executable), f'--app={url}', f'--user-data-dir={profile}',
                     '--no-first-run', '--no-default-browser-check'],
                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL, env=env, start_new_session=True)
                try:
                    code = process.wait(timeout=.25)
                except subprocess.TimeoutExpired:
                    return 'app'
                # A second invocation hands the URL to the existing app process.
                if code == 0:
                    return 'app'
            except OSError:
                continue
    try:
        if webbrowser.open(url):
            return 'browser'
    except webbrowser.Error:
        pass
    print(f'Open AI Lab in your browser: {url}', file=sys.stderr)
    return 'manual'
