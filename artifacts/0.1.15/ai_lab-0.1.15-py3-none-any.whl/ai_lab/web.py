"""Launch the website with persistent DeepSeek and CLM APIs."""
import errno
import json
import os
from pathlib import Path
import socket
import threading

import httpx

from ai_lab.paths import load_backend
from ai_lab.credentials import sync_jev_key
from ai_lab.web_app import open_website


def existing_site(root, port):
    """Reuse only this workspace's persistent two-API website contract."""
    try:
        with httpx.Client(timeout=2, trust_env=False) as client:
            response = client.get(f'http://127.0.0.1:{port}/api/workspace')
            response.raise_for_status()
            identity = response.json()
        return (identity.get('kind') == 'deepseek-comparison' and identity.get('root') == str(root)
                and identity.get('api_lifetime') == 'web-process'
                and identity.get('supported_models') == ['deepseek', 'clm']
                and identity.get('runtime_mode') == (
                    'fixture' if os.environ.get('AI_LAB_GENERATION_FIXTURE_FILE') else 'native'))
    except (httpx.HTTPError, ValueError, AttributeError):
        return False


def announce(root, url, existing, structured):
    if structured:
        print(json.dumps({'url': url, 'root': str(root), 'existing': existing,
                          'status': 'running'}), flush=True)
    else:
        print(f'AI Lab website: {url}', flush=True)
        if not existing:
            print('Keep this terminal open: DeepSeek and CLM APIs stay available until exit. '
                  'Press Ctrl+C to stop the website and its owned APIs.', flush=True)


def run(root, port=8080, no_browser=False, yes=False, no_setup=False, structured=False, browser=False):
    from ai_lab.setup import prepare
    if not 1 <= port <= 65535:
        raise ValueError('Choose a web port between 1 and 65535.')
    root = Path(root).resolve()
    url = f'http://127.0.0.1:{port}/completion'
    listener = socket.socket()
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    finished = threading.Event()
    try:
        try:
            listener.bind(('127.0.0.1', port))
        except OSError as error:
            if error.errno != errno.EADDRINUSE:
                raise
            if not existing_site(root, port):
                raise ValueError(f'Port {port} belongs to another service, workspace, or older website launcher. '
                                 'That process was left untouched. Use a compatible launcher or choose '
                                 f'--port {port + 1 if port < 65535 else 8080}.') from error
            sync_jev_key(root)
            announce(root, url, True, structured)
            if not no_browser:
                open_website(root, url, browser=browser)
            return 0
        prepare(root)
        sync_jev_key(root)
        load_backend(root)
        # The app lifespan starts both local APIs without implicit setup or
        # downloads. Uvicorn reports ready only after both APIs are usable.
        from comparison_app import create_app
        import uvicorn
        app = create_app(root=root)
        server = uvicorn.Server(uvicorn.Config(app, host='127.0.0.1', port=port, log_level='warning'))
        def ready():
            while not finished.wait(.05):
                if server.started:
                    announce(root, url, False, structured)
                    if not no_browser:
                        open_website(root, url, browser=browser)
                    return
        threading.Thread(target=ready, daemon=True).start()
        server.run(sockets=[listener])
        return 0 if server.started else 1
    except KeyboardInterrupt:
        return 130
    finally:
        finished.set()
        listener.close()
