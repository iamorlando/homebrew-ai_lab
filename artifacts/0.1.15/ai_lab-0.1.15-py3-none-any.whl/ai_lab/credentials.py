"""Private credential handoff between CLI launches and the running website."""
import os
from pathlib import Path
import tempfile

from ai_lab.paths import state_path

JEV_ENV_NAMES = ('TYPESAFE_API_KEY', 'JEV_API_KEY')


def environment_jev_key():
    return next((value for name in JEV_ENV_NAMES
                 if (value := os.environ.get(name, '').strip())), '')


def jev_key(root):
    """Read the latest CLI-synced key on each request, then try launch environment."""
    try:
        saved = (Path(root) / '.state/ai-lab/jev-api-key').read_text().strip()
    except OSError:
        saved = ''
    return saved or environment_jev_key()


def sync_jev_key(root):
    """Atomically sync an available environment key without logging or HTTP transport.

    An environment without a key preserves the last configured key. A later CLI
    launch with a new key rotates it even when the website process is reused.
    """
    key = environment_jev_key()
    if not key:
        return False
    directory = state_path(root)
    path = directory / 'jev-api-key'
    try:
        if path.read_text().strip() == key and path.stat().st_mode & 0o777 == 0o600:
            return False
    except OSError:
        pass
    descriptor, name = tempfile.mkstemp(prefix='.jev-key-', dir=directory)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, 'w') as stream:
            stream.write(key + '\n')
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)
    return True
