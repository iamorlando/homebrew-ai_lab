"""Build the pinned sibling mistral.rs fork and download public model assets."""
import hashlib
import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tempfile
import sys

from project_paths import ROOT
SOURCES = json.loads((ROOT / 'sources.json').read_text())
MISTRAL_DIR = Path(os.environ.get('MISTRAL_DIR', ROOT.parent / 'mistral')).expanduser().resolve()


def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def checked_output(command, **kwargs):
    return subprocess.check_output(command, text=True, **kwargs).strip()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--use-local-source', action='store_true', help='Build existing local source changes and record their provenance without checking out or modifying source files.')
    parser.add_argument("--completion-only", action="store_true", help="Build the runtime without requiring Docker or OpenCode.")
    args = parser.parse_args(argv)
    if platform.system() != 'Darwin' or platform.machine() != 'arm64':
        raise RuntimeError('This Metal bootstrap requires Apple Silicon macOS.')
    for tool in ('git', 'cargo', 'rustc', 'rustup', 'clang', *(() if args.completion_only else ('docker',))):
        if not shutil.which(tool):
            raise RuntimeError(f'Missing source-build prerequisite: {tool}. Install Rust via rustup and Apple Command Line Tools.' + ('' if args.completion_only else ' Docker Desktop is also required.'))
    state = ROOT / '.state'
    state.mkdir(exist_ok=True)
    runtime = SOURCES['runtime']
    if not MISTRAL_DIR.exists():
        subprocess.run(['git', 'clone', runtime['repository'], str(MISTRAL_DIR)], check=True)
    origin = checked_output(['git', 'config', '--get', 'remote.origin.url'], cwd=MISTRAL_DIR)
    if origin.removesuffix('.git') not in {runtime['repository'].removesuffix('.git'), 'git@github.com:iamorlando/mistral.rs'}:
        raise RuntimeError(f'{MISTRAL_DIR}: origin must be the iamorlando/mistral.rs fork; found {origin}')
    if not args.use_local_source and checked_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=MISTRAL_DIR):
        raise RuntimeError(f'{MISTRAL_DIR} has source changes; commit or save them before building the pinned revision.')
    if subprocess.run(['git', 'cat-file', '-e', runtime['commit'] + '^{commit}'], cwd=MISTRAL_DIR, stderr=subprocess.DEVNULL).returncode:
        subprocess.run(['git', 'fetch', 'origin', runtime['commit']], cwd=MISTRAL_DIR, check=True)
    if not args.use_local_source and checked_output(['git', 'rev-parse', 'HEAD'], cwd=MISTRAL_DIR) != runtime['commit']:
        subprocess.run(['git', 'checkout', '--detach', runtime['commit']], cwd=MISTRAL_DIR, check=True)
    library = MISTRAL_DIR.parent / 'llm_watermarking'
    library_source = SOURCES['watermark_library']
    if not library.exists():
        subprocess.run(['git', 'clone', library_source['repository'], str(library)], check=True)
        subprocess.run(['git', 'checkout', '--detach', library_source['commit']], cwd=library, check=True)
    if not args.use_local_source:
        if checked_output(['git', 'status', '--porcelain'], cwd=library):
            raise RuntimeError('The sibling llm_watermarking checkout has local changes. Use --use-local-source to build and record them.')
        if subprocess.run(['git', 'cat-file', '-e', library_source['commit'] + '^{commit}'], cwd=library, stderr=subprocess.DEVNULL).returncode:
            subprocess.run(['git', 'fetch', 'origin', library_source['commit']], cwd=library, check=True)
        if checked_output(['git', 'rev-parse', 'HEAD'], cwd=library) != library_source['commit']:
            subprocess.run(['git', 'checkout', '--detach', library_source['commit']], cwd=library, check=True)
    compiler = checked_output(['rustc', '--version'])
    cargo = ['cargo']
    if compiler.split()[1] != runtime['rust_version']:
        subprocess.run(['rustup', 'toolchain', 'install', runtime['rust_version'], '--profile', 'minimal'], check=True)
        cargo += ['+' + runtime['rust_version']]
        compiler = checked_output(['rustup', 'run', runtime['rust_version'], 'rustc', '--version'])
    env = os.environ.copy()
    env['CARGO_NET_GIT_FETCH_WITH_CLI'] = 'true'
    # Metal compiles the embedded kernels through the OS framework on first use.
    # Source builds therefore need Command Line Tools, not full Xcode/Metal SDKs.
    env['MISTRALRS_METAL_PRECOMPILE'] = '0'
    env.setdefault('MACOSX_DEPLOYMENT_TARGET', '15.0')
    flags = ['--locked', '--release', '--package', runtime['package'], '--no-default-features', '--features', ','.join(runtime['features'])]
    for action in ('build', 'check'):
        command = [*cargo, action, *flags]
        print(' '.join(command), flush=True)
        with (state / f'mistral-{action}.log').open('a') as log:
            subprocess.run(command, cwd=MISTRAL_DIR, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    metadata = json.loads(checked_output([*cargo, 'metadata', '--no-deps', '--format-version', '1'], cwd=MISTRAL_DIR, env=env))
    built_binary = Path(metadata['target_directory']) / 'release/mistralrs'
    # Keep this project's verified runtime independent of other sibling builds.
    binary = ROOT / '.runtime/mistral/mistralrs'
    binary.parent.mkdir(parents=True, exist_ok=True)
    # Replacing the inode avoids stale macOS code-signature cache entries when
    # updating an executable that is still running. Validate before activation.
    with tempfile.TemporaryDirectory(prefix='.build-', dir=binary.parent) as directory:
        staged_binary = Path(directory) / binary.name
        shutil.copy2(built_binary, staged_binary)
        version = checked_output([str(staged_binary), '--version'])
        staged_binary.replace(binary)
    def source_record(directory):
        files = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=directory, text=True).splitlines()
        digest = hashlib.sha256()
        for name in sorted(set(files)):
            path = directory / name
            if path.is_file():
                digest.update(name.encode() + b'\0' + path.read_bytes())
        return {'commit': checked_output(['git', 'rev-parse', 'HEAD'], cwd=directory),
                'dirty': bool(checked_output(['git', 'status', '--porcelain'], cwd=directory)),
                'source_sha256': digest.hexdigest()}
    build = {
        'repository': runtime['repository'], 'commit': checked_output(['git', 'rev-parse', 'HEAD'], cwd=MISTRAL_DIR),
        'source_directory': str(MISTRAL_DIR), 'binary': str(binary),
        'binary_sha256': sha256(binary), 'cargo_lock_sha256': sha256(MISTRAL_DIR / 'Cargo.lock'),
        'rustc': compiler, 'features': runtime['features'],
        'version': version,
        'watermark_support': True, 'source': source_record(MISTRAL_DIR),
        'watermark_library': source_record(library),
    }
    (state / 'mistral-build.json').write_text(json.dumps(build, indent=2) + '\n')
    download_assets()
    print(f'Ready: {binary}', flush=True)


def download_assets():
    env = os.environ.copy()
    env.update(HF_HOME=str(ROOT / '.runtime/huggingface'), HF_HUB_DISABLE_IMPLICIT_TOKEN='1', HF_HUB_DISABLE_TELEMETRY='1')
    model = SOURCES['model']
    model_dir = ROOT / '.models/deepseek-r1'
    weights = model_dir / model['filename']
    if not weights.exists() or sha256(weights) != model['weights_sha256']:
        subprocess.run([str(Path(sys.executable).parent / 'hf'), 'download', model['repository'], model['filename'], '--revision', model['revision'], '--local-dir', str(model_dir)], env=env, check=True, stdout=sys.stderr)
    if sha256(weights) != model['weights_sha256']:
        raise RuntimeError('Model checksum does not match sources.json')
    assets = SOURCES['assets']
    asset_dir = ROOT / '.models/deepseek-assets'
    if any(not (asset_dir / name).exists() for name in assets['files']):
        subprocess.run([str(Path(sys.executable).parent / 'hf'), 'download', assets['repository'], *assets['files'], '--revision', assets['revision'], '--local-dir', str(asset_dir)], env=env, check=True, stdout=sys.stderr)
    for name, expected in assets['sha256'].items():
        if sha256(asset_dir / name) != expected:
            raise RuntimeError(f'Model asset checksum mismatch: {name}')
    from ai_lab.download_ui import phase
    phase('DeepSeek weights and tokenizer verified')


if __name__ == '__main__':
    main()
