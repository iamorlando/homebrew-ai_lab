"""Independent Qwen3 last-token encoder for upstream CLM on Apple Silicon.

The upstream CLM source is unchanged. This replaces its external CUDA/vLLM
embedding service with the same local Qwen weights in Transformers/PyTorch.
Raw tokenization, causal attention and final non-padding-token pooling match
the reference recipe; no chat template or instruction prefix is applied.
"""
import argparse
import base64
from contextlib import asynccontextmanager
import threading

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import torch
from transformers import AutoModel, AutoTokenizer
import uvicorn


class EmbeddingInput(BaseModel):
    model: str = 'qwen3-8b'
    input: str | list[str] = Field(min_length=1)
    encoding_format: str = 'float'
    truncate_prompt_tokens: int = Field(default=2048, ge=1, le=2048)


def create_app(path):
    @asynccontextmanager
    async def lifespan(app):
        device = 'mps' if torch.backends.mps.is_available() else 'cpu'
        dtype = torch.bfloat16 if device == 'mps' else torch.float32
        tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True, padding_side='right')
        tokenizer.truncation_side = 'left'  # vLLM's truncate_prompt_tokens keeps the final tokens.
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token = tokenizer.eos_token
        print(f'Loading independent Qwen3 encoder on {device} ({dtype})…', flush=True)
        model = AutoModel.from_pretrained(path, local_files_only=True, torch_dtype=dtype,
                                          attn_implementation='eager').eval().to(device)
        app.state.encoder = model, tokenizer, device
        print('Independent Qwen3 encoder ready.', flush=True)
        yield

    app = FastAPI(title='Qwen3 independent reference encoder', lifespan=lifespan)
    lock = threading.Lock()

    @app.get('/v1/models')
    def models():
        return {'object': 'list', 'data': [{'id': 'qwen3-8b', 'object': 'model'}]}

    @app.get('/health')
    def health():
        return {'ok': True, 'backend': 'transformers', 'device': app.state.encoder[2],
                'pooling': 'last-token', 'dtype': str(app.state.encoder[0].dtype)}

    @app.post('/v1/embeddings')
    def embed(body: EmbeddingInput):
        if body.model != 'qwen3-8b':
            raise HTTPException(404, 'Unknown encoder model.')
        if body.encoding_format not in {'float', 'base64'}:
            raise HTTPException(422, 'Expected float or base64 encoding.')
        texts = [body.input] if isinstance(body.input, str) else body.input
        if len(texts) > 255 or any(not text for text in texts):
            raise HTTPException(422, 'Supply 1–255 nonempty texts.')
        model, tokenizer, device = app.state.encoder
        data, tokens = [], 0
        with lock, torch.inference_mode():
            # Avoid padding and batch-dependent rounding in this reference path.
            for index, text in enumerate(texts):
                inputs = tokenizer(text, return_tensors='pt', truncation=True,
                                   max_length=body.truncate_prompt_tokens, add_special_tokens=True).to(device)
                tokens += int(inputs['attention_mask'].sum().item())
                hidden = model(**inputs, use_cache=False).last_hidden_state
                vector = hidden[0, -1].float().cpu().numpy()
                encoded = (base64.b64encode(vector.astype('<f4').tobytes()).decode('ascii')
                           if body.encoding_format == 'base64' else vector.tolist())
                data.append({'object': 'embedding', 'index': index, 'embedding': encoded})
        return {'object': 'list', 'model': body.model, 'data': data,
                'usage': {'prompt_tokens': tokens, 'total_tokens': tokens}}

    return app


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', required=True)
    parser.add_argument('--port', type=int, default=8090)
    args = parser.parse_args()
    uvicorn.run(create_app(args.model), host='127.0.0.1', port=args.port, log_level='warning')
