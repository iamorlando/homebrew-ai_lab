"""Independent known-key tests for Mistral's aggregate watermark evidence.

Confidence is 1 - a one-sided null tail probability (or conservative bound),
not a posterior probability of authorship. No other candidate enters a test.
"""
import math

SCORING_VERSION = 2
MATCH_P_VALUE = 0.001
MIN_TOKENS = 20


def binomial_tail(successes, trials, probability):
    """P[Binomial(trials, probability) >= successes], with stable small tails."""
    if successes <= 0:
        return 1.0
    if successes > trials:
        return 0.0

    def sum_tail(k, upper):
        log_mass = (math.lgamma(trials + 1) - math.lgamma(k + 1) - math.lgamma(trials - k + 1)
                    + k * math.log(probability) + (trials - k) * math.log1p(-probability))
        term = total = 1.0
        while (k < trials) if upper else (k > 0):
            if upper:
                term *= (trials - k) * probability / ((k + 1) * (1 - probability))
                k += 1
            else:
                term *= k * (1 - probability) / ((trials - k + 1) * probability)
                k -= 1
            total += term
            if term <= total * 1e-15:
                break
        return math.exp(log_mass + math.log(total))

    value = sum_tail(successes, True) if successes > trials * probability else 1 - sum_tail(successes - 1, False)
    return min(1.0, max(0.0, value))


def key_evidence(config, evidence):
    n = evidence.get("tokens_scored", evidence.get("trials", 0))
    result = {"strength": None, "tokens_scored": n, "p_value": None,
              "confidence": None, "matches": False, "method": "No scored tokens"}
    if not n:
        return result
    scheme = config["scheme"]
    if scheme == "synthid":
        # The endpoint averages ALL binary layers, not one Bernoulli per token.
        # Its detector excludes repeated contexts, so each scored hash is distinct.
        mean = evidence.get("mean_g_value")
        if mean is None or not math.isfinite(mean) or not 0 <= mean <= 1:
            return result
        trials = n * config["depth"]
        score = (mean - 0.5) * 2 * math.sqrt(trials)
        p_value = binomial_tail(round(mean * trials), trials, 0.5)
        result.update(method="One-sided binomial test across tokens × SynthID layers", trials=trials)
    elif scheme in {"kgw", "unigram"}:
        score = evidence.get("z_score")
        if score is None or not math.isfinite(score):
            return result
        p_value = 0.5 * math.erfc(score / math.sqrt(2))
        result["method"] = "Nominal one-sided count z-test"
    elif scheme == "mpac":
        votes = evidence.get("votes", [])
        successes = sum(row[symbol] for row, symbol in zip(votes, config["payload"]))
        trials = sum(sum(row) for row in votes)
        if not trials:
            return result
        probability = 1 / config["radix"]
        score = (successes - trials * probability) / math.sqrt(trials * probability * (1 - probability))
        p_value = binomial_tail(successes, trials, probability)
        result.update(method="Nominal known-payload binomial test", trials=trials)
    else:
        cost = evidence.get("mean_cost")
        if cost is None or not math.isfinite(cost) or cost < 0:
            return result
        # Reusing key-stream rows cannot create additional independent evidence.
        effective_n = n / math.ceil(n / config["sequence_len"])
        if scheme == "exponential":
            score = (1 - cost) * math.sqrt(effective_n)
            exponent = effective_n * (1 - cost + math.log(cost)) if 0 < cost < 1 else (-math.inf if cost == 0 else 0)
            result["method"] = "Conservative exponential-cost Chernoff bound"
        else:
            # For ANY fixed vocabulary rank r, E[|U-r|] >= 1/4. Using
            # 1/3 would assume independent ranks despite repeated text tokens.
            score = (0.25 - cost) * math.sqrt(2 * effective_n)
            exponent = -2 * effective_n * max(0, 0.25 - cost) ** 2
            result["method"] = "Conservative rank-distance Hoeffding bound"
        p_value = math.exp(exponent)
    result.update(strength=score, p_value=p_value, confidence=1 - p_value,
                  matches=n >= MIN_TOKENS and p_value <= MATCH_P_VALUE)
    # Repeated identical observations are not independent trials; the endpoint
    # does not return enough information to correct their multiplicities.
    if config.get("ignore_repeated_ngrams") is False or config.get("ignore_repeated_tokens") is False:
        result.update(p_value=None, confidence=None, matches=False,
                      method="Enable repeated-context/token filtering for a valid key-confidence test")
    return result
