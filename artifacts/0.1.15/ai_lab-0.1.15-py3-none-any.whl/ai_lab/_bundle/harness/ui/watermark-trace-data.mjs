// These are projections of captured values, never reconstructed distributions.
export const percent = value => value == null ? 'Unavailable' : value > 0 && value < .0001 ? `${(value * 100).toExponential(1)}%` : `${(value * 100).toFixed(2)}%`;
export const number = value => value == null ? '—' : value === 0 ? '0' : Math.abs(value) < .001 ? value.toExponential(3) : value.toFixed(4);
export const piece = candidate => candidate?.text == null || candidate.text === '' ? `[token ${candidate?.token_id}]` : candidate.text.replaceAll('\n', '↵').replaceAll('\t', '⇥').replaceAll(' ', '·');
export function traceSource(agent) {
  return agent.sampling_trace?.steps?.length ? {sample: agent, separate: false} : {sample: agent.illustration || agent, separate: !!agent.illustration};
}
export function rowsFor(step, layerIndex = -1) {
  const layer = step.layers?.[layerIndex];
  return step.candidates.map((candidate, index) => ({
    ...candidate, selected: candidate.token_id === step.selected_token_id,
    before: layer ? layer.input_probabilities[index] : candidate.pre_watermark_probability,
    after: layer ? layer.probabilities[index] : candidate.post_watermark_probability,
    group: layer ? (layer.g_values[index] === 1 ? 'g = 1' : 'g = 0') : candidate.membership ?
      (candidate.membership.kind === 'green' ? (candidate.membership.favored ? 'Green' : 'Red') : (candidate.membership.favored ? 'Favored' : 'Unfavored')) : '',
    favored: layer ? layer.g_values[index] === 1 : candidate.membership?.favored,
  }));
}
export function visibleRows(rows, limit = 8) {
  const selected = rows.find(row => row.selected);
  const others = rows.filter(row => row !== selected).sort((a, b) => Math.max(b.before || 0, b.after || 0) - Math.max(a.before || 0, a.after || 0) || a.token_id - b.token_id);
  return [...(selected ? [selected] : []), ...others].slice(0, limit);
}
export function remainingMass(rows, field) {
  if (rows.some(row => !Number.isFinite(row[field]))) return null;
  return Math.max(0, 1 - rows.reduce((sum, row) => sum + row[field], 0));
}
export function explanation(step, layerIndex = -1) {
  const wm = step.watermark, layer = step.layers?.[layerIndex];
  if (!wm) return 'No watermark was applied. The input and output sampling probabilities stay the same.';
  if (wm.status !== 'applied') return ({warmup: 'The watermark needs more context. This step uses the ordinary sampling distribution.', repeated_context: 'This context has already been marked. Watermarking is skipped for this step.', greedy: 'Greedy decoding chooses the leading token directly. Watermarking is skipped.'})[wm.status] || `Watermark status: ${wm.status}.`;
  if (layer) return `In this round, the key assigns each token a 0 or 1. Tokens with g = 1 gain probability; tokens with g = 0 lose it. The full distribution has ${percent(layer.green_mass)} of its input mass in g = 1.`;
  if (step.selection_rule === 'synthid_tournament') return 'The emitted token is the actual tournament winner. Inspect its recorded matches in Watermarking. This policy does not calculate post-watermark probabilities.';
  if (wm.scheme === 'synthid') return 'The key reweights the alternatives over successive tournament rounds. Explore a round to see its 0/1 assignments and probability update, or compare the input with the final distribution here.';
  if (['kgw', 'unigram'].includes(wm.scheme)) return `The key divides tokens into green and red lists. Green tokens receive a bias of ${number(wm.bias_delta)} before the distribution is normalized. Red tokens remain possible.`;
  if (wm.scheme === 'mpac') return `The key favors tokens encoding payload symbol ${wm.payload_symbol} at position ${wm.payload_position}. Favored tokens receive a bias of ${number(wm.bias_delta)}. Other colors are grouped as unfavored.`;
  if (wm.scheme === 'inverse_transform') return 'The key orders the vocabulary and places a threshold along its cumulative probability. The selected token is the interval containing that threshold.';
  return 'The key gives each token a reproducible race score, combined with its input probability. The largest score wins. These scores are not probabilities.';
}
