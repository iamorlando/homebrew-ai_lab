import {mountDecoder} from './decoder-ui.js';

export function connectDecoder(root, fetchImpl = fetch) {
  let catalog = {profiles: [], schemes: []};
  async function json(path, body) {
    let response, value;
    try {
      response = await fetchImpl(path, body === undefined ? {} : {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
      value = await response.json();
    } catch {
      throw Object.assign(new Error(), {publicMessage: 'Decoder service is unavailable. Check the website connection and reload this page.'});
    }
    if (!response.ok) throw Object.assign(new Error(), {publicMessage: typeof value.detail === 'string' ? value.detail : 'Check the text, selected model and detector options, then retry.'});
    return value;
  }
  const view = mountDecoder(root, {detect: async run => {
    const profile = catalog.profiles.find(row => row.id === run.profileId);
    if (!profile) throw Object.assign(new Error(), {publicMessage: 'The selected profile is unavailable. Reload the decoder.'});
    const body = {model: run.profileId, text: run.text, ...run.options, ...(run.snapshot ? {snapshot: run.snapshot} : {})};
    if (run.configurationSource === 'override') Object.assign(body, {scheme: run.scheme, settings: run.settings, ...(run.key ? {key: run.key} : {})});
    const result = await json('/api/decoder/detect', body);
    if (result.profile_key !== profile.id || result.underlying_model !== run.underlyingModel || result.scheme !== run.scheme) {
      throw Object.assign(new Error(), {publicMessage: 'The profile model or scheme changed. Reload its settings and decode again.'});
    }
    return result;
  }, generate: async run => {
    const result = await json('/api/decoder/generate', {model: run.profileId, prompt: run.prompt, max_tokens: run.max_tokens, temperature: run.temperature});
    if (result.profile_key !== run.profileId) throw Object.assign(new Error(), {publicMessage: 'The generated response has a different model. Retry generation.'});
    return result;
  }});
  view.ready = json('/api/decoder/models').then(value => {
    catalog = value; view.setCatalog(value); return value;
  }).catch(error => view.showError(error.publicMessage || 'Model profiles could not be loaded. Reload the decoder.'));
  return view;
}
