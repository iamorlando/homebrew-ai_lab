import './shell.js';
import {connectDecoder} from './decoder-api.js';

connectDecoder(document.getElementById('named-decoder'));
