import {setShellContext, loadShellHistory} from './shell.js';
import {resultContext, sourceConversation, embeddedUrl} from './navigation.mjs';
const frame = document.getElementById('harbor-view');
const error = document.getElementById('frame-error');
let context;
let historyKey;
function updateContext(url) {
  const next = resultContext(url);
  if (next !== context) {
    context = next; setShellContext(context);
  }
  const key = `${context}:${url.pathname.split('/')[2] || ''}`;
  if (key !== historyKey) {
    historyKey = key;
    loadShellHistory(context).catch(() => { /* The viewer remains usable if history is unavailable. */ });
  }
  document.getElementById('results-context').textContent = {watermark:'WATERMARK LAB / RESULTS',comparison:'MODEL COMPARISON / RESULTS',results:'LOCAL RESULTS ARCHIVE'}[context];
  document.getElementById('results-title').textContent = url.pathname.startsWith('/jobs/') ? 'Experiment results' : url.pathname === '/compare' ? 'Harbor comparison' : url.pathname === '/run' ? 'Run a benchmark' : 'Harbor results';
  const back = document.getElementById('back-to-experiment'); const source = sourceConversation(url);
  back.hidden = !source; if (source) back.href = source;
}
function themeFrame() {
  const doc = frame.contentDocument;
  if (!doc?.head) return;
  const theme = getComputedStyle(document.body);
  const read = key => theme.getPropertyValue(key).trim();
  let style = doc.getElementById('local-lab-theme');
  if (!style) { style = doc.createElement('style'); style.id = 'local-lab-theme'; doc.head.append(style); }
  style.textContent = `@import url('/pair-assets/fonts/fonts.css');
  :root, .dark {color-scheme:dark;--background:${read('--bg')};--foreground:${read('--text')};--card:${read('--panel')};--card-foreground:${read('--text')};--popover:${read('--panel')};--popover-foreground:${read('--text')};--primary:${read('--accent-fill')};--primary-foreground:${read('--accent-ink')};--secondary:${read('--raised')};--secondary-foreground:${read('--text')};--muted:${read('--well')};--muted-foreground:${read('--muted')};--accent:${read('--accent-soft')};--accent-foreground:${read('--accent')};--border:${read('--line')};--input:${read('--line')};--ring:${read('--accent')};--radius:0rem;--font-sans:'JetBrains Mono',monospace;--font-mono:'JetBrains Mono',monospace;}
  body{background:var(--background);color:var(--foreground);font-family:'JetBrains Mono',monospace;font-size:12px;} body>div>header{position:absolute;right:16px;top:12px;padding:0;height:28px;background:transparent;border:0;z-index:10} body>div>header a[href="/run"]{display:none} body>div>header button{font-size:11px;padding:5px 9px} h1,h2,h3{font-family:'JetBrains Mono',monospace} h1{font-size:24px!important;overflow-wrap:anywhere} main{min-width:0} body>div{min-height:100dvh!important} main>div{padding-top:20px!important} ::selection{background:var(--accent);color:var(--accent-foreground)}
  `;
}
function syncFrameRoute() {
  try {
    const url = new URL(frame.contentWindow.location.href);
    if (url.origin !== location.origin) return;
    url.searchParams.delete('lab_embed');
    // Native Harbor owns navigation within the frame; keep deep links shareable.
    history.replaceState(null, '', url.pathname + url.search + url.hash);
    updateContext(url); themeFrame();
  } catch { /* Authentication may temporarily navigate outside this origin. */ }
}
frame.addEventListener('load', () => {
  error.hidden = true;
  try {
    const child = frame.contentWindow;
    if (!child.document.body) return;
    // Prevent the standalone wrapper if Harbor reloads after navigating client-side.
    // The server also recognizes Sec-Fetch-Dest: iframe for these document loads.
    for (const method of ['pushState', 'replaceState']) {
      const original = child.history[method].bind(child.history);
      child.history[method] = (...args) => { const result = original(...args); syncFrameRoute(); return result; };
    }
    child.addEventListener('popstate', syncFrameRoute);
    syncFrameRoute();
    const observer = new MutationObserver(() => { if (!child.document.getElementById('local-lab-theme')) themeFrame(); });
    observer.observe(child.document.documentElement, {childList: true, subtree: true});
    child.addEventListener('pagehide', () => observer.disconnect(), {once: true});
  } catch { error.hidden = false; }
});
frame.addEventListener('error', () => { error.hidden = false; });
updateContext(new URL(location.href));
const source = embeddedUrl(location.href); frame.src = source;
document.getElementById('native-results').href = source;
