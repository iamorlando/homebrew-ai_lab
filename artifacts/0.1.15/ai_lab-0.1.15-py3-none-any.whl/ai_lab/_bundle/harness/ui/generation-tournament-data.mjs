export function productionMatches(report) {
  if (report?.origin !== 'production' || report.used_for_generation !== true || report.status !== 'applied') return [];
  const draws = new Map(report.draws.map(draw => [draw.draw_id, draw]));
  return report.matches.map(match => ({...match,
    left:{...match.left, draw:draws.get(match.left.draw_id)},
    right:{...match.right, draw:draws.get(match.right.draw_id)},
    winnerDraw:draws.get(match.winner_draw_id),
  }));
}

// Lay out the native graph by source references, never array offsets or token rank.
export function productionGraph(step) {
  const report = step.generation_tournament;
  if (report?.status !== 'applied' || report.origin !== 'production' || report.used_for_generation !== true) return null;
  if (report.winner.token_id !== step.selected_token_id) throw new Error('Tournament winner differs from the emitted token.');
  const draws = new Map(report.draws.map(d => [d.draw_id, d]));
  const matches = new Map(productionMatches(report).map(m => [m.match_id, m]));
  const collapsed = new Map(report.collapsed_subtrees.map(s => [s.root_match_id, s]));
  const nodes = [], edges = [], seen = new Set(); let leaves = 0;
  function visit(source) {
    const key = `${source.kind}:${source.id}`;
    if (seen.has(key)) throw new Error('Tournament contains a repeated source.');
    seen.add(key);
    let node;
    if (source.kind === 'match') {
      const match = matches.get(source.id);
      if (!match) throw new Error('Tournament match source is unavailable.');
      const parents = ['left','right'].map(side => ({side,node:visit(match[side].source)}));
      node = {key,kind:'match',round:match.round,token:match.winnerDraw,match,y:(parents[0].node.y + parents[1].node.y)/2};
      for (const parent of parents) edges.push({from:parent.node.key,to:key,winner:parent.side === match.winner});
    } else if (source.kind === 'collapsed_subtree') {
      const subtree = collapsed.get(source.id);
      if (!subtree) throw new Error('Collapsed tournament source is unavailable.');
      node = {key,kind:source.kind,round:subtree.round,token:draws.get(subtree.winner_draw_id),subtree,y:leaves++};
    } else if (source.kind === 'draw') {
      node = {key,kind:'draw',round:-1,token:draws.get(source.id),y:leaves++};
    } else throw new Error('Unknown tournament source.');
    if (!node.token) throw new Error('Tournament advancing draw is unavailable.');
    nodes.push(node); return node;
  }
  const root = visit({kind:matches.has(report.winner.match_id) ? 'match' : 'collapsed_subtree',id:report.winner.match_id});
  const firstRound = Math.min(...nodes.map(n => n.round));
  for (const node of nodes) node.column = node.round - firstRound;
  return {nodes,edges,root,leaves,columns:root.column + 1};
}
