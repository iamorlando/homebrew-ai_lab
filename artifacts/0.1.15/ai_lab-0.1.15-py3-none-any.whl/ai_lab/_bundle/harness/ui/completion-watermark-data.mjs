import {rowsFor, piece} from './watermark-trace-data.mjs';

export function tokenGroups(step, round = 0) {
  const tournament = step.watermark?.scheme === 'synthid';
  const layer = tournament ? step.layers?.[round] : null;
  const rows = rowsFor(step, layer ? round : -1);
  const available = rows.some(row => typeof row.favored === 'boolean');
  return {available, layer, green: rows.filter(row => row.favored === true),
    red: rows.filter(row => row.favored === false),
    unknown: rows.filter(row => typeof row.favored !== 'boolean')};
}

// Use only recorded generation values.
export function tournamentStages(step, tokenId) {
  if (step.watermark?.scheme !== 'synthid' || step.watermark.status !== 'applied') return [];
  const index = step.candidates.findIndex(candidate => candidate.token_id === tokenId);
  const layers = (step.layers || []).slice(0,4);
  if (index < 0 || !layers.length) return [];
  return [{probability: layers[0].input_probabilities[index]}, ...layers.map(layer => ({
    round: layer.index + 1, probability: layer.probabilities[index],
    before: layer.input_probabilities[index], favored: layer.g_values[index] === 1,
    greenMass: layer.green_mass,
  }))];
}

export function teachingMatches(demo) {
  if (!demo || demo.origin !== 'teaching_simulation' || demo.used_for_generation !== false || demo.status !== 'demonstrated') return [];
  const draws = new Map(demo.draws.map(draw => [draw.draw_id, draw]));
  return demo.matches.map(match => ({...match,
    left: {...match.left, draw: draws.get(match.left.draw_id)},
    right: {...match.right, draw: draws.get(match.right.draw_id)},
    winnerDraw: draws.get(match.winner_draw_id),
  }));
}

export function matchExplanation(match) {
  const winner = match[match.winner], loser = match[match.winner === 'left' ? 'right' : 'left'];
  if (match.reason === 'random_tie') return `Both contestants scored ${winner.g_value}. A random tie-break advanced ${piece(winner.draw)} (draw ${winner.draw_id + 1}).`;
  return `${piece(winner.draw)} scored ${winner.g_value} (green), beating ${piece(loser.draw)} with ${loser.g_value} (red). The watermark score decides the match; the model probability was used to draw the contestants.`;
}

export function openingMatch(matches) {
  return matches.find(m => m.reason === 'higher_g' && m[m.winner].draw.probability < m[m.winner === 'left' ? 'right' : 'left'].draw.probability)
    || matches.find(m => m.reason === 'higher_g') || matches[0];
}
