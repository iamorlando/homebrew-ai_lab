// Kept separate from the DOM so direct links and mixed comparisons share one rule.
export function resultContext(url) {
  const job = decodeURIComponent(url.pathname.split('/')[2] || '');
  const jobs = url.pathname === '/compare' ? url.searchParams.getAll('job') : url.pathname.startsWith('/jobs/') ? [job] : [];
  if (!jobs.length) return 'results';
  return jobs.every(name => name.startsWith('wm-')) ? 'watermark' : jobs.every(name => !name.startsWith('wm-')) ? 'comparison' : 'results';
}
export function sourceConversation(url) {
  const job = decodeURIComponent(url.pathname.split('/')[2] || '');
  const match = job.match(/^(wm|comparison)-([a-f0-9]{32})$/);
  return match ? (match[1] === 'wm' ? `/wm?id=${match[2]}` : `/pair?conversation=${match[2]}`) : null;
}
export function embeddedUrl(url) {
  const next = new URL(url); next.searchParams.set('lab_embed', '1'); return next.pathname + next.search + next.hash;
}
