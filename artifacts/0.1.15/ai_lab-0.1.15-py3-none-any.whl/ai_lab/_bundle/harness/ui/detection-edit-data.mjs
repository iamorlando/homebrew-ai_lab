// Word ranges use JavaScript string offsets, including Unicode surrogate pairs.
export function words(text) {
  return [...new Intl.Segmenter(undefined, {granularity:'word'}).segment(text)]
    .filter(part => part.isWordLike)
    .map(part => ({start:part.index, end:part.index + part.segment.length, text:part.segment}));
}

export function targetWord(text, range) {
  // A leading space normally belongs to the model token, not the visible word.
  const prefixEnd = range.start > 0 && text[range.start - 1] === ' ' ? range.start - 1 : range.start;
  return {...range, prefix:text.slice(0, prefixEnd), leading:text.slice(prefixEnd, range.start)};
}

export function wordAlternative(candidate, target) {
  if (typeof candidate.text !== 'string' || !candidate.text.startsWith(target.leading)) return null;
  const word = candidate.text.slice(target.leading.length);
  // No control tokens, punctuation-only tokens, or extra whitespace variants.
  return /^[\p{L}\p{M}\p{N}]+(?:['’\-][\p{L}\p{M}\p{N}]+)*$/u.test(word) ? word : null;
}

export function replaceWord(text, target, replacement) {
  if (text.slice(target.start, target.end) !== target.text) throw new Error('This word changed. Select it again.');
  return text.slice(0, target.start) + replacement + text.slice(target.end);
}

export function syncEditedResponse(detectorText, previous, next) {
  return !detectorText.trim() || detectorText === previous ? next : detectorText;
}
