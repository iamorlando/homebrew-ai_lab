import {percent, piece} from './watermark-trace-data.mjs';
import {teachingMatches, matchExplanation, openingMatch} from './completion-watermark-data.mjs';

const el = (tag, text = '', cls = '') => { const n = document.createElement(tag); n.textContent = text; n.className = cls; return n; };
export function teachingTournament(step) {
  const demo = step.teaching_tournament, section = el('section', '', 'completion-tournament');
  const matches = teachingMatches(demo);
  section.append(el('h3', 'Watch tokens compete'));
  if (!matches.length) {
    section.append(el('p', demo ? `No teaching matches were captured (${(demo.status || 'unavailable').replaceAll('_', ' ')}). Choose SynthID and inspect again to capture a teaching example.` : 'This result has no teaching bracket. Choose SynthID and inspect again using a runtime with teaching captures.', 'field-help'));
    return section;
  }
  section.append(el('p', `${demo.draws.length} contestants → ${demo.rounds} rounds → one teaching winner. Green (1) beats red (0). Equal scores use a random tie-break.`, 'tournament-guide'));
  section.append(el('p', 'Each round uses a new key-derived green/red split, so a token’s color can change between rounds.', 'field-help'));
  section.append(el('p', 'Mistral sampled this teaching example from the same starting probabilities and watermark key. It is separate from the generation result.', 'field-help'));
  if (!matches.some(match => match.match_id === demo.winner.match_id)) section.append(el('p', 'Final teaching match was not captured. Only recorded matches can be inspected; inspect again for a complete teaching example.', 'trace-notice'));
  const winners = el('div', '', 'tournament-outcomes');
  const demoWinner = demo.draws.find(d => d.draw_id === demo.winner.draw_id);
  const actual = step.candidates.find(c => c.token_id === step.selected_token_id);
  for (const [label, token, caption] of [
    ['Teaching winner', demoWinner, `${demo.rounds} demonstration rounds`],
    ['Actual generated token', actual, `${demo.configured_depth} production layers`],
  ]) {
    const item = el('div'); item.append(el('span', label), el('code', piece(token)), el('small', caption)); winners.append(item);
  }
  section.append(winners);
  const detail = el('div', '', 'tournament-match-detail'); detail.setAttribute('aria-live', 'polite');
  section.append(detail);
  const navigation = el('div', '', 'tournament-navigation');
  const previous = el('button', '← Previous match'), next = el('button', 'Next match →'); previous.type = next.type = 'button';
  const position = el('span');
  navigation.append(previous, position, next); section.append(navigation);

  const gap = 128, boxWidth = 106, rowHeight = 32, offset = 32;
  const width = (demo.rounds + 1) * gap, height = demo.draws.length * rowHeight + offset;
  const scroll = el('div', '', 'completion-bracket-scroll'); scroll.tabIndex = 0;
  scroll.setAttribute('aria-label', 'Teaching tournament bracket. Select a match winner to see both contestants and the reason. Scroll to see all matches.');
  const bracket = el('div', '', 'completion-bracket'); bracket.style.width = `${width}px`; bracket.style.height = `${height}px`;
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('viewBox', `0 0 ${width} ${height}`); svg.setAttribute('aria-hidden', 'true'); bracket.append(svg);
  const nodes = new Map(), matchButtons = new Map(), edges = [];
  for (let round = 0; round <= demo.rounds; round++) {
    const label = el('div', round ? `ROUND ${round} WINNERS` : 'INITIAL DRAWS', 'bracket-column-label'); label.style.left = `${round * gap}px`; bracket.append(label);
  }
  for (const draw of demo.draws) {
    const y = offset + (draw.draw_id + .5) * rowHeight;
    const item = el('div', '', 'bracket-node bracket-draw');
    item.dataset.draw = draw.draw_id; item.style.left = '0px'; item.style.top = `${y - 13}px`;
    item.append(el('code', piece(draw)), el('small', `Draw ${draw.draw_id + 1} · ${percent(draw.probability)}`));
    item.title = `Draw ${draw.draw_id + 1}: ${piece(draw)} (token ${draw.token_id}), ${percent(draw.probability)} input probability`;
    nodes.set(`draw:${draw.draw_id}`, {x:0,y,item}); bracket.append(item);
  }
  for (const match of matches) {
    const parents = ['left','right'].map(side => nodes.get(`${match[side].source.type}:${match[side].source.id}`));
    const y = (parents[0].y + parents[1].y) / 2, x = (match.round + 1) * gap;
    const winner = match[match.winner];
    const item = el('button', '', `bracket-node bracket-match ${winner.g_value ? 'green' : 'red'}${match.reason === 'random_tie' ? ' tied' : ''}`);
    item.type = 'button'; item.dataset.match = match.match_id;
    item.style.left = `${x}px`; item.style.top = `${y - 13}px`;
    item.append(el('code', piece(match.winnerDraw)), el('small', match.reason === 'random_tie' ? 'Tie-break winner' : 'Green beats red'));
    item.setAttribute('aria-label', `Round ${match.round + 1}, match ${match.match_id + 1}: ${piece(match.winnerDraw)} advances. ${match.reason === 'random_tie' ? 'Random tie-break' : 'Higher watermark score'}.`);
    item.onclick = () => { select(match.match_id); detail.scrollIntoView({block:'nearest'}); };
    matchButtons.set(match.match_id, item); nodes.set(`match:${match.match_id}`, {x,y,item}); bracket.append(item);
    parents.forEach((parent, index) => {
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', `M${parent.x + boxWidth},${parent.y} H${x - 11} V${y} H${x}`);
      const side = index ? 'right' : 'left';
      path.classList.toggle('winning-edge', match.winner === side);
      edges.push({match: match.match_id, path}); svg.append(path);
    });
  }
  scroll.append(bracket); section.append(scroll, el('p', 'Click a match winner, or Tab to the bracket and use ←/→ for matches, Home/End for first/final captured match, and Enter to activate a focused button. A token can be drawn more than once; draw numbers distinguish those contestants. Input probabilities explain the initial draws, not the chance of winning a match.', 'field-help'));
  const replay = el('details', '', 'trace-values'); replay.append(el('summary', 'Replay details'), el('p', `Diagnostic seed ${demo.effective_seed} · ${demo.rng_version}. This random stream is separate from generation.`, 'field-help')); section.append(replay);
  let selected;
  function select(id) {
    const match = matches.find(m => m.match_id === id); selected = matches.indexOf(match);
    detail.replaceChildren(el('h4', `ROUND ${match.round + 1} / MATCH ${match.match_id + 1}`));
    const contestants = el('div', '', 'tournament-contestants');
    for (const side of ['left', 'right']) {
      const entrant = match[side], winner = side === match.winner;
      const card = el('div', '', `tournament-contestant ${entrant.g_value ? 'green' : 'red'}${winner ? ' winner' : ''}`);
      card.append(el('span', `Draw ${entrant.draw_id + 1} · ${winner ? 'ADVANCES' : 'ELIMINATED'}`, 'contestant-status'), el('code', piece(entrant.draw)), el('strong', `${entrant.g_value ? 'GREEN' : 'RED'} / score ${entrant.g_value}`), el('small', `Initial draw probability ${percent(entrant.draw.probability)}`));
      contestants.append(card);
    }
    detail.append(contestants, el('p', matchExplanation(match), 'tournament-explanation'));
    position.textContent = `${selected + 1} / ${matches.length}`; previous.disabled = selected === 0; next.disabled = selected === matches.length - 1;
    for (const [matchId, button] of matchButtons) { button.classList.toggle('active', matchId === id); button.setAttribute('aria-pressed', String(matchId === id)); }
    for (const node of nodes.values()) node.item.classList.remove('match-entrant');
    for (const side of ['left','right']) nodes.get(`${match[side].source.type}:${match[side].source.id}`).item.classList.add('match-entrant');
    for (const edge of edges) edge.path.classList.toggle('inspected-edge', edge.match === id);
  }
  previous.onclick = () => select(matches[selected - 1].match_id);
  next.onclick = () => select(matches[selected + 1].match_id);
  scroll.onkeydown = event => {
    if (event.altKey || event.ctrlKey || event.metaKey) return;
    const index = {ArrowLeft:selected-1, ArrowRight:selected+1, Home:0, End:matches.length-1}[event.key];
    if (index === undefined) return;
    event.preventDefault();
    const match = matches[Math.max(0, Math.min(index, matches.length-1))];
    select(match.match_id);
    const button = matchButtons.get(match.match_id);
    button.focus({preventScroll:true}); button.scrollIntoView({block:'nearest', inline:'nearest'});
  };
  select(openingMatch(matches).match_id);
  return section;
}
