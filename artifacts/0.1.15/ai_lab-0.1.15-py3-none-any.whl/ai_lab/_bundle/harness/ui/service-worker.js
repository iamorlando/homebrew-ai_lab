// Keep every workspace page and API request live. Only a stopped-server notice
// is available offline; never store prompts, credentials, results or old UI.
self.addEventListener('install', event => event.waitUntil(self.skipWaiting()));
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || event.request.mode !== 'navigate' ||
      event.request.destination !== 'document' || url.origin !== self.location.origin ||
      url.pathname.startsWith('/api/')) return;
  event.respondWith(fetch(event.request).catch(() => {
    const port = self.location.port || '8080';
    return new Response(`<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#080c10"><title>AI Lab — start the website</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#080c10;color:#e0e6ec;font:16px/1.7 system-ui}main{max-width:460px;padding:32px}h1{font-size:28px}code{display:block;padding:16px;background:#10161d;border:1px solid #384653;color:#b8d1e5}p{color:#9caebd}button{padding:10px 16px;color:#e0e6ec;background:#10161d;border:1px solid #384653;cursor:pointer}</style>
</head><body><main><h1>Start AI Lab</h1><p>The local website is stopped. Run this in your workspace terminal, then return to this window.</p>
<code>ai-lab web --port ${port}</code><p>Keep the terminal open while using the app.</p><button onclick="location.reload()">Try again</button></main>
<script>setInterval(async()=>{try{if((await fetch('/manifest.webmanifest',{cache:'no-store'})).ok)location.reload()}catch{}},5000)</script></body></html>`,
      {status: 503, headers: {'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store'}});
  }));
});
