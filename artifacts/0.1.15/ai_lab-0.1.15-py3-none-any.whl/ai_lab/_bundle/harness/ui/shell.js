// One navigation shell for every workspace, including native Harbor results.
import {setupWebApp} from './web-app.js';
const section = document.body.dataset.section || 'completion';
const labels = {completion: 'Completion', decisions: 'Decisions', detection: 'Watermark decoder', models: 'Model configuration', results: 'Harbor results'};
const element = (tag, text = '', cls = '') => { const el = document.createElement(tag); el.textContent = text; el.className = cls; return el; };
const revision = document.querySelector('meta[name="lab-revision"]')?.content;
const link = (text, href, cls = '') => {
  const el = element('a', text, cls);
  if (revision && href.startsWith('/')) {
    const url = new URL(href, location.origin); url.searchParams.set('ui', revision);
    href = url.pathname + url.search + url.hash;
  }
  el.href = href; return el;
};
let currentContext = section;
const sidebar = document.createElement('aside'); sidebar.id = 'lab-sidebar'; sidebar.className = 'sidebar'; sidebar.setAttribute('aria-label', 'Workspace navigation');
const brand = link('', '/completion', 'brand');
const mark = element('span', '>_', 'mark'); mark.setAttribute('aria-hidden', 'true');
const wordmark = element('span', 'AI LAB'); wordmark.append(element('span', 'LOCAL_LAB', 'brand-sub'));
brand.append(mark, wordmark); sidebar.append(brand);
const close = element('button', '×', 'sidebar-close'); close.type = 'button'; close.setAttribute('aria-label', 'Close navigation'); sidebar.append(close);
const sidebarContent = element('div', '', 'sidebar-content'); sidebar.append(sidebarContent);
const foot = element('div', '', 'sidebar-foot'); foot.append(element('span', 'LOCAL WORKSPACE', 'sidebar-foot-label'), element('p', 'Models and conversations stay on this machine.')); sidebar.append(foot);
const backdrop = element('button', '', 'sidebar-backdrop'); backdrop.type = 'button'; backdrop.setAttribute('aria-label', 'Close navigation'); backdrop.hidden = true;
const top = element('header', '', 'lab-topbar');
const toggle = element('button', '☰', 'menu-toggle'); toggle.type = 'button'; toggle.setAttribute('aria-label', 'Open navigation'); toggle.setAttribute('aria-controls', 'lab-sidebar'); toggle.setAttribute('aria-expanded', 'false');
const modes = element('nav', '', 'mode-nav'); modes.setAttribute('aria-label', 'Workspace mode'); modes.append(element('span', 'MODE //', 'mode-label'));
for (const [key, label, href] of [['completion', 'Completion', '/completion'], ['decisions', 'Decisions', '/decisions'], ['detection', 'Watermark decoder', '/decoder']]) {
  const item = link(label, href); item.dataset.context = key; modes.append(item);
}
const utilities = element('nav', '', 'utility-nav'); utilities.setAttribute('aria-label', 'Workspace tools');
for (const [key, label, href] of [['models', 'Models', '/models']]) {
  const item = link(label, href); item.dataset.context = key; utilities.append(item);
}
top.append(toggle, modes, utilities);
const main = document.querySelector('main'); main.id ||= 'workspace'; main.tabIndex = -1;
const skip = link('Skip to workspace', '#workspace', 'skip-link');
document.body.prepend(skip, sidebar, backdrop, top);
setupWebApp(utilities);

function closeNavigation(restore = true) {
  document.body.classList.remove('navigation-open'); sidebar.removeAttribute('role'); sidebar.removeAttribute('aria-modal');
  backdrop.hidden = true; main.inert = false; top.inert = false;
  toggle.setAttribute('aria-expanded', 'false'); if (restore) toggle.focus();
}
function openNavigation() {
  document.body.classList.add('navigation-open'); backdrop.hidden = false;
  sidebar.setAttribute('role', 'dialog'); sidebar.setAttribute('aria-modal', 'true');
  main.inert = true; top.inert = true; toggle.setAttribute('aria-expanded', 'true'); close.focus();
}
toggle.onclick = () => document.body.classList.contains('navigation-open') ? closeNavigation() : openNavigation();
close.onclick = () => closeNavigation(); backdrop.onclick = () => closeNavigation();
sidebar.addEventListener('click', event => {
  if (document.body.classList.contains('navigation-open') && event.target.closest('a,button') && !event.target.closest('.sidebar-close')) closeNavigation(!!event.target.closest('button'));
});
document.addEventListener('keydown', event => {
  if (!document.body.classList.contains('navigation-open')) return;
  if (event.key === 'Escape') { event.preventDefault(); closeNavigation(); }
  if (event.key === 'Tab') {
    const nodes = [...sidebar.querySelectorAll('a[href],button:not(:disabled)')].filter(n => n.getClientRects().length);
    if (event.shiftKey && document.activeElement === nodes[0]) { event.preventDefault(); nodes.at(-1).focus(); }
    else if (!event.shiftKey && document.activeElement === nodes.at(-1)) { event.preventDefault(); nodes[0].focus(); }
  }
});
matchMedia('(min-width: 768px)').addEventListener('change', e => { if (e.matches) closeNavigation(false); });
function historyGroup(title, id, ariaLabel) {
  sidebarContent.append(element('div', title, 'nav-label'));
  const nav = element('nav'); nav.id = id; nav.setAttribute('aria-label', ariaLabel); sidebarContent.append(nav);
}
export function setShellContext(context) {
  currentContext = context; document.body.dataset.theme = context;
  modes.querySelectorAll('a').forEach(a => {
    const active = a.dataset.context === context;
    a.classList.toggle('active', active); if (active) a.setAttribute('aria-current', section === 'results' ? 'location' : 'page'); else a.removeAttribute('aria-current');
  });
  utilities.querySelectorAll('a').forEach(a => {
    const active = a.dataset.context === section;
    a.classList.toggle('active', active); if (active) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
  sidebarContent.replaceChildren();
  if (context !== 'models') sidebarContent.append(element('div', (labels[context] || 'AI Lab').toUpperCase(), 'sidebar-context'));
  if (context === 'decisions') {
    sidebarContent.append(element('p', 'Ask typed questions about a state, or rank candidate answers and actions.', 'nav-empty'));
    const guide = element('div', '', 'completion-guide');
    guide.append(element('p', '01 / Choose a model'), element('p', '02 / Define state & questions'), element('p', '03 / Compare probabilities'));
    sidebarContent.append(guide);
  }
  else if (context === 'detection') {
    sidebarContent.append(element('p', 'Generate text on the left, then copy or paste it into the decoder on the right. Select the writing model to inherit its watermark, or change the settings to compare results.', 'nav-empty'));
    const guide = element('div', '', 'completion-guide');
    guide.append(element('p', '01 / Generate or paste text'), element('p', '02 / Select the writing model'), element('p', '03 / Decode or change settings'));
    sidebarContent.append(guide);
  }
  else if (context === 'completion') {
    sidebarContent.append(element('p', 'Inspect one next-token decision at a time. Append an alternative to continue the prefix.', 'nav-empty'));
    const guide = element('div', '', 'completion-guide');
    guide.append(element('p', '01 / Enter a prefix'), element('p', '02 / Inspect logits'), element('p', '03 / Append a token'));
    sidebarContent.append(guide);
  }
  document.dispatchEvent(new CustomEvent('lab:context', {detail: context}));
}
// Retained for old result links; the supported workspace has no comparison history.
export async function loadShellHistory() {}
setShellContext(section);
