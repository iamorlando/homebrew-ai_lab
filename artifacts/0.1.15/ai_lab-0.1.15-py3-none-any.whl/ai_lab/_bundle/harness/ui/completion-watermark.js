import {percent, number, piece, explanation} from './watermark-trace-data.mjs';
import {tokenGroups, tournamentStages} from './completion-watermark-data.mjs';
import {teachingTournament} from './teaching-tournament.js';
import {generationTournament} from './generation-tournament.js';

const el = (tag, text = '', cls = '') => { const n = document.createElement(tag); n.textContent = text; n.className = cls; return n; };
export function renderWatermark(container, result, chosen, round, choose, changeRound) {
  container.replaceChildren();
  const step = result.step, wm = step.watermark;
  if (!wm) {
    container.append(el('h3', 'No watermark applied'), el('p', 'Choose a watermark scheme beside the prefix, then inspect again to compare its effect.', 'field-help'));
    return;
  }
  if (step.generation_tournament) {
    container.append(generationTournament(step, choose));
    if (step.selection_rule === 'synthid_tournament' || wm.status !== 'applied') return;
  }
  if (wm.scheme !== 'synthid' || wm.status !== 'applied') container.append(el('h3', 'How this key changes the next token'), el('p', explanation(step), 'field-help'));
  if (wm.status !== 'applied') {
    container.append(el('p', wm.status === 'warmup' ? 'Add more text to the prefix or reduce the context length in Scheme settings, then inspect again.' : 'No watermark changes were applied to this decision.', 'trace-notice'));
    return;
  }
  const group = tokenGroups(step, round);
  if (wm.scheme === 'synthid' && step.teaching_tournament && !step.generation_tournament) container.append(teachingTournament(step));
  const stages = tournamentStages(step, chosen.token_id);
  if (stages.length) {
    const progress = el('details', '', 'trace-values');
    progress.append(el('summary', `Actual probability changes for ${piece(chosen)}`));
    const sequence = el('ol', '', 'tournament-probability-sequence');
    stages.forEach((stage, i) => { const row = el('li'); row.append(el('span', i ? `Round ${stage.round} · g ${Number(stage.favored)}` : 'Before watermark'), el('strong', percent(stage.probability))); sequence.append(row); });
    const final = el('li'); final.append(el('span', `After all ${result.watermark.depth} rounds`), el('strong', percent(chosen.post_watermark_probability))); sequence.append(final);
    progress.append(sequence, el('p', 'These are recorded generation probabilities, separate from the teaching tournament above.', 'field-help')); container.append(progress);
  }
  if (wm.scheme === 'synthid' && step.layers.length) {
    const control = el('div', '', 'completion-round-control'), label = el('label', 'Color lists for round');
    const select = el('select'); select.id = 'completion-round'; label.htmlFor = select.id;
    for (const [i, layer] of step.layers.slice(0,4).entries()) { const option = el('option', String(layer.index + 1)); option.value = i; select.append(option); }
    select.value = round; select.onchange = () => changeRound(Number(select.value));
    control.append(label, select); container.append(control);
  }
  if (group.available) {
    container.append(el('p', `${step.candidates.length} captured alternatives of ${step.candidate_count.toLocaleString()} vocabulary tokens. Lists below cover these alternatives only.${group.layer ? ' Green = g 1; red = g 0 in this round.' : ''}`, 'field-help'));
    const lists = el('div', '', 'completion-color-lists');
    for (const [name, rows, cls] of [[wm.scheme === 'mpac' ? 'Favored payload group' : 'Green list', group.green, 'green'], [wm.scheme === 'mpac' ? 'Other payload groups' : 'Red list', group.red, 'red']]) {
      const section = el('section', '', `completion-color-list ${cls}`);
      section.append(el('h4', `${name} / ${rows.length}`));
      const tokens = el('div', '', 'completion-list-tokens');
      for (const row of rows) {
        const button = el('button', '', `completion-list-token${row.token_id === chosen.token_id ? ' active' : ''}`); button.type = 'button';
        button.append(el('code', piece(row)), el('small', `#${row.token_id}${row.selected ? ' ★ sampled' : ''}`), el('span', `${percent(row.before)} → ${percent(row.after)}`));
        button.setAttribute('aria-label', `Inspect ${piece(row)}, token ${row.token_id}`);
        button.setAttribute('aria-pressed', String(row.token_id === chosen.token_id));
        button.onclick = () => choose(row); tokens.append(button);
      }
      if (!rows.length) tokens.append(el('p', 'No captured alternatives in this group.', 'field-help'));
      section.append(tokens); lists.append(section);
    }
    container.append(lists);
    if (wm.scheme === 'mpac') container.append(el('p', 'MPAC uses payload color groups; the unfavored group may contain several colors, rather than a single red list.', 'field-help'));
  } else if (wm.scheme !== 'synthid') {
    container.append(el('p', 'This scheme uses keyed selection, without green/red token lists. Its actual selection scores are shown below.', 'field-help'));
    const table = el('table'), head = el('tr'), body = el('tbody');
    for (const label of ['Token', 'Input probability', 'Key score']) head.append(el('th', label));
    const thead = el('thead'); thead.append(head); table.append(thead);
    for (const c of step.candidates.slice(0,16)) {
      const row = el('tr');
      for (const value of [`${piece(c)}${c.token_id === step.selected_token_id ? ' ★' : ''}`, percent(c.pre_watermark_probability), c.selection_score_status === 'negative_infinity' ? '−∞' : number(c.selection_score)]) row.append(el('td', value));
      body.append(row);
    }
    table.append(body); const wrap = el('div', '', 'trace-table-wrap'); wrap.append(table); container.append(wrap);
  }
}
