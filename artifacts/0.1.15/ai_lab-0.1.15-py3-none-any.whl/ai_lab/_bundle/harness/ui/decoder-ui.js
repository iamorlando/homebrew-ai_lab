import {renderWatermarkFields, readWatermarkFields, schemeDescription} from './watermark-config.js';
import {detectionPresentation} from './decoder-evidence.mjs';

// Owns UI only. Profile metadata and the detector callback are supplied by a host.
// No network, tokenizer, key generation, profile writes or confidence calculation.
export function mountDecoder(root, {profiles = [], schemes = [], detect = null, generate = null} = {}) {
  root.innerHTML = `
    <div class="decoder-workspace">
    <section class="detection-pane" aria-labelledby="generation-heading">
      <div class="pane-heading"><h2 id="generation-heading">01 / Generate</h2><span>SAVED MODEL SETTINGS</span></div>
      <form id="generation-form"><fieldset id="generation-controls">
        <div class="field"><label for="generation-model">Generation model</label><select id="generation-model" required></select></div>
        <p id="generation-model-help" class="field-help"></p>
        <div class="field"><label for="generation-prompt">Prompt</label><textarea id="generation-prompt" rows="6" maxlength="24000" required placeholder="Explain how coral reefs support marine life."></textarea></div>
        <details class="detection-settings"><summary>Generation options</summary><div class="decoder-options">
          <div class="field"><label for="generation-limit">Response limit / tokens</label><input id="generation-limit" type="number" min="64" max="2048" step="1" value="512" required></div>
          <div class="field"><label for="generation-temperature">Temperature</label><input id="generation-temperature" type="number" min="0" max="2" step="any" value="1" required></div>
        </div></details>
        <div class="detection-actions"><span id="generation-status" role="status" class="field-help">Choose a saved model to generate.</span><button id="generation-run" type="submit" class="primary">Generate →</button></div>
      </fieldset></form>
      <p id="generation-error" role="alert" class="trace-notice" hidden></p>
      <div class="detection-response"><h3>Generated text</h3><p id="generation-context" class="field-help">Your response will appear here.</p>
        <textarea id="generation-output" rows="12" readonly aria-label="Generated text" placeholder="Generate a response, then copy it to the decoder."></textarea>
        <div class="detection-actions"><button id="generation-copy" type="button" disabled>Copy to decoder →</button></div>
      </div>
    </section>
    <section class="detection-pane" aria-labelledby="decoder-heading">
    <div class="pane-heading"><h2 id="decoder-heading">02 / Decode</h2><span>PASTE OR COPY TEXT</span></div>
    <form id="decoder-form">
      <fieldset id="decoder-controls">
        <div class="decoder-inputs">
          <div class="decoder-text-field field"><label for="decoder-text">Text to decode</label>
            <textarea id="decoder-text" rows="9" maxlength="100000" required placeholder="Paste text to test against a known watermark key."></textarea>
            <p class="field-help">Text stays here when you change models or compare schemes.</p></div>
          <div class="decoder-configuration">
            <div class="field"><label for="decoder-model">Decoder model</label><select id="decoder-model" required></select></div>
            <p id="decoder-model-help" class="field-help"></p>
            <div class="field"><label for="decoder-scheme">Watermark scheme</label><select id="decoder-scheme" required></select></div>
            <div class="decoder-source"><span id="decoder-source" role="status"></span><button id="decoder-restore" type="button">Reset to saved model settings</button></div>
            <div id="decoder-key-holder"></div>
            <details class="detection-settings"><summary>Scheme settings</summary><div id="decoder-description"></div><div id="decoder-fields" class="watermark-inputs"></div></details>
          </div>
        </div>
        <details class="detection-settings"><summary>Detection options</summary><div class="decoder-options">
          <div class="field"><label for="decoder-prefix">Skip prefix tokens</label><input id="decoder-prefix" type="number" min="0" max="24000" step="1" value="0" required></div>
          <div class="field"><label for="decoder-eos">Stop at token IDs</label><input id="decoder-eos" placeholder="Optional comma-separated IDs"></div>
          <label class="detection-check"><input id="decoder-special" type="checkbox"> Add tokenizer special tokens</label>
          <div class="field"><label for="decoder-threshold">Match p-value threshold</label><input id="decoder-threshold" type="number" min="0.000000000001" max="1" step="any" value="0.001" required></div>
          <div class="field"><label for="decoder-minimum">Minimum scored tokens</label><input id="decoder-minimum" type="number" min="1" max="10000" step="1" value="20" required></div>
        </div></details>
        <div class="detection-actions"><span id="decoder-status" role="status" class="field-help"></span><button id="decoder-run" type="submit" class="primary">Decode watermark →</button></div>
      </fieldset>
    </form>
    <p id="decoder-error" role="alert" class="trace-notice" hidden></p>
    <section id="decoder-result" class="detection-result" aria-labelledby="decoder-result-heading" aria-live="polite" hidden>
      <div class="pane-heading"><h3 id="decoder-result-heading">Decoder result</h3><span id="decoder-result-state"></span></div>
      <p id="decoder-stale" class="trace-notice" hidden>Text or settings changed. Decode again to update this result.</p>
      <p id="decoder-result-context" class="field-help"></p>
      <div id="decoder-verdict" class="detection-verdict"></div><p id="decoder-reason" class="field-help"></p>
      <div class="detection-confidence"><span>Known-key confidence</span><strong id="decoder-confidence"></strong></div>
      <div id="decoder-meter" class="confidence-track" role="meter" aria-label="Known-key confidence" aria-valuemin="0" aria-valuemax="100" hidden><span></span></div>
      <dl id="decoder-statistics" class="completion-metrics"></dl>
      <p class="field-help">Confidence is 1 − p-value from a known-key test or conservative bound against unwatermarked text. It is not a probability of authorship.</p>
      <details class="trace-values"><summary>Detection evidence</summary><pre id="decoder-raw"></pre></details>
    </section>
    </section></div>`;
  const $ = name => root.querySelector(`#decoder-${name}`);
  const gen = name => root.querySelector(`#generation-${name}`);
  let rows = structuredClone(profiles), definitions = structuredClone(schemes), catalogLoaded = profiles.length > 0 || schemes.length > 0;
  let busy = false, local = false, lastSignature = null, failed = false, generated = null, inheritedResponse = null, operation = null;
  const current = () => inheritedResponse?.profile || rows.find(row => row.id === $('model').value);
  const generationProfile = () => rows.find(row => row.id === gen('model').value);
  const availableSchemes = () => current()?.schemes || definitions;
  const selectedScheme = () => availableSchemes().find(row => row.id === $('scheme').value);
  const option = (value, label) => { const node = document.createElement('option'); node.value = value; node.textContent = label; return node; };
  function fields(defaults = {}, key = '') {
    const schema = selectedScheme();
    renderWatermarkFields(schema, $('fields'), 'decoder', {...defaults, key}, {generateKey: false, keyRequired: !current()?.hasKey});
    const holder = $('fields').querySelector('#decoder-key')?.closest('.field');
    $('key-holder').replaceChildren(...(holder ? [holder] : []));
    const input = root.querySelector('#decoder-key');
    if (input) input.placeholder = current()?.hasKey ? 'Leave blank to use the saved key' : 'Enter the original 64-character hex key';
    $('description').replaceChildren(...(schema ? [schemeDescription(schema)] : []));
  }
  function inherit() {
    inheritedResponse = null;
    const profile = current(); local = false;
    $('scheme').replaceChildren(option('', 'Choose a scheme'), ...availableSchemes().map(row => option(row.id, row.name)));
    $('scheme').value = profile?.scheme || '';
    fields(profile?.settings || {});
    for (const [name, value] of [['prefix', '0'], ['eos', ''], ['threshold', '0.001'], ['minimum', '20']]) $(name).value = value;
    $('special').checked = false;
    refresh();
  }
  function request() {
    const profile = current(), schema = selectedScheme();
    if (!profile || !schema) throw new Error('Choose a model and watermark scheme.');
    const values = readWatermarkFields(schema, 'decoder'), key = values.key || null;
    delete values.key; delete values.scheme;
    const ids = $('eos').value.trim();
    if (ids && !/^\d+(\s*,\s*\d+)*$/.test(ids)) throw new Error('Stop token IDs must be comma-separated integers.');
    const eos = ids ? ids.split(',').map(Number) : [];
    if (eos.length > 32 || eos.some(id => !Number.isSafeInteger(id))) throw new Error('Supply at most 32 valid stop token IDs.');
    return {profileId: profile.id, text: $('text').value, configurationSource: local ? 'override' : inheritedResponse ? 'response' : 'profile',
      underlyingModel: profile.underlying_model, ...(inheritedResponse ? {snapshot: inheritedResponse.snapshot} : {}),
      scheme: schema.id, key, settings: values, options: {prompt_len: Number($('prefix').value), eos_token_ids: eos,
        add_special_tokens: $('special').checked, p_value_threshold: Number($('threshold').value), min_tokens: Number($('minimum').value)}};
  }
  const signature = () => { try { return JSON.stringify(request()); } catch { return ''; } };
  function refresh() {
    const profile = current(), generationModel = generationProfile();
    gen('controls').disabled = busy;
    gen('model').disabled = busy || !rows.length;
    gen('run').disabled = busy || !generate || !generationModel || !gen('prompt').value.trim();
    gen('copy').disabled = busy || !generated;
    gen('model-help').textContent = generationModel ? `${generationModel.modelLabel} · ${generationModel.scheme ? `Saved ${generationModel.scheme} settings and private key` : 'No saved watermark'} · Changes here apply to the next generation.` : 'Choose a named model from Models.';
    $('controls').disabled = busy;
    $('model').disabled = !rows.length || busy;
    $('scheme').disabled = !profile || busy;
    $('run').disabled = busy || !detect || !profile || !selectedScheme() || !$('text').value.trim();
    $('restore').disabled = busy || !profile || (!local && !inheritedResponse);
    $('source').textContent = !profile ? 'Choose a model' : local ? `Local override · this run only${inheritedResponse ? ' · response settings as base' : ''}` : inheritedResponse ? `Inherited response settings · ${profile.hasKey ? 'original private key' : 'no saved watermark'}` : profile.scheme ? 'Inherited profile settings' : 'Explicit scheme and key required';
    $('model-help').textContent = !profile ? catalogLoaded && !rows.length ? 'Create a named generation profile in Models, then reload the decoder.' : 'Select the model that generated this text.' : `${profile.modelLabel} · ${profile.hasKey ? 'Saved key stays private.' : 'No saved watermark key. Enter the original key.'}`;
    $('status').textContent = busy ? operation === 'generate' ? 'Waiting for generation…' : 'Scoring supplied text…' : !detect ? 'Model-aware decoding is not connected yet.' : failed ? 'Detection failed. Check the message and try again.' : !catalogLoaded ? 'Loading model profiles…' : 'Overrides apply to this run only.';
    $('stale').hidden = lastSignature === null || lastSignature === signature();
    $('result-state').textContent = failed ? 'LAST SUCCESSFUL RESULT' : !$('stale').hidden ? 'STALE' : 'COMPLETE';
  }
  function render(result, profile, schema, source) {
    const view = detectionPresentation(result, {modelLabel: `${profile.name} · ${profile.modelLabel}`, schemeLabel: schema.name});
    $('result').hidden = false; $('result').dataset.verdict = view.verdict;
    $('result-context').textContent = `${profile.name} · ${profile.modelLabel} / ${schema.name} / ${source === 'profile' ? 'Inherited settings' : source === 'response' ? 'Inherited response settings' : 'Run-only override'}${result.fixture === true ? ' / HTTP fixture · not native evidence' : ''}`;
    $('verdict').textContent = view.title; $('reason').textContent = view.reason; $('confidence').textContent = view.confidenceLabel;
    $('meter').hidden = view.confidence === null;
    if (view.confidence !== null) {
      $('meter').setAttribute('aria-valuenow', String(view.confidence * 100));
      $('meter').setAttribute('aria-valuetext', view.confidenceLabel);
      $('meter').firstElementChild.style.width = `${view.confidence * 100}%`;
    }
    const metrics = [['Tokens scored', result.tokens_scored], ['Null-tail p-value', view.pValueLabel], ['Evidence score', view.publicResult.strength ?? 'Unavailable'], ['Method', view.publicResult.method],
      ...Object.entries(view.publicResult.stats).map(([key, value]) => [key.replaceAll('_', ' '), JSON.stringify(value)])];
    $('statistics').replaceChildren(...metrics.map(([name, value]) => {
      const row = document.createElement('div'), label = document.createElement('dt'), content = document.createElement('dd');
      label.textContent = name; content.textContent = value; row.append(label, content); return row;
    }));
    $('raw').textContent = JSON.stringify(view.publicResult, null, 2);
  }
  $('model').onchange = inherit;
  $('restore').onclick = inherit;
  $('scheme').onchange = () => { const key = root.querySelector('#decoder-key')?.value || ''; local = true; fields({}, key); refresh(); };
  $('form').addEventListener('input', event => { if (event.target !== $('text') && event.target !== $('model')) local = true; refresh(); });
  $('form').addEventListener('change', refresh);
  $('form').onsubmit = async event => {
    event.preventDefault(); if (busy || !detect) return;
    $('error').hidden = true; failed = false;
    try {
      for (const input of $('form').querySelectorAll(':invalid')) { const details = input.closest('details'); if (details) details.open = true; }
      if (!$('form').reportValidity()) return;
      const body = request(), submitted = JSON.stringify(body), profile = structuredClone(current()), schema = structuredClone(selectedScheme());
      if (!body.text.trim()) throw new Error('Enter text to decode.');
      if (!body.key && !profile.hasKey) throw new Error('Missing watermark key. Supply the original key; no test was run.');
      busy = true; operation = 'detect'; $('run').textContent = 'Decoding…'; refresh();
      const result = await detect(structuredClone(body));
      render(result, profile, schema, body.configurationSource); lastSignature = submitted;
    } catch (error) {
      failed = true;
      const message = error.publicMessage || (busy ? 'Detection failed or returned invalid evidence. Check the model API and try again.' : error.message);
      $('error').textContent = bodySafeMessage(message); $('error').hidden = false;
    } finally { busy = false; operation = null; $('run').textContent = 'Decode watermark →'; refresh(); }
  };
  function bodySafeMessage(message) {
    // Explicit keys entered by a user must not be echoed by a callback failure.
    const key = root.querySelector('#decoder-key')?.value;
    return key ? String(message).replaceAll(key, '[private key]') : String(message);
  }
  function setProfiles(next) {
    rows = structuredClone(next);
    for (const select of [$('model'), gen('model')]) select.replaceChildren(option('', rows.length ? 'Choose a model' : 'No model profiles loaded'), ...rows.map(row => option(row.id, `${row.name} · ${row.modelLabel}`)));
    inherit();
  }
  gen('model').onchange = refresh;
  gen('prompt').oninput = refresh;
  gen('form').onsubmit = async event => {
    event.preventDefault(); if (busy || !generate) return;
    gen('error').hidden = true;
    try {
      for (const input of gen('form').querySelectorAll(':invalid')) { const details = input.closest('details'); if (details) details.open = true; }
      if (!gen('form').reportValidity()) return;
      const profile = structuredClone(generationProfile());
      if (!profile || !gen('prompt').value.trim()) throw new Error('Choose a model and enter a prompt.');
      busy = true; operation = 'generate'; gen('run').textContent = 'Generating…'; gen('status').textContent = 'Generating with saved model settings…'; refresh();
      const result = await generate({profileId: profile.id, prompt: gen('prompt').value, max_tokens: Number(gen('limit').value), temperature: Number(gen('temperature').value)});
      if (typeof result.answer !== 'string' || !result.answer.trim() || !result.snapshot) throw new Error('Invalid generated response.');
      generated = {snapshot: result.snapshot, answer: result.answer,
        profile: {...profile, name: result.model, modelLabel: result.modelLabel, scheme: result.scheme, settings: structuredClone(result.settings), hasKey: result.hasKey, underlying_model: result.underlying_model}};
      gen('output').value = generated.answer;
      gen('context').textContent = `${generated.profile.name} · ${generated.profile.modelLabel} · ${result.scheme || 'No watermark'}${result.fixture ? ' · HTTP fixture' : ''}. Copy keeps these original settings.${result.finish_reason === 'length' ? ' Response reached the token limit.' : ''}`;
      gen('status').textContent = 'Response ready to copy.';
    } catch (error) {
      gen('error').textContent = error.publicMessage || 'Generation failed. Retry; web manages the model API automatically.';
      gen('error').hidden = false; gen('status').textContent = generated ? 'Generation failed. Previous response remains below.' : 'Generation failed.';
    } finally { busy = false; operation = null; gen('run').textContent = 'Generate →'; refresh(); }
  };
  gen('copy').onclick = () => {
    if (!generated || busy) return;
    $('model').value = generated.profile.id;
    inherit();
    inheritedResponse = structuredClone(generated); local = false;
    $('scheme').value = generated.profile.scheme || '';
    fields(generated.profile.settings || {});
    $('text').value = generated.answer;
    $('error').hidden = true; failed = false; refresh(); $('text').focus();
    gen('status').textContent = `Copied ${generated.profile.name} response and its settings to the decoder.`;
  };
  setProfiles(rows);
  return {setProfiles, setCatalog(catalog) { definitions = structuredClone(catalog.schemes); catalogLoaded = true; setProfiles(catalog.profiles); },
    showError(message) { failed = true; $('error').textContent = message; $('error').hidden = false; refresh(); }};
}
