// Browser installation always follows a user click. CLI app windows need none.
export function setupWebApp(container) {
  const button = document.createElement('button');
  button.type = 'button'; button.className = 'app-install'; button.textContent = 'Install app';
  const standalone = matchMedia('(display-mode: standalone)');
  const minimal = matchMedia('(display-mode: minimal-ui)');
  let deferredPrompt = null;
  let installed = false;
  const update = () => { button.hidden = installed || standalone.matches || minimal.matches || !!navigator.standalone; };
  update(); container.append(button);
  standalone.addEventListener('change', update); minimal.addEventListener('change', update);
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); deferredPrompt = event; update();
  });
  window.addEventListener('appinstalled', () => { deferredPrompt = null; installed = true; update(); });

  const help = document.createElement('dialog'); help.className = 'app-install-dialog';
  help.setAttribute('aria-labelledby', 'app-install-title');
  const title = document.createElement('h2'); title.id = 'app-install-title'; title.textContent = 'Open AI Lab as an app';
  const instructions = document.createElement('p');
  instructions.textContent = /iPad|iPhone|iPod/.test(navigator.userAgent) ?
    'Use your browser’s Share menu, then Add to Home Screen.' :
    /Mac/.test(navigator.platform) && /Safari/.test(navigator.userAgent) && !/Chrome|Chromium|Edg/.test(navigator.userAgent) ?
      'In Safari on macOS Sonoma or later, choose File → Add to Dock, then Add.' :
      'In Chrome or Edge, use the install icon in the address bar or choose Install AI Lab from the browser menu. If installation is unavailable, use Chrome, Edge or Safari.';
  const note = document.createElement('p'); note.className = 'app-install-note';
  note.textContent = 'Keep ai-lab web running in your terminal while using the app. The CLI also opens an app window automatically when a supported browser is installed.';
  const close = document.createElement('button'); close.type = 'button'; close.textContent = 'Got it'; close.autofocus = true;
  close.onclick = () => help.close(); help.append(title, instructions, note, close); document.body.append(help);
  help.addEventListener('click', event => { if (event.target === help) {
    const rect = help.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) help.close();
  }});
  button.onclick = async () => {
    if (!deferredPrompt) { help.showModal(); return; }
    const prompt = deferredPrompt; deferredPrompt = null;
    button.disabled = true;
    try {
      await prompt.prompt();
      const choice = await prompt.userChoice;
      if (choice.outcome === 'accepted') installed = true;
    } catch { help.showModal(); }
    finally { button.disabled = false; update(); }
  };
  if ('serviceWorker' in navigator && window.isSecureContext) {
    navigator.serviceWorker.register('/service-worker.js', {scope: '/', updateViaCache: 'none'}).catch(() => {
      // Keep the regular website usable when browser policy blocks workers.
    });
  }
}
