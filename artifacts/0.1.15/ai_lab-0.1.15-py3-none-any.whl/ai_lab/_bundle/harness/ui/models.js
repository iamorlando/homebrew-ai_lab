import {schemeDescription, renderWatermarkFields, readWatermarkFields} from './watermark-config.js';
import './shell.js';
const $ = id => document.getElementById(id);
const text = (tag, value, className) => { const node = document.createElement(tag); node.textContent = value; if (className) node.className = className; return node; };
let saving = false;
let schemes = [];
function watermarkFields() {
  const scheme = schemes.find(s => s.id === $('watermark-scheme').value);
  $('watermark-description').replaceChildren(...(scheme ? [schemeDescription(scheme)] : []));
  $('watermark-description').hidden = !scheme;
  $('watermark-fields').hidden = !scheme;
  renderWatermarkFields(scheme, $('watermark-inputs'));
}
function watermarkValue() {
  return readWatermarkFields(schemes.find(s => s.id === $('watermark-scheme').value));
}
async function api(path, method = 'GET', body) {
  const response = await fetch(path, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  const data = await response.json();
  if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : JSON.stringify(data.detail || data));
  return data;
}
function error(message = '') { $('error').textContent = message; $('error').hidden = !message; }
function setSaving(value) {
  saving = value;
  document.querySelectorAll('#model-form input, #model-form select, #model-form button, #model-list button, #model-list select').forEach(el => { el.disabled = value; });
  $('add-model').textContent = value ? 'Saving…' : 'Add model';
}
function previewSeed() {
  const literal = $('model-seed').value.trim();
  let message = literal ? '' : 'Unseeded · runtime default';
  try {
    if (!/^(?:0x[0-9a-f]+(?:_[0-9a-f]+)*|[0-9]+(?:_[0-9]+)*)$/i.test(literal)) throw new Error();
    const seed = BigInt(literal.replaceAll('_', ''));
    if (seed > 9007199254740991n) throw new Error();
    message = `0x${seed.toString(16).toUpperCase()} · ${seed.toString(10)}`;
  } catch { /* The server validates the submitted value. */ }
  $('seed-preview').textContent = message;
}
async function loadModels() {
  const { models, underlying_models, watermark_schemes, watermark_note } = await api('/api/models');
  if (!schemes.length) {
    $('underlying-model').replaceChildren(...underlying_models.map(value => { const option = text('option', value); option.value = value; return option; }));
    schemes = watermark_schemes;
    for (const scheme of schemes) { const option = text('option', scheme.name); option.value = scheme.id; $('watermark-scheme').append(option); }
    $('watermark-note').textContent = watermark_note;
  }
  $('model-count').textContent = `${models.length} ${models.length === 1 ? 'model' : 'models'}`;
  $('no-models').hidden = models.length > 0;
  $('model-list').replaceChildren();
  for (const model of models) {
    const row = document.createElement('tr');
    const backendCell = document.createElement('td');
    const backend = document.createElement('select'); backend.setAttribute('aria-label', `Underlying model for ${model.name}`);
    for (const value of underlying_models) { const option = text('option', value); option.value = value; backend.append(option); }
    backend.value = model.underlying_model;
    backend.onchange = async () => {
      setSaving(true); error();
      try { await api(`/api/models/${model.key}`, 'PATCH', {underlying_model: backend.value}); await loadModels(); $('model-status').textContent = `Updated ${model.name}.`; }
      catch(e) { backend.value = model.underlying_model; error(e.message); }
      finally { setSaving(false); }
    };
    backendCell.append(backend);
    row.append(text('td', model.name, 'configured-model-name'), backendCell);
    const seed = text('td', '', 'configured-seed');
    if (model.seed == null) seed.append(text('div', 'Unseeded'), text('div', 'Runtime default', 'seed-decimal'));
    else seed.append(text('div', model.seed_literal), text('div', String(model.seed), 'seed-decimal'));
    const actions = document.createElement('td'); const remove = text('button', 'Remove', 'remove-model');
    remove.type = 'button'; remove.setAttribute('aria-label', `Remove ${model.name}`);
    remove.onclick = async () => {
      if (saving) return;
      setSaving(true); error(); $('model-status').textContent = '';
      try { await api(`/api/models/${model.key}`, 'DELETE'); await loadModels(); $('model-status').textContent = `Removed ${model.name}.`; }
      catch (e) { error(e.message); }
      finally { setSaving(false); }
    };
    const scheme = schemes.find(s => s.id === model.watermark?.scheme);
    const watermark = text('td', model.watermark ? scheme?.name || model.watermark.scheme : 'None');
    if (model.watermark) {
      const details = document.createElement('details'); details.append(text('summary', 'About & parameters'));
      if (scheme) details.append(schemeDescription(scheme));
      details.append(text('pre', JSON.stringify(Object.fromEntries(Object.entries(model.watermark).filter(([key]) => key !== 'key')), null, 2), 'watermark-parameters'));
      watermark.append(details);
    }
    actions.append(remove); row.append(seed, watermark, actions); $('model-list').append(row);
  }
}
$('model-seed').oninput = previewSeed;
$('watermark-scheme').onchange = watermarkFields;
$('model-form').onsubmit = async event => {
  event.preventDefault(); if (saving) return;
  let body;
  try { body = { name: $('model-name').value.trim(), seed: $('model-seed').value.trim() || null, underlying_model: $('underlying-model').value, watermark: watermarkValue() }; }
  catch(e) { error(e.message); return; }
  setSaving(true); error(); $('model-status').textContent = '';
  try {
    const model = await api('/api/models', 'POST', body); await loadModels();
    $('model-form').reset(); watermarkFields(); previewSeed(); $('model-status').textContent = `${model.name} is ready to select.`;
  } catch(e) { error(e.message); }
  finally { setSaving(false); }
};
previewSeed();
try {
  await loadModels();
  const backends = await api('/api/generation-backends');
  $('backend-status').textContent = backends.map(b => `${b.label}: ${b.status}${b.running ? '' : ` · ${b.installed ? b.run_command : b.install_command}`}`).join(' | ');
} catch(e) { error(e.message); }
