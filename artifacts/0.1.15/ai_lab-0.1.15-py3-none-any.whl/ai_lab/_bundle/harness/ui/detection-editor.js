import {words, targetWord, wordAlternative, replaceWord} from './detection-edit-data.mjs';
import {tokenGroups} from './completion-watermark-data.mjs';
import {percent, number, explanation} from './watermark-trace-data.mjs';

const el = (tag, text = '', cls = '') => { const n = document.createElement(tag); n.textContent = text; n.className = cls; return n; };
const button = (text, action, cls = '') => { const n = el('button',text,cls); n.type = 'button'; n.onclick = action; return n; };

export class DetectionEditor {
  constructor({container, input, toggle, undo, help, inspect, onChange, onBusy}) {
    Object.assign(this, {container,input,toggle,undo,help,inspect,onChange,onBusy});
    this.text = ''; this.original = ''; this.history = []; this.cache = new Map(); this.serial = 0; this.disabled = false;
    toggle.onclick = () => {
      this.input.hidden = !this.input.hidden; this.container.hidden = !this.input.hidden;
      if (!this.input.hidden) { this.input.value = this.text; this.typingStart = this.text; this.input.focus(); }
      else this.render();
      this.controls();
    };
    input.oninput = () => {
      if (this.typingStart !== null && this.input.value !== this.text) { this.history.push(this.typingStart); this.typingStart = null; }
      this.change(input.value, false);
    };
    undo.onclick = () => { if (this.history.length) { this.change(this.history.pop(), false); this.input.value = this.text; } };
    this.buildDialog(); this.controls();
  }
  setResponse(text, request) {
    this.serial++; this.text = this.original = text; this.request = request; this.history = []; this.cache.clear();
    this.input.hidden = true; this.container.hidden = false; this.render();
  }
  setDisabled(value) { this.disabled = value; this.controls(); }
  controls() {
    this.toggle.disabled = this.disabled || !this.request;
    this.undo.disabled = this.disabled || !this.history.length;
    this.input.disabled = this.disabled;
    this.toggle.textContent = this.input.hidden ? 'Edit text' : 'Done editing';
    for (const word of this.container.querySelectorAll('button')) word.disabled = this.disabled;
    this.help.hidden = !this.request;
    this.help.textContent = this.text === this.original ? 'Click any word for green/red alternatives, or edit the text.' : 'Edited response · click any word to replace it again. Original generation traces are unchanged.';
  }
  render() {
    const scrollTop = this.container.scrollTop, nodes = []; let end = 0;
    for (const range of words(this.text)) {
      nodes.push(document.createTextNode(this.text.slice(end,range.start)));
      const word = button(range.text, () => this.open(range), 'response-word');
      word.dataset.start = range.start; word.setAttribute('aria-label', `Replace “${range.text}”`);
      word.setAttribute('aria-haspopup','dialog');
      nodes.push(word); end = range.end;
    }
    nodes.push(document.createTextNode(this.text.slice(end))); this.container.replaceChildren(...nodes);
    this.container.scrollTop = scrollTop; this.input.value = this.text; this.controls();
  }
  change(text, save = true) {
    if (text === this.text) return;
    const previous = this.text;
    if (save) this.history.push(previous);
    this.text = text;
    if (this.input.hidden) this.render(); else this.controls();
    this.onChange(text,previous);
  }
  buildDialog() {
    this.dialog = el('dialog','','word-dialog'); this.dialog.setAttribute('aria-labelledby','word-dialog-title');
    const header = el('div','','word-dialog-header'); this.title = el('h2'); this.title.id = 'word-dialog-title';
    header.append(this.title,button('Close ×',()=>this.dialog.close()));
    this.context = el('p','','word-context');
    const form = el('form','','word-replacement-form');
    const label = el('label','Replacement text'); label.htmlFor = 'word-replacement';
    this.replacement = el('input'); this.replacement.id = 'word-replacement'; this.replacement.maxLength = 200; this.replacement.required = true;
    const apply = button('Replace word →',()=>{}); apply.type = 'submit';
    form.append(label,this.replacement,apply);
    form.onsubmit = event => { event.preventDefault(); if(this.replacement.value.trim()) this.replace(this.replacement.value); };
    this.status = el('p','','field-help'); this.status.setAttribute('role','status');
    this.roundControl = el('div','','word-round-control'); const roundLabel = el('label','Color lists for round');
    this.roundSelect = el('select'); this.roundSelect.id = 'word-round'; roundLabel.htmlFor = 'word-round';
    this.roundSelect.onchange = () => { this.round = Number(this.roundSelect.value); this.renderLists(); };
    this.roundControl.append(roundLabel,this.roundSelect);
    this.lists = el('div','','word-lists');
    this.more = button('Show all captured words',()=>{ this.expanded = !this.expanded; this.renderLists(); });
    const note = el('p','Colors use the response’s generation key. These are fresh next-token alternatives for the text before this word; the original sampling history is not replayed. A token may be a word fragment. Choosing one replaces the whole word.','field-help word-inspection-note');
    this.dialog.append(header,this.context,form,this.status,this.roundControl,this.lists,this.more,note);
    this.dialog.addEventListener('close',()=>{ this.serial++; this.container.querySelector(`[data-start="${this.target?.start}"]`)?.focus({preventScroll:true}); });
    document.body.append(this.dialog);
  }
  async open(range) {
    if (this.disabled || !this.request) return;
    this.target = targetWord(this.text,range); this.round = 0; this.expanded = false; this.result = null;
    const target = this.target, request = {...this.request, prefix:target.prefix}, serial = ++this.serial;
    this.title.textContent = `Replace “${range.text}”`; this.replacement.value = range.text;
    this.context.replaceChildren(document.createTextNode(this.text.slice(Math.max(0,range.start-90),range.start)), el('mark',range.text), document.createTextNode(this.text.slice(range.end,range.end+90)));
    this.lists.replaceChildren(); this.more.hidden = this.roundControl.hidden = true;
    this.status.textContent = 'Loading alternatives for this word…'; this.dialog.showModal();
    try {
      this.onBusy(true);
      const cached = this.cache.get(target.prefix), result = cached || await this.inspect(request);
      if (serial !== this.serial) return;
      this.cache.set(target.prefix,result);
      if(this.cache.size > 24) this.cache.delete(this.cache.keys().next().value);
      this.result = result;
      this.roundSelect.replaceChildren(...(result.step.layers || []).slice(0,4).map((layer,i)=>{ const option=el('option',String(layer.index+1));option.value=i;return option; }));
      this.roundSelect.value = '0'; this.renderLists();
    } catch(error) { if(serial === this.serial) this.status.textContent = `${error.message} You can still type a replacement above.`; }
    finally { this.onBusy(false); }
  }
  renderLists() {
    const step = this.result.step, groups = tokenGroups(step,this.round);
    const readable = rows => rows.map(row=>({row,word:wordAlternative(row,this.target)})).filter(item=>item.word);
    const ordered = rows => readable(rows).sort((a,b)=>(b.row.input_logit ?? -Infinity)-(a.row.input_logit ?? -Infinity));
    const keyed = step.selection_rule === 'keyed_argmax', tournament = step.selection_rule === 'synthid_tournament';
    const all = groups.available ? [
      [step.watermark.scheme==='mpac' ? 'Favored group' : 'Green list', ordered(groups.green), 'green'],
      [step.watermark.scheme==='mpac' ? 'Other groups' : 'Red list', ordered(groups.red), 'red']
    ] : [['Alternatives',ordered(step.candidates),'neutral']];
    this.roundControl.hidden = !(groups.available && groups.layer);
    this.status.textContent = `${groups.available ? 'Click an alternative to replace this word.' : explanation(step)} Showing ${this.expanded ? 'all' : 'up to 10'} readable captured alternatives${groups.available ? ' per list' : ''}, ranked by model probability. ${tournament ? 'Input probabilities; this tournament has no post-watermark probability vector.' : keyed ? 'Input probability · key score.' : 'Probability before → after watermarking.'} Response position: ${this.result.response_position + 1}.`;
    this.lists.replaceChildren();
    for(const [name,items,color] of all) {
      const section=el('section','',`word-list ${color}`); section.append(el('h3',`${name} / ${items.length}`));
      for(const {row,word} of this.expanded ? items : items.slice(0,10)) {
        const choice=button('',()=>this.replace(word),'word-choice'); choice.dataset.replacement=word;
        choice.disabled = word === this.target.text;
        choice.setAttribute('aria-label',`Replace with ${word}`); choice.title=`Token ${row.token_id} · ${JSON.stringify(row.text)}`;
        choice.append(el('strong',word),el('span',`${word === this.target.text ? 'current · ' : ''}${percent(row.pre_watermark_probability)}${tournament ? '' : keyed ? ` · score ${number(row.selection_score)}` : ` → ${percent(row.post_watermark_probability)}`}`));
        section.append(choice);
      }
      if(!items.length) section.append(el('p','No readable alternatives captured in this group. Try another word or type a replacement.','field-help'));
      this.lists.append(section);
    }
    this.more.hidden = !all.some(([,items])=>items.length>10); this.more.textContent = this.expanded ? 'Show top 10 per list' : 'Show all captured words';
  }
  replace(word) {
    this.change(replaceWord(this.text,this.target,word)); this.dialog.close();
  }
}
