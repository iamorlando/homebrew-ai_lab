const text = (tag, value, className) => { const node = document.createElement(tag); node.textContent = value; if (className) node.className = className; return node; };
const randomKey = () => Array.from(crypto.getRandomValues(new Uint8Array(32)), byte => byte.toString(16).padStart(2, '0')).join('');
export function schemeDescription(scheme) {
  const info = text('div', '', 'scheme-description');
  info.append(text('p', scheme.description));
  const paper = text('a', `Paper: ${scheme.paper.title} ↗`, 'scheme-paper');
  paper.href = scheme.paper.url; paper.target = '_blank'; paper.rel = 'noopener noreferrer';
  paper.setAttribute('aria-label', `Paper: ${scheme.paper.title} (opens in a new tab)`);
  info.append(paper);
  return info;
}
export function renderWatermarkFields(scheme, container, prefix = 'wm', defaults = {}, options = {}) {
  container.replaceChildren();
  for (const spec of scheme?.fields || []) {
    const wrapper = text('div', '', 'field');
    const input = document.createElement(spec.type === 'enum' ? 'select' : 'input'); input.id = `${prefix}-${spec.name}`;
    const label = text('label', spec.label); label.htmlFor = input.id;
    if (spec.type === 'enum') {
      for (const option of spec.options) { const node = text('option', option.label); node.value = option.value; input.append(node); }
    } else input.type = spec.type === 'boolean' ? 'checkbox' : ['integer', 'number'].includes(spec.type) ? 'number' : 'text';
    if (spec.type === 'boolean') input.checked = defaults[spec.name] ?? spec.default;
    else { input.required = true; input.value = defaults[spec.name] ?? (spec.type === 'key' ? options.generateKey === false ? '' : randomKey() : spec.type === 'symbols' ? spec.default.join(', ') : spec.default); }
    if (spec.min !== undefined) input.min = spec.min;
    if (spec.max !== undefined) input.max = spec.max;
    input.step = spec.step || '1';
    if (spec.name === 'vocab_size') input.readOnly = true;
    if (spec.type === 'key') { input.pattern = '[0-9a-fA-F]{64}'; input.maxLength = 64; input.autocomplete = 'off'; input.spellcheck = false;
      if (options.generateKey === false) { input.type = 'password'; input.required = options.keyRequired !== false; }
    }
    wrapper.append(label, input);
    if (spec.type === 'key' && options.generateKey !== false) { const button = text('button', 'Generate key'); button.type = 'button'; button.onclick = () => { input.value = randomKey(); input.dispatchEvent(new Event('input', {bubbles: true})); }; wrapper.append(button); }
    if (spec.help) {
      const message = spec.type === 'key' && options.generateKey === false
        ? 'Use the original 64-character hexadecimal key. Decoding never creates a key.' : spec.help;
      const help = text('p', message, 'field-help'); help.id = `${input.id}-help`; input.setAttribute('aria-describedby', help.id); wrapper.append(help);
    }
    container.append(wrapper);
  }
  const policy = document.getElementById(`${prefix}-generation_policy`), depth = document.getElementById(`${prefix}-depth`);
  if (policy && depth) {
    const constrain = () => { depth.max = policy.value === 'tournament' ? '20' : '256'; };
    policy.addEventListener('change', constrain); constrain();
  }
}
export function readWatermarkFields(scheme, prefix = 'wm') {
  if (!scheme) return null;
  const result = { scheme: scheme.id };
  for (const spec of scheme.fields) {
    const input = document.getElementById(`${prefix}-${spec.name}`);
    if (spec.type === 'boolean') result[spec.name] = input.checked;
    else if (spec.type === 'symbols') {
      const symbols = input.value.trim().split(',').map(s => s.trim());
      if (!symbols.every(s => /^\d+$/.test(s))) throw new Error('Payload symbols must be comma-separated integers.');
      result[spec.name] = symbols.map(Number);
    } else result[spec.name] = ['integer', 'number'].includes(spec.type) ? Number(input.value) : input.value.trim();
  }
  return result;
}

export function writeWatermarkFields(scheme, values, prefix = 'wm') {
  for (const spec of scheme.fields) {
    const input = document.getElementById(`${prefix}-${spec.name}`), value = values[spec.name];
    if (value === undefined) continue;
    if (spec.type === 'boolean') input.checked = value;
    else input.value = spec.type === 'symbols' ? value.join(', ') : value;
  }
  const policy = document.getElementById(`${prefix}-generation_policy`), depth = document.getElementById(`${prefix}-depth`);
  if (policy && depth) depth.max = policy.value === 'tournament' ? '20' : '256';
}
