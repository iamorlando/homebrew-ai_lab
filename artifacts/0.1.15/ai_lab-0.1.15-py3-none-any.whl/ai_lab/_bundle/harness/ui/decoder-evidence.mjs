// Presentation only: never calculate a detector score or create evidence.
const probability = value => value == null ? 'Unavailable' : value === 0 ? '<1e-300' : value < .001 ? value.toExponential(3) : value.toFixed(6);
export const confidenceLabel = value => value == null ? 'Unavailable' : value > .999999 ? '>99.9999%' : `${(value * 100).toFixed(4)}%`;
const finiteProbability = value => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1;
const count = value => Number.isSafeInteger(value) && value >= 0;
const nativeFields = ['mean_g_value', 'z_score', 'mean_cost', 'green_count', 'green_fraction', 'trials', 'votes'];
const numeric = value => typeof value === 'number' && Number.isFinite(value) || Array.isArray(value) && value.length <= 1024 && value.every(numeric);

export function detectionPresentation(result, {modelLabel, schemeLabel} = {}) {
  if (!result || !['match', 'no_match', 'insufficient'].includes(result.verdict) || !count(result.tokens_scored)
      || !Number.isSafeInteger(result.min_tokens) || result.min_tokens < 1
      || !finiteProbability(result.p_value_threshold) || result.p_value_threshold === 0) {
    throw new Error('The detector returned invalid evidence.');
  }
  for (const field of ['p_value', 'confidence']) {
    if (result[field] != null && !finiteProbability(result[field])) throw new Error('The detector returned invalid evidence.');
  }
  if (result.p_value != null && result.confidence != null && Math.abs(result.confidence - (1 - result.p_value)) > 1e-10) {
    throw new Error('The detector returned inconsistent confidence.');
  }
  const insufficient = result.verdict === 'insufficient' || result.tokens_scored < result.min_tokens || result.p_value == null || result.confidence == null;
  if (!insufficient) {
    const passes = result.p_value <= result.p_value_threshold;
    if ((result.verdict === 'match') !== passes || (result.matches !== undefined && result.matches !== passes)) {
      throw new Error('The detector returned a verdict inconsistent with its p-value cutoff.');
    }
  } else if (result.matches === true) {
    throw new Error('The detector returned a match without sufficient evidence.');
  }
  const verdict = insufficient ? 'insufficient' : result.verdict;
  const pValue = insufficient ? null : result.p_value, confidence = insufficient ? null : result.confidence;
  const stats = Object.fromEntries(nativeFields.filter(key => numeric(result.stats?.[key])).map(key => [key, result.stats[key]]));
  const method = typeof result.method === 'string' ? result.method : 'No valid known-key test';
  const publicResult = {verdict, tokens_scored: result.tokens_scored, min_tokens: result.min_tokens,
    p_value: pValue, confidence, p_value_threshold: result.p_value_threshold,
    strength: typeof result.strength === 'number' && Number.isFinite(result.strength) ? result.strength : null,
    method, stats};
  if (modelLabel) publicResult.model = modelLabel;
  if (schemeLabel) publicResult.scheme = schemeLabel;
  if (result.fixture === true) publicResult.fixture = true;
  const cutoff = `the configured cutoff (p ≤ ${probability(result.p_value_threshold)})`;
  return {verdict, confidence, publicResult,
    title: {match: 'Watermark detected', no_match: 'Below detection threshold', insufficient: 'Insufficient evidence'}[verdict],
    reason: insufficient ? result.tokens_scored < result.min_tokens
      ? `Scored ${result.tokens_scored} tokens; at least ${result.min_tokens} are required before evaluating the detection threshold.`
      : 'No valid known-key score is available; the detection threshold was not evaluated.'
      : verdict === 'match'
        ? `The p-value (${probability(pValue)}) meets ${cutoff}. Confidence is 1 − p, not a probability that the key is present.`
        : `The selected key was tested. The p-value (${probability(pValue)}) is above ${cutoff}. Confidence is 1 − p; a high value can still fall below this detection threshold.`,
    confidenceLabel: insufficient ? 'Insufficient evidence' : confidenceLabel(confidence),
    pValueLabel: probability(pValue)};
}
