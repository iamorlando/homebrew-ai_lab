import './shell.js';
import {number, percent, piece, remainingMass} from './watermark-trace-data.mjs';
import {distributionBar} from './distribution-bars.js';
import {schemeDescription, renderWatermarkFields, readWatermarkFields} from './watermark-config.js';
import {renderWatermark} from './completion-watermark.js';

const $ = id => document.getElementById(id);
const node = (tag, text = '', cls = '') => { const el = document.createElement(tag); el.textContent = text; el.className = cls; return el; };
let result = null, chosen = null, busy = false, mode = 'logits', round = 0, schemes = [], resultConfig = '';
const selectedScheme = () => schemes.find(s => s.id === $('completion-scheme').value);
const watermarkValue = () => readWatermarkFields(selectedScheme(), 'completion-wm');
const signature = () => { try { return JSON.stringify({model: $('completion-model').value, watermark: watermarkValue()}); } catch { return ''; } };
const current = () => result?.prompt === $('completion-prompt').value && resultConfig === signature();
function controls() {
  $('completion-run').disabled = busy || !$('completion-prompt').value.length;
  $('completion-clear').disabled = busy; $('completion-prompt').disabled = busy;
  $('completion-append').disabled = busy || !current() || !chosen?.text || $('completion-prompt').value.length + (chosen?.text?.length || 0) > 24000;
  $('completion-stale').hidden = !result || current();
  $('completion-run').textContent = busy ? 'Scoring prefix…' : 'Inspect next token →';
  for (const input of document.querySelectorAll('#completion-model, #completion-scheme, #completion-watermark-inputs input, #completion-watermark-inputs select, #completion-watermark-inputs button')) input.disabled = busy;
}
function inspectToken(candidate) {
  chosen = candidate;
  $('inspector-empty').hidden = true; $('token-inspector').hidden = false;
  $('chosen-status').textContent = candidate.token_id === result.step.selected_token_id ? 'EMITTED TOKEN' : 'INSPECTING AN ALTERNATIVE';
  $('chosen-token').textContent = piece(candidate); $('chosen-id').textContent = candidate.token_id;
  $('chosen-logit').textContent = number(candidate.input_logit);
  $('chosen-probability').textContent = percent(candidate.reporting_probability);
  $('chosen-final-probability').textContent = percent(candidate.post_watermark_probability);
  $('chosen-logprob').textContent = candidate.reporting_probability > 0 ? number(Math.log(candidate.reporting_probability)) : '−∞';
  $('completion-preview').textContent = result.prompt + (candidate.text || '');
  for (const row of $('completion-chart').querySelectorAll('[data-token]')) {
    const active = Number(row.dataset.token) === candidate.token_id;
    row.classList.toggle('active', active); row.querySelector('button').setAttribute('aria-pressed', String(active));
  }
  if (mode === 'watermark') renderWatermark($('completion-watermark'), result, chosen, round, inspectToken, value => { round = value; inspectToken(chosen); $('completion-round')?.focus({preventScroll:true}); });
  controls();
}
function render() {
  if (!result) return;
  const step = result.step, candidates = [...step.candidates].sort((a,b) => (b.input_logit ?? -Infinity) - (a.input_logit ?? -Infinity)).slice(0,10);
  const sampled = step.candidates.find(c => c.token_id === step.selected_token_id);
  $('actual-token').textContent = piece(sampled); $('actual-token').dataset.tokenId = sampled.token_id; $('actual-token').onclick = () => inspectToken(sampled);
  $('completion-sampled').hidden = candidates.includes(sampled);
  $('completion-sampled').textContent = `Sampled outside the top 10: ${piece(sampled)} / inspect →`;
  $('completion-sampled').onclick = () => inspectToken(sampled);
  const logits = mode === 'logits', bound = Math.max(1, ...candidates.map(c => Math.abs(c.input_logit || 0)));
  const watermarked = !!step.watermark, keyed = step.selection_rule === 'keyed_argmax', tournament = step.selection_rule === 'synthid_tournament', finalAvailable = !keyed && !tournament;
  $('completion-empty').hidden = true; $('completion-results').hidden = false;
  $('vocab-count').textContent = `${step.candidate_count.toLocaleString()} TOKENS`;
  for (const [id, value] of [['logits','logits'],['probabilities','probability'],['watermark','watermark']]) $('view-'+id).setAttribute('aria-pressed', String(mode === value));
  $('completion-distribution').hidden = mode === 'watermark'; $('completion-watermark').hidden = mode !== 'watermark';
  $('distribution-help').textContent = logits ? 'Raw model scores before sampling and watermarking. Zero is the center line. Select a token to inspect it.' : watermarked ? tournament ? 'Input probabilities for actual tournament draws. The bracket selects the emitted token; this policy does not calculate post-watermark probabilities.' : keyed ? 'Input probabilities before keyed selection. Key scores and the selected token appear in Watermarking; this scheme does not report a final categorical distribution.' : 'Before → after watermarking, at temperature 1. Both bars use the full-vocabulary 0–100% scale.' : 'Probability at temperature 1 across the full vocabulary. Bars use a fixed 0–100% scale; alternatives are not renormalized.';
  $('distribution-scale').textContent = logits ? `LOGIT / −${number(bound)} TO +${number(bound)}` : 'PROBABILITY / 0–100%';
  $('completion-chart').replaceChildren();
  for (const c of candidates) {
    const row = node('div', '', 'completion-row'); row.dataset.token = c.token_id;
    const token = node('button', '', 'completion-token'); token.type = 'button';
    token.append(node('code', piece(c)), node('small', `#${c.token_id}${c.token_id === step.selected_token_id ? ' / sampled' : ''}`));
    token.setAttribute('aria-label', `Inspect token ${piece(c)}, ID ${c.token_id}`);
    token.onclick = () => inspectToken(c);
    const bars = node('div', '', 'trace-bars');
    bars.append(distributionBar(logits ? c.input_logit : c.reporting_probability, watermarked && !logits ? 'before' : 'after', logits, bound));
    if (!logits && watermarked && finalAvailable) bars.append(distributionBar(c.post_watermark_probability, 'after'));
    row.append(token, bars);
    $('completion-chart').append(row);
  }
  const mass = remainingMass(candidates, 'reporting_probability');
  if (!logits) { const row = node('div', '', 'completion-row completion-other'), bars = node('div', '', 'trace-bars'); bars.append(distributionBar(mass, 'before')); if(watermarked && finalAvailable) bars.append(distributionBar(remainingMass(candidates,'post_watermark_probability'),'after')); row.append(node('span', 'Other tokens'), bars); $('completion-chart').append(row); }
  $('completion-mass').textContent = `Top ${candidates.length} alternatives by model probability${watermarked ? ' before watermarking' : ''}. Other tokens hold ${percent(mass)} of the input probability mass.`;
  const table = node('table'), head = node('thead'), heading = node('tr'), body = node('tbody');
  for (const label of ['Token / ID', 'Raw logit', 'Before p', 'After p', 'Before ln(p)']) heading.append(node('th', label));
  head.append(heading);
  for (const c of candidates) { const row = node('tr'); for (const text of [`${piece(c)} / ${c.token_id}`, number(c.input_logit), percent(c.reporting_probability), percent(c.post_watermark_probability), c.reporting_probability > 0 ? number(Math.log(c.reporting_probability)) : '−∞']) row.append(node('td', text)); body.append(row); }
  table.append(head, body); $('completion-values').replaceChildren(table);
  inspectToken(step.candidates.find(c => c.token_id === chosen?.token_id) || sampled);
}
async function run() {
  if (busy || !$('completion-prompt').value.length) return;
  for (const input of $('completion-form').querySelectorAll(':invalid')) { const details = input.closest('details'); if (details) details.open = true; }
  if (!$('completion-form').reportValidity()) return;
  busy = true; controls(); $('error').hidden = true; $('completion-status').textContent = 'WORKING / scoring one next-token decision';
  try {
    const watermark = watermarkValue(), config = signature();
    const response = await fetch('/api/completion', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({prompt:$('completion-prompt').value, watermark, model:$('completion-model').value})});
    const data = await response.json();
    if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : 'The prefix could not be scored. Check its length and try again.');
    if (!data.step?.candidates?.length) throw new Error('Mistral returned no token scores.');
    result = data; resultConfig = config; chosen = null; round = 0;
    if (data.step.generation_tournament?.used_for_generation) mode = 'watermark';
    render();
    $('completion-status').textContent = `COMPLETE / ${data.step.context_length} context tokens · 1 decision · top ${Math.min(10, data.step.candidates.length)} alternatives`;
  } catch (error) {
    $('error').textContent = error.message; $('error').hidden = false; $('completion-status').textContent = 'ERROR / prefix not scored';
  } finally { busy = false; controls(); }
}
$('completion-form').onsubmit = event => { event.preventDefault(); run(); };
$('completion-prompt').oninput = controls;
$('completion-model').onchange = () => { $('completion-model-label').textContent = $('completion-model').value; controls(); };
$('completion-scheme').onchange = () => {
  const scheme = selectedScheme();
  renderWatermarkFields(scheme, $('completion-watermark-inputs'), 'completion-wm', {generation_policy:'tournament', depth:4});
  $('completion-scheme-description').replaceChildren(...(scheme ? [schemeDescription(scheme)] : []));
  $('completion-scheme-description').hidden = !scheme; $('completion-watermark-settings').hidden = !scheme;
  $('completion-mode').textContent = scheme ? `TEMPORARY / ${scheme.name}` : 'RAW PREFIX / NO WATERMARK';
  document.body.dataset.theme = scheme ? 'watermark' : 'completion';
  controls();
};
$('completion-watermark-inputs').oninput = controls;
$('completion-watermark-inputs').onchange = controls;
$('completion-prompt').onkeydown = event => { if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) { event.preventDefault(); run(); } };
$('completion-clear').onclick = () => {
  result = null; chosen = null; $('completion-prompt').value = ''; $('completion-results').hidden = true; $('token-inspector').hidden = true; $('completion-empty').hidden = false; $('inspector-empty').hidden = false; $('error').hidden = true; $('vocab-count').textContent = 'AWAITING INPUT'; $('completion-status').textContent = 'READY / enter a prefix'; controls(); $('completion-prompt').focus();
};
$('completion-append').onclick = () => {
  if (!current() || !chosen?.text || busy) return;
  $('completion-prompt').value += chosen.text;
  const position = $('completion-wm-start_position');
  if (position) position.value = String(Number(position.value) + 1);
  run();
};
$('view-logits').onclick = () => { mode = 'logits'; render(); };
$('view-probabilities').onclick = () => { mode = 'probability'; render(); };
$('view-watermark').onclick = () => { mode = 'watermark'; render(); };
controls();
try {
  const response = await fetch('/api/models');
  if (!response.ok) throw new Error('Watermark schemes could not be loaded. Reload the page to try again.');
  schemes = (await response.json()).watermark_schemes;
  for (const scheme of schemes) { const option = node('option', scheme.name); option.value = scheme.id; $('completion-scheme').append(option); }
} catch(error) { $('error').textContent = error.message; $('error').hidden = false; }
