import {number, percent} from './watermark-trace-data.mjs';

// Shared renderer for actual model logits and full-vocabulary probabilities.
export function distributionBar(value, kind, logit = false, bound = 1) {
  const line = document.createElement('div'); line.className = 'trace-bar-line';
  const track = document.createElement('div'); track.className = `trace-track${logit ? ' logits' : ''}`;
  const fill = document.createElement('div'); fill.className = `trace-fill ${kind}`;
  if (Number.isFinite(value)) {
    const width = logit ? Math.abs(value) / Math.max(1, bound) * 50 : Math.max(0, Math.min(1, value)) * 100;
    fill.style.width = `${width}%`;
    if (logit) fill.style.left = `${value < 0 ? 50 - width : 50}%`;
  }
  const label = document.createElement('span'); label.textContent = logit ? number(value) : percent(value);
  track.append(fill); line.append(track, label);
  line.setAttribute('aria-label', `${kind}: ${label.textContent}${logit ? ' logit' : ''}`);
  return line;
}
