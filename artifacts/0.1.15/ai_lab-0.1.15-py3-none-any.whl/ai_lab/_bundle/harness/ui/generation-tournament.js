import {percent, piece} from './watermark-trace-data.mjs';
import {matchExplanation} from './completion-watermark-data.mjs';
import {productionGraph} from './generation-tournament-data.mjs';

const el = (tag, text = '', cls = '') => { const node = document.createElement(tag); node.textContent = text; node.className = cls; return node; };
export function generationTournament(step, choose) {
  const report = step.generation_tournament, section = el('section', '', 'completion-tournament production-tournament');
  section.append(el('h3', 'Actual generation tournament'));
  if (!report || report.status !== 'applied' || report.origin !== 'production' || report.used_for_generation !== true) {
    const messages = {
      no_production_bracket:'Probability-update sampling does not execute a bracket. Choose “Tournament · actual bracket” and a depth from 1 to 20 in Scheme settings.',
      warmup:'The prefix is too short for this watermark. No tournament ran for this token.',
      repeated_context:'This context was already marked. No tournament ran for this token.',
      greedy:'Greedy sampling skipped the tournament.',
    };
    section.append(el('p', messages[report?.status] || `No production bracket was recorded (${report?.status || 'unavailable'}). Choose SynthID / Tournament · actual bracket and inspect again.`, 'trace-notice'));
    return section;
  }
  let graph;
  try { graph = productionGraph(step); }
  catch (error) {
    section.append(el('p', `Recorded bracket unavailable: ${error.message} Run again to capture a complete bracket; omitted matches cannot be inspected.`, 'trace-notice'));
    return section;
  }
  const sampled = step.candidates.find(c => c.token_id === step.selected_token_id);
  section.append(el('p', `${report.total_draws.toLocaleString()} actual draws → ${report.rounds} rounds → emitted token. Green (1) beats red (0); equal scores use the generation RNG to break the tie.`, 'tournament-guide'));
  const outcome = el('div', '', 'production-outcome'); outcome.dataset.tokenId = sampled.token_id;
  const inspect = el('button', `Winner = emitted token: ${piece(sampled)}`); inspect.type = 'button'; inspect.onclick = () => choose(sampled);
  outcome.append(inspect, el('small', `Token ${sampled.token_id} · selected by this bracket`)); section.append(outcome);
  if (report.truncated) section.append(el('p', `${report.matches.length} of ${report.total_matches.toLocaleString()} matches captured. Collapsed subtrees show their recorded advancing tokens; their internal matches are unavailable. Capture limit: ${report.truncation_reason}. All ${report.rounds} generation rounds ran.`, 'trace-notice'));
  const detail = el('div', '', 'tournament-match-detail'); detail.setAttribute('aria-live', 'polite'); section.append(detail);
  const navigation = el('div', '', 'tournament-navigation'), previous = el('button', '← Previous match'), next = el('button', 'Next match →'), position = el('span');
  previous.type = next.type = 'button'; navigation.append(previous,position,next); section.append(navigation);
  const scroll = el('div', '', 'completion-bracket-scroll'); scroll.tabIndex = 0; scroll.setAttribute('aria-label', 'Actual generation tournament bracket');
  const bracket = el('div', '', 'completion-bracket'), gap = 148, boxWidth = 126, rowHeight = 42, offset = 35;
  const width = Math.max(boxWidth,graph.columns*gap), height = Math.max(90,graph.leaves*rowHeight+offset);
  bracket.style.width = `${width}px`; bracket.style.height = `${height}px`;
  const svg = document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('viewBox',`0 0 ${width} ${height}`); svg.setAttribute('aria-hidden','true'); bracket.append(svg);
  const nodes = new Map(), buttons = new Map(), edges = [], matches = graph.nodes.filter(n => n.match).map(n => n.match).sort((a,b)=>a.round-b.round || a.match_id-b.match_id);
  const labeled = new Set();
  for (const node of graph.nodes) {
    const x = node.column*gap, y = offset+(node.y+.5)*rowHeight;
    if (!labeled.has(node.column)) { const label = el('div', node.round < 0 ? 'ACTUAL DRAWS' : `ROUND ${node.round+1} WINNERS`, 'bracket-column-label'); label.style.left = `${x}px`; bracket.append(label); labeled.add(node.column); }
    const item = el(node.match ? 'button' : 'div', '', `bracket-node ${node.match ? `bracket-match ${node.match[node.match.winner].g_value ? 'green' : 'red'}${node.match.reason === 'random_tie' ? ' tied' : ''}` : node.subtree ? 'bracket-collapsed' : 'bracket-draw'}`);
    item.style.left = `${x}px`; item.style.top = `${y-15}px`;
    const caption = node.match ? node.match.reason === 'random_tie' ? 'Tie-break winner' : 'Green beats red' : node.subtree ? `Collapsed · ${node.subtree.match_count.toLocaleString()} matches` : `Draw ${node.token.draw_id+1} · ${percent(node.token.probability)}`;
    item.append(el('code',piece(node.token)),el('small',caption));
    item.title = `${piece(node.token)} · token ${node.token.token_id} · draw ${node.token.draw_id+1}${node.token.text_status !== 'decoded' ? ` · text ${node.token.text_status}` : ''}`;
    if (node.match) { item.type = 'button'; item.dataset.match = node.match.match_id; item.setAttribute('aria-label',`Round ${node.round+1}, match ${node.match.match_id+1}: ${piece(node.token)} advances`); item.onclick = () => { select(node.match.match_id); detail.scrollIntoView({block:'nearest'}); }; buttons.set(node.match.match_id,item); }
    else if (node.subtree) item.dataset.collapsed = node.subtree.root_match_id;
    nodes.set(node.key,{x,y,item}); bracket.append(item);
  }
  for (const edge of graph.edges) {
    const from = nodes.get(edge.from), to = nodes.get(edge.to), path = document.createElementNS('http://www.w3.org/2000/svg','path');
    path.setAttribute('d',`M${from.x+boxWidth},${from.y} H${to.x-11} V${to.y} H${to.x}`); path.classList.toggle('winning-edge',edge.winner);
    edges.push({...edge,path}); svg.append(path);
  }
  scroll.append(bracket); section.append(scroll,el('p','Click a match winner, or Tab to the bracket and use ←/→ for matches, Home/End for first/final captured match, and Enter to activate a focused button. Each node comes from this generation trace. Repeated token draws remain separate contestants. Input probabilities describe the initial draws, not match-winning probabilities.','field-help'));
  const replay = el('details','','trace-values'); replay.append(el('summary','Replay details'),el('p',`Generation seed ${report.effective_seed ?? 'unavailable'} · ${report.rng_version} · ${report.sampling_version || 'sampling version unavailable'} · step ${step.generated_index+1} · accepted attempt ${step.attempt}. Replay also requires the same prefix, key, model and sampling settings.`,'field-help')); section.append(replay);
  let selected = 0;
  function select(id) {
    selected = matches.findIndex(m => m.match_id === id); const match = matches[selected];
    if (!match) return;
    detail.replaceChildren(el('h4',`ROUND ${match.round+1} / MATCH ${match.match_id+1}`));
    const contestants = el('div','','tournament-contestants');
    for (const side of ['left','right']) {
      const entrant = match[side], card = el('div','',`tournament-contestant ${entrant.g_value ? 'green' : 'red'}${side === match.winner ? ' winner' : ''}`);
      card.append(el('span',`Draw ${entrant.draw_id+1} · ${side === match.winner ? 'ADVANCES' : 'ELIMINATED'}`,'contestant-status'),el('code',piece(entrant.draw)),el('strong',`${entrant.g_value ? 'GREEN' : 'RED'} / score ${entrant.g_value}`),el('small',`Initial draw probability ${percent(entrant.draw.probability)}${entrant.source.kind === 'collapsed_subtree' ? ' · advanced from a collapsed subtree' : ''}`)); contestants.append(card);
    }
    detail.append(contestants,el('p',matchExplanation(match),'tournament-explanation'));
    position.textContent = `${selected+1} / ${matches.length} captured`; previous.disabled = selected === 0; next.disabled = selected === matches.length-1;
    for (const [identity,button] of buttons) { button.classList.toggle('active',identity === id); button.setAttribute('aria-pressed',String(identity === id)); }
    for (const edge of edges) edge.path.classList.toggle('inspected-edge',edge.to === `match:${id}`);
  }
  previous.onclick = () => select(matches[selected-1].match_id); next.onclick = () => select(matches[selected+1].match_id);
  scroll.onkeydown = event => {
    if (!matches.length || event.altKey || event.ctrlKey || event.metaKey) return;
    const index = {ArrowLeft:selected-1, ArrowRight:selected+1, Home:0, End:matches.length-1}[event.key];
    if (index === undefined) return;
    event.preventDefault();
    const match = matches[Math.max(0, Math.min(index, matches.length-1))];
    select(match.match_id);
    const button = buttons.get(match.match_id);
    button.focus({preventScroll:true}); button.scrollIntoView({block:'nearest', inline:'nearest'});
  };
  if (matches.length) select(buttons.has(report.winner.match_id) ? report.winner.match_id : matches.at(-1).match_id);
  else {
    navigation.hidden = true;
    detail.append(el('p','No inspectable matches were captured. Scores and tie breaks inside collapsed subtrees are unavailable. Run again with a lower tournament depth.','trace-notice'));
  }
  return section;
}
