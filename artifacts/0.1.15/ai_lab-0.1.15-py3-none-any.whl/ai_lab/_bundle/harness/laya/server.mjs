import {createServer} from 'node:http';
import {existsSync, realpathSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {parseArgs} from 'node:util';

const MAX_BYTES = 100_000;
const MODEL = 'laya';
const text = value => typeof value === 'string' ? value : JSON.stringify(value);
const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);

function questionsToLaya(questions) {
  if (!record(questions) || !Object.keys(questions).length || Object.keys(questions).length > 64) {
    throw new Error('Supply 1–64 named questions.');
  }
  // The library stores answers in a plain object. Use internal IDs and restore
  // the caller's IDs after inference, including names such as __proto__.
  const ids = Object.keys(questions);
  const normalized = Object.fromEntries(ids.map((id, index) => {
    const q = questions[id];
    if (!id.trim() || id.length > 128 || !record(q) || !['noul', 'choice', 'score'].includes(q.type)) {
      throw new Error('Invalid question ID or type.');
    }
    const c = q.criteria;
    if (q.type === 'choice' && (!record(c) || !Object.keys(c).length || Object.keys(c).length > 255)) {
      throw new Error('Choice requires 1–255 named options.');
    }
    if (q.type === 'score' && (!Array.isArray(c) || c.length < 2 || c.length > 10)) {
      throw new Error('Score requires 2–10 ordered levels.');
    }
    if (q.type === 'noul' && c != null && (!record(c) || Object.keys(c).some(k => !['true', 'false'].includes(k)))) {
      throw new Error('Noul criteria must describe true and/or false.');
    }
    const criteria = Array.isArray(c) ? c.map(text) : record(c)
      ? Object.fromEntries(Object.entries(c).map(([k, v]) => [k, v == null ? null : text(v)])) : undefined;
    return [`q${index}`, {type: q.type, instructions: q.instructions == null ? '' : text(q.instructions), ...(criteria ? {criteria} : {})}];
  }));
  return {ids, normalized};
}

export function createDecisionServer(laya, {root}) {
  let queue = Promise.resolve();
  let pending = 0;
  return createServer(async (request, response) => {
    const send = (status, value) => {
      response.writeHead(status, {'Content-Type': 'application/json', 'Cache-Control': 'no-store'});
      response.end(JSON.stringify(value));
    };
    if (request.method === 'GET' && request.url === '/v1/models') {
      send(200, {models: [{name: MODEL}], workspace: root});
      return;
    }
    if (request.method !== 'POST' || request.url !== '/v1/systemone') {
      send(404, {detail: 'Unknown endpoint.'});
      return;
    }
    if (pending >= 8) {
      send(503, {detail: 'Laya is busy. Try again shortly.'});
      return;
    }
    pending++;
    try {
      let bytes = 0;
      const chunks = [];
      for await (const chunk of request) {
        bytes += chunk.length;
        if (bytes > MAX_BYTES) {
          send(413, {detail: 'Decision requests must be at most 100 KB.'});
          return;
        }
        chunks.push(chunk);
      }
      const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      if (!record(body) || body.model !== MODEL || !(typeof body.state === 'string' || record(body.state) || Array.isArray(body.state))) {
        throw new Error('Supply model laya, a text or JSON state, and typed questions.');
      }
      const {ids, normalized} = questionsToLaya(body.questions);
      const work = queue.then(() => laya.systemOne(body.state, normalized));
      queue = work.catch(() => {});
      const result = await work;
      send(200, {...result, model: MODEL, answers: Object.fromEntries(ids.map((id, i) => [id, result.answers[`q${i}`]]))});
    } catch (error) {
      send(422, {detail: error instanceof SyntaxError ? 'Invalid JSON request.' : String(error.message).slice(0, 1000)});
    } finally {
      pending--;
    }
  });
}

async function main() {
  const {values} = parseArgs({options: {'model-dir': {type: 'string'}, root: {type: 'string'}, port: {type: 'string', default: '8710'}}});
  if (!values['model-dir'] || !values.root || !/^\d+$/.test(values.port) || +values.port < 1 || +values.port > 65535) {
    throw new Error('Supply --model-dir, --root, and a port from 1 to 65535.');
  }
  const {Laya} = await import('@receptron/laya');
  // A local modelDir prevents first-request downloads and network freshness checks.
  const laya = await Laya.load({modelDir: resolve(values['model-dir']), executionProviders: ['cpu'], sessionOptions: {intraOpNumThreads: 4}});
  const server = createDecisionServer(laya, {root: resolve(values.root)});
  server.on('error', async error => {
    console.error(error.message);
    await laya.close();
    process.exitCode = 1;
  });
  server.listen(+values.port, '127.0.0.1', () => console.log(`Laya listening on 127.0.0.1:${values.port}`));
  const stop = () => server.close(async () => { await laya.close(); });
  process.once('SIGTERM', stop);
  process.once('SIGINT', stop);
}

if (process.argv[1] && existsSync(process.argv[1]) && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  main().catch(error => { console.error(error.message); process.exitCode = 1; });
}
