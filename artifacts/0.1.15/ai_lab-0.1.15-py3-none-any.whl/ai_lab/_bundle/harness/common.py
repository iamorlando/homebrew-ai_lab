import json
import os
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from project_paths import ROOT
from inference import MODEL, BASE_URL, parse_seed
from harness.generation_models import generation_backend

PROVIDER = "mistral-local"
OPENCODE = ROOT / ".runtime/opencode/opencode"
HARBOR = ROOT / ".venv/bin/harbor"


def load_seed(path):
    from dotenv import dotenv_values
    values = dotenv_values(path)
    raw = values.get("DEEPSEEK_SEED")
    if raw is None:
        raise ValueError(f"{path}: missing DEEPSEEK_SEED")
    return parse_seed(raw)


def opencode_config(seed, base_url, plugin="file:///root/.config/opencode/plugins/stable-prompt.js", model_alias=MODEL):
    return {
        "$schema": "https://opencode.ai/config.json",
        "model": f"{PROVIDER}/{model_alias}",
        "small_model": f"{PROVIDER}/{model_alias}",
        "default_agent": "sonnet",
        "enabled_providers": [PROVIDER],
        "share": "disabled",
        "autoupdate": False,
        "snapshot": False,
        "plugin": [plugin],
        "compaction": {"auto": False},
        "tools": {"*": False},
        "agent": {
            "sonnet": {
                "mode": "primary",
                "description": "Write the requested poem without tools.",
                "prompt": "You are a poet. Follow the user's requested form precisely. Do not use tools. Return only the requested poem.",
                "temperature": 0.6,
                "top_p": 0.95,
                "tools": {"*": False},
                "permission": {"*": "deny"},
            },
            "title": {"disable": True},
            "summary": {"disable": True},
            "compaction": {"disable": True},
        },
        "provider": {
            PROVIDER: {
                "npm": "@ai-sdk/openai-compatible",
                "name": "AI Lab via local mistral.rs",
                "options": {"baseURL": base_url.rstrip("/") + "/v1", "apiKey": "local-only", "timeout": 600000},
                "models": {
                    model_alias: {
                        "id": MODEL,
                        "name": model_alias if model_alias != MODEL else "DeepSeek R1 8B",
                        "reasoning": True,
                        "temperature": True,
                        "tool_call": False,
                        "limit": {"context": 8192, "output": 4096},
                        "options": {"seed": seed} if seed is not None else {},
                        "cost": {"input": 0, "output": 0},
                    }
                },
            }
        },
    }


def seed_profiles():
    from model_profiles import ModelProfiles
    return ModelProfiles().profiles()


def seed_model_name(seed, literal=None):
    if literal and literal.lower().startswith("0x"):
        hexadecimal = literal[2:].upper()
    else:
        hexadecimal = f"{seed:X}"
        if len(hexadecimal) > 6:
            hexadecimal = hexadecimal[:-6] + "_" + hexadecimal[-6:]
    return f"DeepSeek_0x{hexadecimal}"


def app_config(seed=None, plugin=None, profiles=None):
    profiles = seed_profiles() if profiles is None else profiles
    selected = next((key for key, profile in profiles.items() if seed is not None and profile["seed"] == seed), next(iter(profiles), None))
    config = opencode_config(profiles[selected]["seed"] if selected else 0, BASE_URL)
    # OpenCode resolves SDK URLs from model.provider.api only when the provider
    # has no global baseURL override. Keep legacy provider/profile IDs stable.
    config["provider"][PROVIDER]["options"].pop("baseURL")
    template = config["provider"][PROVIDER]["models"][MODEL]
    config["provider"][PROVIDER]["models"] = {
        key: {
            **template, "id": generation_backend(profile).api_model, "name": profile["name"],
            "provider": {"api": generation_backend(profile).base_url + "/v1"},
            "options": {**({"seed": profile["seed"]} if profile["seed"] is not None else {}),
                        **({"watermark": profile["watermark"]} if profile.get("watermark") else {})},
            "variants": {effort: {"disabled": True} for effort in ("low", "medium", "high")},
        }
        for key, profile in profiles.items()
    }
    if selected:
        config["model"] = config["small_model"] = f"{PROVIDER}/{selected}"
    else:
        config.pop("model")
        config.pop("small_model")
    config["default_agent"] = "seeded"
    config["agent"]["seeded"] = {
        **config["agent"]["sonnet"],
        "description": "A conversation with its own model settings and history, independent of other sessions.",
        "prompt": "You are a helpful assistant. Follow the user's instructions. Do not use tools.",
    }
    config["plugin"] = [[plugin or (ROOT / "harness/seeded-profiles.mjs").as_uri(), {
        "provider": PROVIDER, "sampling_version": 2,
        "seeds": {key: profile["seed"] for key, profile in profiles.items()},
        "watermarks": {key: profile["watermark"] for key, profile in profiles.items() if profile.get("watermark")},
    }]]
    return config


def viewer_environment(seed=None):
    directory = ROOT / ".state/opencode-viewer"
    # OpenCode 1.18.32 defaults to collapsed reasoning in its TUI KV store.
    # Preserve other preferences while opening recorded sessions expanded.
    preferences = directory / "state/opencode/kv.json"
    preferences.parent.mkdir(parents=True, exist_ok=True)
    saved = json.loads(preferences.read_text()) if preferences.exists() else {}
    saved["thinking_mode"] = "show"
    temporary = preferences.with_suffix(".tmp")
    temporary.write_text(json.dumps(saved, indent=2) + "\n")
    temporary.replace(preferences)
    config = directory / "config/opencode/opencode.json"
    config.parent.mkdir(parents=True, exist_ok=True)
    plugins = config.parent / "plugins"
    # Older viewers auto-loaded the sonnet plugin from this directory.
    (plugins / "stable-prompt.js").unlink(missing_ok=True)
    config.write_text(json.dumps(app_config(seed), indent=2) + "\n")
    env = os.environ.copy()
    env.update({
        "XDG_CONFIG_HOME": str(directory / "config"),
        "XDG_DATA_HOME": str(directory / "data"),
        "XDG_STATE_HOME": str(directory / "state"),
        "XDG_CACHE_HOME": str(directory / "cache"),
        "OPENCODE_CONFIG": str(config),
        "OPENCODE_CONFIG_DIR": str(config.parent),
        "OPENCODE_DISABLE_PROJECT_CONFIG": "true",
        "OPENCODE_DISABLE_MODELS_FETCH": "true",
        "OPENCODE_DISABLE_AUTOUPDATE": "true",
        "OPENCODE_DISABLE_DEFAULT_PLUGINS": "true",
    })
    return env


def import_session(source, label, seed):
    data = json.loads(source.read_text())
    data["info"]["title"] = f"{label} | Sonnet + fixed follow-up"
    profile = next((key for key, value in seed_profiles().items() if value["seed"] == seed), None)
    if profile:
        # Only the viewer copy uses friendly aliases; the original export stays untouched.
        model = data["info"].get("model", {})
        if model.get("providerID") == PROVIDER:
            model["id"] = profile
        for message in data["messages"]:
            info = message["info"]
            if info.get("providerID") == PROVIDER:
                info["modelID"] = profile
            if info.get("model", {}).get("providerID") == PROVIDER:
                info["model"]["modelID"] = profile
    prepared = source.with_name("session.viewer.json")
    prepared.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    subprocess.run([str(OPENCODE), "import", str(prepared)], cwd=ROOT, env=viewer_environment(seed), check=True)
    return data["info"]["id"]
