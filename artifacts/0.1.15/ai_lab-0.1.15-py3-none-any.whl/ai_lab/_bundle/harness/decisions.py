"""Typed decisions through native local CLM or the server-authenticated Jev API."""
import asyncio
import json
import math
import os
from pathlib import Path
import signal
import time
import sys
from typing import Annotated, Literal

from fastapi import HTTPException
from fastapi.responses import JSONResponse
import httpx
from pydantic import BaseModel, ConfigDict, Field, JsonValue, model_validator
from ai_lab.credentials import jev_key
from ai_lab.laya import installed as laya_installed
from ai_lab import decision_processes

from clm_upstream import REVISION as UPSTREAM_REVISION, installed as upstream_installed

CLM_MODEL = decision_processes.MODEL
LOCAL_URL = 'http://127.0.0.1:11436'
UPSTREAM_URL = 'http://127.0.0.1:8700'
LAYA_URL = 'http://127.0.0.1:8710'
DecisionProvider = Literal['contrastive', 'jev']
JEV_URL = 'https://api.typesafe.ai/v1/systemone'
STARTUP_SECONDS = 600
MAX_REQUEST_BYTES = 100_000


class Question(BaseModel):
    model_config = ConfigDict(extra='forbid')
    type: Literal['noul', 'choice', 'score']
    instructions: str | dict[str, JsonValue] | list[JsonValue] | None = None
    criteria: dict[str, JsonValue] | list[JsonValue] | None = None

    @model_validator(mode='after')
    def check_criteria(self):
        c = self.criteria
        text = lambda v: isinstance(v, (str, dict, list))
        if self.type == 'noul':
            if c is not None and (not isinstance(c, dict) or any(
                    k not in {'true', 'false'} or not text(v) for k, v in c.items())):
                raise ValueError('Noul criteria must describe true and/or false.')
        elif self.type == 'choice':
            if not isinstance(c, dict) or not 1 <= len(c) <= 255 or any(
                    not k.strip() or (v is not None and not text(v)) for k, v in c.items()):
                raise ValueError('Choice requires 1–255 named options with text, JSON, or null descriptions.')
        elif not isinstance(c, list) or not 2 <= len(c) <= 10 or any(not text(v) for v in c):
            raise ValueError('Score requires 2–10 ordered rubric levels.')
        return self


class DecisionInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    model: DecisionProvider = 'contrastive'
    state: str | dict[str, JsonValue] | list[JsonValue]
    questions: dict[str, Question] = Field(min_length=1, max_length=64)

    @model_validator(mode='after')
    def check_names(self):
        if any(not k.strip() or len(k) > 128 for k in self.questions):
            raise ValueError('Question IDs must contain 1–128 characters.')
        return self


class RankInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    model: DecisionProvider = 'contrastive'
    context: str | dict[str, JsonValue] | list[JsonValue]
    question: str | None = None
    answers: list[Annotated[str, Field(min_length=1, max_length=24000)]] = Field(min_length=2, max_length=255)


class DecisionRuntime:
    def __init__(self, root, *, transport=None, allow_start=True):
        self.root = Path(root)
        self.allow_start = allow_start
        self.url = os.environ.get('AI_LAB_DECISIONS_URL', LOCAL_URL).rstrip('/')
        parsed = self.loopback(self.url, 'AI_LAB_DECISIONS_URL')
        self.port = parsed.port or 80
        # The native runtime is ours at any supported loopback origin. A URL
        # override chooses its bind address; it does not prove process ownership.
        self.managed = True
        self.upstream_url = os.environ.get('AI_LAB_CLM_UPSTREAM_URL', UPSTREAM_URL).rstrip('/')
        self.upstream_port = self.loopback(self.upstream_url, 'AI_LAB_CLM_UPSTREAM_URL').port or 80
        self.upstream_managed = 'AI_LAB_CLM_UPSTREAM_URL' not in os.environ
        self.transport = transport
        self.process = None
        self.process_state = None
        self.log = None
        self.start_lock = asyncio.Lock()
        self.upstream_process = None
        self.upstream_log = None
        self.upstream_start_lock = asyncio.Lock()
        self.laya_url = os.environ.get('AI_LAB_LAYA_URL', LAYA_URL).rstrip('/')
        self.laya_port = self.loopback(self.laya_url, 'AI_LAB_LAYA_URL').port or 80
        self.laya_managed = decision_processes.host_port(self.laya_url)[0] == '127.0.0.1'
        self.laya_process = None
        self.laya_state = None
        self.laya_log = None
        self.laya_start_lock = asyncio.Lock()

    @staticmethod
    def loopback(url, setting):
        return decision_processes.loopback(url, setting)

    def upstream_available(self):
        return not self.upstream_managed or upstream_installed(self.root)

    def laya_available(self):
        return 'AI_LAB_LAYA_URL' in os.environ or not self.laya_managed or laya_installed(self.root)

    def laya_headers(self):
        key = os.environ.get('AI_LAB_LAYA_API_KEY', '').strip()
        return {'Authorization': f'Bearer {key}'} if key else {}

    def upstream_headers(self):
        key = os.environ.get('AI_LAB_CLM_UPSTREAM_API_KEY', '').strip()
        return {'Authorization': f'Bearer {key}'} if key else {}

    def client(self, timeout=120):
        return httpx.AsyncClient(timeout=timeout, trust_env=False, transport=self.transport)

    def local_headers(self):
        key = os.environ.get('AI_LAB_DECISIONS_API_KEY', '').strip()
        return {'Authorization': f'Bearer {key}'} if key else {}

    async def local_model(self):
        try:
            async with self.client(2) as client:
                response = await client.get(self.url + '/v1/models', headers=self.local_headers())
            if response.status_code != 200:
                raise HTTPException(503, 'The local decision server rejected discovery. Check its authentication and /v1/models endpoint.')
            models = response.json().get('models', [])
            wanted = os.environ.get('AI_LAB_DECISIONS_MODEL')
            for model in models:
                if isinstance(model, dict) and isinstance(model.get('name'), str) and (not wanted or model['name'] == wanted):
                    return model['name']
            raise HTTPException(503, 'The local Mistral server has no matching decision model. Load Contrastive-LM/CLM-v0.1-8B, or point AI_LAB_DECISIONS_URL at its server.')
        except (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadError):
            return None
        except (ValueError, TypeError, AttributeError, httpx.HTTPError) as error:
            raise HTTPException(503, 'Could not discover the local Mistral decision model.') from error

    async def ensure_local(self):
        async with self.start_lock:
            if model := await self.local_model():
                return model
            if not self.allow_start:
                raise HTTPException(503, 'The native CLM API is stopped. Open ai-lab web to start it automatically when you run a decision.')
            binary = decision_processes.binary(self.root)
            model_dir = self.root / '.models/clm-v0.1-8b'
            if not binary.is_file() or not (model_dir / 'config.json').is_file():
                raise HTTPException(503, 'Install the CLM/Qwen weights and native Metal server with '
                                    'ai-lab setup install clm --yes, then retry in the website.')
            if not self.process or self.process.returncode is not None:
                if await asyncio.to_thread(decision_processes.owned_state, self.root):
                    raise HTTPException(503, 'The owned native CLM API is not ready or its launch settings changed. '
                                        'Restart ai-lab web and retry. Check .state/decisions-mistral.log.')
                if not await asyncio.to_thread(decision_processes.port_available, self.url):
                    raise HTTPException(503, 'The native CLM endpoint belongs to another process or workspace. '
                                        'Stop it with its original launcher, then retry in AI Lab.')
                if self.log:
                    self.log.close()
                state = self.root / '.state'
                state.mkdir(parents=True, exist_ok=True)
                self.log = (state / 'decisions-mistral.log').open('a')
                env = os.environ.copy()
                for key in ('JEV_API_KEY', 'TYPESAFE_API_KEY'):
                    env.pop(key, None)
                env.update(HF_HOME=str(self.root / '.runtime/huggingface'), HF_HUB_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
                try:
                    argv = decision_processes.command(self.root, self.url, binary)
                    self.process = await asyncio.create_subprocess_exec(
                        *argv, cwd=self.root, env=env,
                        stdin=asyncio.subprocess.DEVNULL, stdout=self.log, stderr=self.log, start_new_session=True)
                    self.process_state = await asyncio.to_thread(decision_processes.capture_process, self.root, self.url, argv, self.process)
                    decision_processes.record_state(self.root, self.process_state)
                except OSError as error:
                    raise HTTPException(503, 'Could not start the local decision runtime. Check AI_LAB_DECISIONS_BINARY.') from error
                except ValueError as error:
                    raise HTTPException(503, 'The launched native CLM identity could not be recorded. '
                                        'Inspect its original launcher and .state/decisions-mistral.log.') from error
            deadline = time.monotonic() + STARTUP_SECONDS
            while time.monotonic() < deadline:
                if self.process.returncode is not None:
                    raise HTTPException(503, 'The local CLM runtime exited. Check .state/decisions-mistral.log and the Qwen3-8B encoder files.')
                if model := await self.local_model():
                    return model
                await asyncio.sleep(.5)
            await self.close()
            raise HTTPException(504, 'The local decision model took too long to load. Check .state/decisions-mistral.log.')

    async def upstream_model(self):
        try:
            async with self.client(2) as client:
                response = await client.get(self.upstream_url + '/v1/models', headers=self.upstream_headers())
            if response.status_code != 200:
                raise HTTPException(503, 'Upstream CLM rejected discovery. Check its authentication.')
            if any(isinstance(model, dict) and model.get('name') == 'clm-latest'
                   for model in response.json().get('models', [])):
                return 'clm-latest'
            raise HTTPException(503, 'The upstream server has no clm-latest projection-head model.')
        except (httpx.ConnectError, httpx.ConnectTimeout):
            return None
        except (ValueError, TypeError, AttributeError, httpx.HTTPError) as error:
            raise HTTPException(503, 'Could not discover the upstream CLM model.') from error

    async def ensure_upstream(self):
        if self.allow_start and not self.upstream_available():
            raise HTTPException(503, 'Install upstream CLM with ai-lab weights install clm --yes to finish setup.')
        async with self.upstream_start_lock:
            if model := await self.upstream_model():
                return model
            if not self.allow_start:
                raise HTTPException(503, 'The legacy upstream CLM API is stopped. Start it through its original upstream launcher; '
                                    'the legacy adapter is omitted from ai-lab services.')
            if not self.upstream_managed:
                raise HTTPException(503, 'The configured upstream CLM server is unavailable. Check AI_LAB_CLM_UPSTREAM_URL.')
            if not self.upstream_process or self.upstream_process.returncode is not None:
                if self.upstream_log:
                    self.upstream_log.close()
                state = self.root / '.state'
                state.mkdir(parents=True, exist_ok=True)
                self.upstream_log = (state / 'clm-upstream.log').open('a')
                env = os.environ.copy()
                for key in ('JEV_API_KEY', 'TYPESAFE_API_KEY', 'AI_LAB_CLM_UPSTREAM_API_KEY'):
                    env.pop(key, None)
                try:
                    self.upstream_process = await asyncio.create_subprocess_exec(
                        sys.executable, str(Path(__file__).with_name('clm_upstream.py')), 'serve',
                        '--root', str(self.root), '--port', str(self.upstream_port),
                        cwd=self.root, env=env, stdin=asyncio.subprocess.DEVNULL,
                        stdout=self.upstream_log, stderr=self.upstream_log, start_new_session=True)
                except OSError as error:
                    raise HTTPException(503, 'Could not start the upstream CLM supervisor.') from error
            deadline = time.monotonic() + STARTUP_SECONDS
            while time.monotonic() < deadline:
                if self.upstream_process.returncode is not None:
                    raise HTTPException(503, 'Upstream CLM exited. Check .state/clm-upstream.log and .state/clm-upstream-encoder.log.')
                if model := await self.upstream_model():
                    return model
                await asyncio.sleep(.5)
            raise HTTPException(504, 'Upstream CLM took too long to load. Check its API and encoder logs.')

    async def laya_model(self):
        try:
            async with self.client(2) as client:
                response = await client.get(self.laya_url + '/v1/models', headers=self.laya_headers())
            if response.status_code != 200:
                raise HTTPException(503, 'Laya rejected model discovery. Check its server and authentication.')
            data = response.json()
            # Configured external APIs retain their read-only discovery contract.
            # Only process receipts can grant lifecycle ownership.
            check_workspace = self.laya_managed and ('AI_LAB_LAYA_URL' not in os.environ or self.laya_process is not None)
            if check_workspace and (not isinstance(data.get('workspace'), str)
                                      or Path(data['workspace']).resolve() != self.root.resolve()):
                raise HTTPException(503, 'The Laya port belongs to another workspace. Set AI_LAB_LAYA_URL to your server.')
            if any(isinstance(model, dict) and model.get('name') == 'laya' for model in data.get('models', [])):
                return 'laya'
            raise HTTPException(503, 'The configured server has no Laya model.')
        except (httpx.ConnectError, httpx.ConnectTimeout):
            return None
        except (ValueError, TypeError, AttributeError, httpx.HTTPError) as error:
            raise HTTPException(503, 'Could not discover the Laya model.') from error

    async def ensure_laya(self):
        if self.allow_start and not self.laya_available():
            raise HTTPException(503, 'Install Laya with ai-lab weights install laya --yes.')
        async with self.laya_start_lock:
            if model := await self.laya_model():
                return model
            if not self.allow_start:
                raise HTTPException(503, 'The Laya API is stopped. Run ai-lab services --action start --model laya in your workspace terminal.')
            if not self.laya_managed:
                raise HTTPException(503, 'The configured Laya server is unavailable. The managed Laya server binds IPv4 loopback; '
                                    'set AI_LAB_LAYA_URL to a 127.0.0.1 or localhost HTTP origin.')
            if not laya_installed(self.root):
                raise HTTPException(503, 'Install Laya with ai-lab weights install laya --yes.')
            if not self.laya_process or self.laya_process.returncode is not None:
                if await asyncio.to_thread(decision_processes.owned_state, self.root, family='laya'):
                    raise HTTPException(503, 'The owned Laya API is not ready or its launch settings changed. '
                                        'Run ai-lab services --action restart --model laya. Check .state/laya.log.')
                if not await asyncio.to_thread(decision_processes.port_available, self.laya_url):
                    raise HTTPException(503, 'The Laya endpoint belongs to another process or workspace. '
                                        'Use its original launcher to stop it, then run ai-lab services --action start --model laya.')
                if self.laya_log:
                    self.laya_log.close()
                state = self.root / '.state'
                state.mkdir(parents=True, exist_ok=True)
                self.laya_log = (state / 'laya.log').open('a')
                env = os.environ.copy()
                for key in ('JEV_API_KEY', 'TYPESAFE_API_KEY', 'AI_LAB_LAYA_API_KEY', 'HF_TOKEN'):
                    env.pop(key, None)
                try:
                    argv = decision_processes.command(self.root, self.laya_url, family='laya')
                    self.laya_process = await asyncio.create_subprocess_exec(
                        *argv, cwd=self.root, env=env,
                        stdin=asyncio.subprocess.DEVNULL, stdout=self.laya_log, stderr=self.laya_log, start_new_session=True)
                    self.laya_state = await asyncio.to_thread(decision_processes.capture_process, self.root,
                                                              self.laya_url, argv, self.laya_process, family='laya')
                    decision_processes.record_state(self.root, self.laya_state, family='laya')
                except OSError as error:
                    raise HTTPException(503, 'Could not start Laya. Run ai-lab weights install laya --yes to repair it.') from error
                except ValueError as error:
                    raise HTTPException(503, 'The launched Laya identity could not be recorded. '
                                        'Inspect its original launcher and .state/laya.log.') from error
            deadline = time.monotonic() + STARTUP_SECONDS
            while time.monotonic() < deadline:
                if self.laya_process.returncode is not None:
                    raise HTTPException(503, 'Laya exited. Check .state/laya.log.')
                if model := await self.laya_model():
                    return model
                await asyncio.sleep(.5)
            raise HTTPException(504, 'Laya took too long to load. Check .state/laya.log.')

    async def decide(self, body):
        if len(json.dumps(body, ensure_ascii=False).encode()) > MAX_REQUEST_BYTES:
            raise HTTPException(422, 'Decision requests must be at most 100 KB.')
        provider = body['model']
        label = {'contrastive': 'Mistral', 'clm-upstream': 'Upstream CLM', 'laya': 'Laya', 'jev': 'Jev'}[provider]
        if provider == 'jev':
            key = jev_key(self.root)
            if not key:
                raise HTTPException(403, 'Jev is not configured on this server.')
            url, model = JEV_URL, 'jev-latest'
            headers = {'Authorization': f'Bearer {key}'}
        elif provider == 'clm-upstream':
            url, model = self.upstream_url + '/v1/systemone', await self.ensure_upstream()
            headers = self.upstream_headers()
        elif provider == 'laya':
            url, model = self.laya_url + '/v1/systemone', await self.ensure_laya()
            headers = self.laya_headers()
        else:
            url, model = self.url + '/v1/systemone', await self.ensure_local()
            headers = self.local_headers()
        started = time.monotonic()
        try:
            async with self.client() as client:
                response = await client.post(url, json={**body, 'model': model}, headers=headers)
        except httpx.TimeoutException as error:
            raise HTTPException(504, f'{label} timed out. Try a shorter state or fewer candidates.') from error
        except httpx.HTTPError as error:
            raise HTTPException(502, f'Could not reach {label}. Check the server connection.') from error
        if response.status_code != 200:
            if provider == 'jev':
                messages = {401: 'Jev rejected the server API key.', 403: 'Jev access was denied.',
                            429: 'Jev rate limit reached. Try again later.', 422: 'Jev rejected this decision request.'}
                raise HTTPException(response.status_code if response.status_code in messages else 502,
                                    messages.get(response.status_code, 'Jev could not complete this request.'))
            try:
                error = response.json()
                detail = error.get('error', error.get('detail', ''))
                if isinstance(detail, dict):
                    detail = detail.get('message', '')
            except (ValueError, AttributeError):
                detail = ''
            if headers.get('Authorization'):
                detail = str(detail).replace(headers['Authorization'].removeprefix('Bearer '), '[redacted]')
            raise HTTPException(422 if response.status_code in {400, 413, 422} else 502,
                                f'{label} could not return a decision. ' + str(detail)[:1000])
        try:
            result = response.json()
            validate_answers(result, body['questions'])
        except (ValueError, TypeError, KeyError, AttributeError) as error:
            raise HTTPException(502, f'{label} returned an invalid decision response.') from error
        return result, (time.monotonic() - started) * 1000

    async def close(self):
        if self.laya_process and self.laya_process.returncode is None:
            saved = self.laya_state
            if not saved or await asyncio.to_thread(decision_processes.process_fingerprint, self.laya_process.pid) != saved['fingerprint']:
                raise HTTPException(503, 'Laya cleanup could not verify process identity. No signal was sent. '
                                    'Inspect its original launcher and .state/laya.log.')
            os.killpg(self.laya_process.pid, signal.SIGTERM)
            try:
                await asyncio.wait_for(self.laya_process.wait(), 10)
            except asyncio.TimeoutError:
                raise HTTPException(503, 'The owned Laya API has not stopped yet. No forced kill was sent. Check .state/laya.log.')
        if self.laya_state:
            await asyncio.to_thread(decision_processes.forget_state, self.root, self.laya_state, family='laya')
            self.laya_state = None
        if self.laya_log:
            self.laya_log.close()
        if self.upstream_process and self.upstream_process.returncode is None:
            self.upstream_process.terminate()
            try:
                await asyncio.wait_for(self.upstream_process.wait(), 30)
            except asyncio.TimeoutError:
                self.upstream_process.kill()
                await self.upstream_process.wait()
        if self.upstream_log:
            self.upstream_log.close()
        if self.process and self.process.returncode is None:
            # Only our recorded child may be signalled; a replaced PID or a
            # borrowed HTTP server never becomes ours through discovery.
            saved = self.process_state
            if not saved or await asyncio.to_thread(decision_processes.process_fingerprint, self.process.pid) != saved['fingerprint']:
                raise HTTPException(503, 'Native CLM cleanup could not verify process identity. No signal was sent. '
                                    'Inspect its original launcher and .state/decisions-mistral.log.')
            os.killpg(self.process.pid, signal.SIGTERM)
            try:
                await asyncio.wait_for(self.process.wait(), 10)
            except asyncio.TimeoutError:
                raise HTTPException(503, 'The owned native CLM API has not stopped yet. No forced kill was sent. '
                                    'Check .state/decisions-mistral.log, then retry.')
        if self.process_state:
            await asyncio.to_thread(decision_processes.forget_state, self.root, self.process_state)
            self.process_state = None
        if self.log:
            self.log.close()
            self.log = None


def validate_answers(result, questions):
    def probability(p):
        if isinstance(p, bool) or not isinstance(p, (int, float)) or not math.isfinite(p) or not 0 <= p <= 1:
            raise ValueError('Invalid probability')
    if not isinstance(result.get('model'), str) or set(result['answers']) != set(questions):
        raise ValueError('Mismatched answers')
    for name, q in questions.items():
        answer = result['answers'][name]
        if answer['type'] != q['type']:
            raise ValueError('Mismatched answer type')
        if q['type'] == 'noul':
            probability(answer['noul'])
        else:
            probabilities = answer['probabilities']
            expected = set(q['criteria']) if q['type'] == 'choice' else {str(i) for i in range(len(q['criteria']))}
            if set(probabilities) != expected:
                raise ValueError('Mismatched options')
            for p in probabilities.values():
                probability(p)
            if abs(sum(probabilities.values()) - 1) > .01:
                raise ValueError('Invalid distribution')
            probability(answer['confidence'])
            if q['type'] == 'choice' and answer['choice'] not in expected:
                raise ValueError('Unknown choice')
            if q['type'] == 'score' and (not math.isfinite(answer['score']) or not 0 <= answer['score'] <= len(expected) - 1):
                raise ValueError('Invalid score')


def register_decisions(app, ui_page, root, runtime=None):
    runtime = runtime or DecisionRuntime(root)
    app.state.decisions = runtime

    @app.get('/decisions')
    def decisions_page():
        return ui_page('decisions.html')

    @app.get('/api/decisions/models')
    def models():
        options = [{'name': 'contrastive', 'label': 'CLM (Mistral)', 'description': 'Runs locally through Mistral.'}]
        if jev_key(root):
            options.append({'name': 'jev', 'label': 'Jev', 'description': 'Sends this request to TypeSafe over the web.'})
        return JSONResponse({'models': options}, headers={'Cache-Control': 'no-store'})

    @app.post('/api/decisions/systemone')
    async def decide(body: DecisionInput):
        result, latency = await runtime.decide(body.model_dump(exclude_none=True))
        return JSONResponse(result, headers={'X-Decision-Latency-Ms': f'{latency:.2f}'})

    @app.post('/api/decisions/rank')
    async def rank(body: RankInput):
        wire = {'model': body.model, 'state': body.context, 'questions': {'ranking': {
            'type': 'choice', 'instructions': body.question,
            'criteria': {str(i): candidate for i, candidate in enumerate(body.answers)}}}}
        result, latency = await runtime.decide(wire)
        probabilities = result['answers']['ranking']['probabilities']
        order = sorted(range(len(body.answers)), key=lambda i: -probabilities[str(i)])
        return JSONResponse({'model': result['model'], 'usage': result.get('usage', {}), 'ranked': [
            {'rank': position + 1, 'candidate': body.answers[i], 'prob': probabilities[str(i)]}
            for position, i in enumerate(order)]}, headers={'X-Decision-Latency-Ms': f'{latency:.2f}'})
