"""Durable watermark agents and blind attribution, separate from paired chat."""
import asyncio
import copy
from harness.generation_models import generation_backend
import hashlib
import hmac
import json
import math
from pathlib import Path
import secrets
import uuid

from paired_chat import now
from result_index import write_json
from harbor_exports import harbor_url
from watermarks import BY_ID
from watermark_scoring import key_evidence, SCORING_VERSION, MATCH_P_VALUE, MIN_TOKENS


def attribution(candidates, evidence):
    if len(candidates) != len(evidence):
        raise ValueError("The Mistral detector returned an incomplete candidate set.")
    ranking = []
    for agent, stats in zip(candidates, evidence):
        ranking.append({"agent_id": agent["id"], "name": agent["name"], "stats": stats,
                        **key_evidence(agent["watermark"], stats)})
    ranking.sort(key=lambda row: (row["p_value"] if row["p_value"] is not None else math.inf,
                                  -(row["strength"] if row["strength"] is not None else -math.inf)))
    valid = [row for row in ranking if row["strength"] is not None]
    best = valid[0] if valid else None
    margin = best["strength"] - valid[1]["strength"] if len(valid) > 1 else None
    matches = [row for row in ranking if row["matches"]]
    winner = matches[0] if len(matches) == 1 else None
    selected = winner or best
    reason = ("One known key passed its independent detection test." if winner else
              "Multiple known keys passed; this response cannot be assigned to just one agent." if matches else
              best["method"] if best and best["confidence"] is None else
              f"Only {best['tokens_scored']} response tokens were scored; at least {MIN_TOKENS} are required for a match." if best and best["tokens_scored"] < MIN_TOKENS else
              "No key passed the detection threshold. More response text may help." if best else
              "No usable watermark evidence was returned.")
    return {"guess": winner["name"] if winner else None,
            "best_match": best["name"] if best else None,
            "confidence": selected["confidence"] if selected else None, "p_value": selected["p_value"] if selected else None,
            "confidence_kind": "independent key evidence (1 − p), not a probability of authorship",
            "verdict": "match" if winner else "ambiguous" if matches else "inconclusive",
            "reason": reason, "margin": margin, "ranking": ranking, "scoring_version": SCORING_VERSION,
            "match_p_value": MATCH_P_VALUE, "minimum_tokens": MIN_TOKENS,
            "note": "Each key is tested independently, even with one agent. Key confidence is 1 − p: evidence against an unrelated-key null model, not a probability of authorship. A match requires p ≤ 0.001 and at least 20 scored response tokens. Only the response and anonymous watermark settings reach Mistral."}


class WatermarkExperiments:
    def __init__(self, directory, profiles, runtime, configuration_lock):
        self.directory = Path(directory)
        self.profiles = profiles
        self.runtime = runtime
        self.configuration_lock = configuration_lock
        self.experiments = {}
        self.tasks = {}
        self.on_save = None

    def path(self, experiment_id):
        if len(experiment_id) != 32 or any(c not in "0123456789abcdef" for c in experiment_id):
            raise ValueError("Invalid watermark experiment ID.")
        return self.directory / experiment_id / "experiment.json"

    def get(self, experiment_id):
        if experiment_id not in self.experiments:
            self.experiments[experiment_id] = json.loads(self.path(experiment_id).read_text())
        return self.experiments[experiment_id]

    def save(self, experiment):
        experiment["updated_at"] = now()
        write_json(self.path(experiment["id"]), experiment)
        if self.on_save:
            self.on_save(experiment)

    def list(self):
        return sorted((self.get(p.parent.name) for p in self.directory.glob("*/experiment.json")),
                      key=lambda e: e["created_at"], reverse=True)

    def public(self, experiment):
        data = copy.deepcopy(experiment)
        data["harbor_url"] = harbor_url("wm", experiment)
        for agent in data["agents"]:
            agent.pop("watermark", None)
            agent["model"].pop("watermark", None)
        return data

    def create(self, scheme):
        if scheme not in BY_ID:
            raise ValueError("Select a supported watermark scheme.")
        experiment = {"id": uuid.uuid4().hex, "scheme": scheme, "title": BY_ID[scheme]["name"] + " experiment",
                      "created_at": now(), "agents": [], "detections": []}
        self.experiments[experiment["id"]] = experiment
        self.save(experiment)
        return self.public(experiment)

    async def add(self, experiment_id, model_id, name, prompt, request_id, capture_trace=False):
        async with self.configuration_lock:
            experiment = self.get(experiment_id)
            name, prompt = name.strip(), prompt.strip()
            if not name or len(name) > 80 or any(ord(c) < 32 for c in name):
                raise ValueError("Enter an agent name of 1–80 characters without line breaks.")
            if not prompt or len(prompt) > 24000:
                raise ValueError("Enter a prompt of 1–24,000 characters.")
            existing = next((a for a in experiment["agents"] if a["id"] == request_id), None)
            if existing:
                if (existing["model_id"], existing["name"], existing["prompt"], existing.get("capture_trace", False)) != (model_id, name, prompt, capture_trace):
                    raise ValueError("That request ID is already used for a different agent.")
                return self.public(experiment)
            if any(a["name"].casefold() == name.casefold() for a in experiment["agents"]):
                raise ValueError("Choose a unique name for each agent in this experiment.")
            model = self.profiles().get(model_id)
            if not model or model.get("watermark", {}).get("scheme") != experiment["scheme"]:
                raise ValueError("Select a model configured with this experiment’s watermark scheme.")
            watermark = copy.deepcopy(model["watermark"])
            # Independent of the agent's name, prompt, sampling seed, and response.
            watermark["key"] = hmac.new(bytes.fromhex(watermark["key"]), secrets.token_bytes(32), hashlib.sha256).hexdigest()
            agent = {"id": request_id, "name": name, "prompt": prompt, "model_id": model_id,
                     "model": copy.deepcopy(model), "watermark": watermark, "answer": "", "status": "queued",
                     "capture_trace": capture_trace, "created_at": now()}
            experiment["agents"].append(agent)
            self.save(experiment)
            self.tasks[(experiment_id, "generate", request_id)] = asyncio.create_task(self.generate(experiment, agent))
            return self.public(experiment)

    async def generate(self, experiment, agent):
        try:
            agent["status"] = "running"
            agent["started_at"] = now()
            self.save(experiment)
            options = {"capture_trace": True} if agent.get("capture_trace") else {}
            result = await self.runtime.generate(agent["model"], agent["watermark"], agent["prompt"], **options)
            agent.update(result, status="complete")
        except asyncio.CancelledError:
            agent.update(status="interrupted", error="Generation interrupted. Retry to generate a new answer.")
            raise
        except Exception as error:
            agent.update(status="error", error=str(error) or "Local generation timed out. Check Mistral and retry.")
        finally:
            agent["finished_at"] = now()
            self.save(experiment)

    def retry(self, experiment_id, agent_id):
        experiment = self.get(experiment_id)
        agent = next((a for a in experiment["agents"] if a["id"] == agent_id), None)
        if not agent or agent["status"] not in {"error", "interrupted"}:
            raise ValueError("Only failed or interrupted agents can be retried.")
        agent.update(status="queued", answer="")
        agent.pop("error", None)
        agent.pop("started_at", None)
        agent.pop("finished_at", None)
        self.save(experiment)
        self.tasks[(experiment_id, "generate", agent_id)] = asyncio.create_task(self.generate(experiment, agent))
        return self.public(experiment)

    def illustrate(self, experiment_id, agent_id, request_id):
        """Capture a new, short sample without replacing an existing response."""
        experiment = self.get(experiment_id)
        agent = next((a for a in experiment["agents"] if a["id"] == agent_id), None)
        if not agent or agent["status"] != "complete":
            raise ValueError("Wait for this agent's answer before capturing a sample.")
        existing = agent.get("illustration", {})
        if existing.get("id") == request_id:
            return self.public(experiment)
        if existing.get("status") in {"queued", "running"}:
            raise ValueError("A traced sample is already being generated for this agent.")
        illustration = {"id": request_id, "status": "queued", "created_at": now()}
        agent["illustration"] = illustration
        self.save(experiment)
        self.tasks[(experiment_id, "illustrate", agent_id)] = asyncio.create_task(self.run_illustration(experiment, agent, illustration))
        return self.public(experiment)

    async def run_illustration(self, experiment, agent, illustration):
        try:
            illustration["status"] = "running"
            illustration["started_at"] = now()
            self.save(experiment)
            result = await self.runtime.generate(agent["model"], agent["watermark"], agent["prompt"],
                                                 capture_trace=True, max_tokens=128)
            illustration.update(result, status="complete")
        except asyncio.CancelledError:
            illustration.update(status="interrupted", error="Sample interrupted. Try capturing again.")
            raise
        except Exception as error:
            illustration.update(status="error", error=str(error) or "Sample generation failed. Try again.")
        finally:
            illustration["finished_at"] = now()
            self.save(experiment)

    def detect(self, experiment_id, text, request_id):
        experiment = self.get(experiment_id)
        if not text.strip():
            raise ValueError("There is no response to detect yet.")
        existing = next((d for d in experiment["detections"] if d["id"] == request_id), None)
        if existing:
            if existing["text"] != text:
                raise ValueError("That detector request ID is already used for a different response.")
            return self.public(experiment)
        # Snapshot *all* candidates, then shuffle independently of the submitted
        # text. No lookup of its author is performed anywhere in this path.
        candidates = [{**{k: copy.deepcopy(a[k]) for k in ("id", "name", "watermark")},
                       "backend": generation_backend(a["model"]).family} for a in experiment["agents"]]
        if not candidates:
            raise ValueError("Add an agent before running detection.")
        secrets.SystemRandom().shuffle(candidates)
        detection = {"id": request_id, "text": text, "created_at": now(), "status": "running"}
        experiment["detections"].append(detection)
        self.save(experiment)
        self.tasks[(experiment_id, "detect", request_id)] = asyncio.create_task(self.run_detection(experiment, detection, candidates))
        return self.public(experiment)

    async def run_detection(self, experiment, detection, candidates):
        try:
            # This is the only detector boundary. Neither candidate identity nor
            # the source agent, prompt, profile name or seed crosses it.
            stats = [None] * len(candidates)
            for family in dict.fromkeys(a['backend'] for a in candidates):
                indices = [i for i, a in enumerate(candidates) if a['backend'] == family]
                evidence = await self.runtime.detect(detection['text'], [candidates[i]['watermark'] for i in indices],
                    **({'model': family} if family != 'deepseek' else {}))
                for index, result in zip(indices, evidence, strict=True):
                    stats[index] = result
            detection.update(attribution(candidates, stats), status="complete")
        except asyncio.CancelledError:
            detection.update(status="interrupted", error="Detection interrupted. Send the response again to retry.")
            raise
        except Exception as error:
            detection.update(status="error", error=str(error) or "Mistral detection timed out. Retry with a shorter response.")
        finally:
            detection["finished_at"] = now()
            self.save(experiment)

    def require_idle(self):
        if any(not task.done() for task in self.tasks.values()):
            raise ValueError("Wait for watermark experiments to finish before changing models.")

    async def recover(self):
        for experiment in self.list():
            before = copy.deepcopy(experiment)
            agents = {agent["id"]: agent for agent in experiment["agents"]}
            for detection in experiment["detections"]:
                if detection["status"] == "complete" and detection.get("scoring_version") != SCORING_VERSION:
                    # Preserve the original candidate snapshot, including results
                    # made when only one agent existed. Raw evidence is unchanged.
                    rows = detection.get("ranking", [])
                    if rows and all(row["agent_id"] in agents for row in rows):
                        detection.update(attribution([agents[row["agent_id"]] for row in rows],
                                                     [row["stats"] for row in rows]))
            illustrations = [a["illustration"] for a in experiment["agents"] if a.get("illustration")]
            for entry in [*experiment["agents"], *experiment["detections"], *illustrations]:
                if entry["status"] in {"queued", "running"}:
                    entry.update(status="interrupted", error="Interrupted by a server restart. Retry this operation.")
            if experiment != before:
                self.save(experiment)

    async def close(self):
        for task in self.tasks.values():
            task.cancel()
        await asyncio.gather(*self.tasks.values(), return_exceptions=True)
