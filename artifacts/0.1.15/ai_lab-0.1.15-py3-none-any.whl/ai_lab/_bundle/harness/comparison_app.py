"""Completion, Decoder, Models and Decisions with a shared local lifecycle."""
from contextlib import asynccontextmanager
from typing import Literal
from hashlib import sha256
import json
from pathlib import Path
from urllib.parse import urlencode

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from harbor.cli.view import STATIC_DIR
from harbor.viewer import create_app as harbor_app
import httpx
from pydantic import BaseModel, Field, StrictInt, StrictStr

from common import ROOT, seed_model_name
from model_profiles import ModelProfiles, UNDERLYING_MODEL, UNDERLYING_MODELS, DEFAULT_TEMPERATURE
from result_index import index_jobs, index_record
from watermarks import SCHEMES, validate_watermark
from watermark_experiments import WatermarkExperiments
from detection_lab import register_detection
from decisions import register_decisions


def create_app(root=ROOT, opencode_port=4096, store=None, watermark_runtime=None, decision_runtime=None, decoder_runtime=None):
    root = Path(root).resolve()
    ui_directory = Path(__file__).resolve().parent / "ui"
    revision = sha256(b"".join(path.name.encode() + b"\0" + path.read_bytes()
                              for path in sorted(ui_directory.iterdir())
                              if path.suffix in {".html", ".css", ".js", ".mjs"})).hexdigest()[:12]

    def ui_page(name):
        # Relative module imports inherit this directory, so shell.js and chart
        # dependencies cannot come from a browser's previous design cache.
        html = (ui_directory / name).read_text().replace("/pair-assets/", f"/pair-assets/{revision}/")
        html = html.replace("</head>", f'''<meta name="lab-revision" content="{revision}">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="icon" type="image/png" href="/pair-assets/app/icon-192.png">
<link rel="apple-touch-icon" href="/pair-assets/app/icon-180.png">
<meta name="theme-color" content="#080c10">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="AI Lab">
</head>''')
        return HTMLResponse(html)

    # Legacy result exports are indexed only when explicitly viewed. Opening
    # Completion must not rewrite or resume retired comparison/watermark data.
    jobs_dir = root / '.state/harbor-jobs'
    jobs_dir.mkdir(parents=True, exist_ok=True)
    indexed = {}
    registry = ModelProfiles(root)
    registry.initialize()
    # Kept as a tiny compatibility interface for shared Decoder idle checks.
    # Retired comparison sessions remain on disk; no recovery or remote client.
    class LocalStore:
        async def require_idle(self):
            app.state.ai_lab.idle()
        async def close(self):
            pass
        def list(self):
            return []
    store = store or LocalStore()
    store.profiles = registry.profiles
    from ai_lab.coordination import WorkspaceLock, proxy_private_sessions
    store.configuration_lock = WorkspaceLock(root)
    from ai_lab.web_runtime import WebLifecycle, WebGenerationRuntime, WebDecisionRuntime
    lifecycle = WebLifecycle(root)
    shared_runtime = watermark_runtime or WebGenerationRuntime(lifecycle)
    # An explicit test runtime or validated HTTP fixture never authorizes native
    # startup, including fallback through an otherwise uninjected operation.
    fixture_runtime = getattr(shared_runtime, 'runtime', shared_runtime)
    if (any(runtime is not None for runtime in (watermark_runtime, decision_runtime, decoder_runtime))
            or getattr(fixture_runtime, 'fixture_endpoints', {})):
        lifecycle.allow_start = False
    wm = WatermarkExperiments(root / "sessions/watermarks", registry.profiles,
                              shared_runtime, store.configuration_lock)
    store.on_save = lambda pair: index_record(root, "comparison", pair)
    wm.on_save = lambda experiment: index_record(root, "wm", experiment)

    @asynccontextmanager
    async def lifespan(app):
        try:
            await lifecycle.start()
            yield
        finally:
            try:
                await app.state.ai_lab.close()
                await store.close()
                await wm.close()
                await app.state.decoder_tools.close()
                await app.state.decisions.close()
            finally:
                await lifecycle.close()

    app = FastAPI(title="AI Lab", lifespan=lifespan)
    app.state.web_lifecycle = lifecycle
    app.state.store = store
    app.state.registry = registry
    app.state.watermarks = wm
    app.state.ui_revision = revision

    from ai_lab.service import register as register_ai_lab
    async def lab_idle():
        wm.require_idle()
        await store.require_idle()
    async def lab_publish(profiles):
        registry.save(profiles)
    register_ai_lab(app, root, registry, wm.runtime, store.configuration_lock, lab_idle, lab_publish)
    proxy_private_sessions(app, root)

    @app.middleware("http")
    async def fresh_ui(request: Request, call_next):
        response = await call_next(request)
        if response.headers.get("content-type", "").startswith("text/html"):
            response.headers["Cache-Control"] = "no-store"
            # Harbor's native iframe and the outer site use the same route.
            response.headers.add_vary_header("Sec-Fetch-Dest")
        elif request.url.path.startswith("/pair-assets/"):
            response.headers["Cache-Control"] = "no-cache"
        return response

    @app.middleware("http")
    async def local_writes(request: Request, call_next):
        if request.method not in {"GET", "HEAD", "OPTIONS"}:
            origin = request.headers.get("origin")
            if origin and origin != str(request.base_url).rstrip("/"):
                return JSONResponse({"detail": "Cross-origin request rejected"}, status_code=403)
        return await call_next(request)

    @app.exception_handler(ValueError)
    async def invalid(request, error):
        return JSONResponse({"detail": str(error)}, status_code=409)

    @app.exception_handler(FileNotFoundError)
    async def missing(request, error):
        return JSONResponse({"detail": "Saved conversation not found"}, status_code=404)

    @app.exception_handler(httpx.HTTPError)
    async def unavailable(request, error):
        return JSONResponse({"detail": "The selected model API is unavailable. Retry, or check its setup and local logs. " + str(error)}, status_code=502)

    def experiments():
        return {p.parent.name: p for p in (root / "sessions").glob("*/comparison.json") if p.parent.name != "latest"}

    @app.get("/")
    @app.get("/pair")
    @app.get("/wm")
    def page():
        return RedirectResponse("/completion", status_code=307)

    @app.get("/models")
    def models_page():
        return ui_page("models.html")

    @app.get("/completion")
    def completion_page():
        return ui_page("completion.html")

    @app.get("/manifest.webmanifest", include_in_schema=False)
    def web_app_manifest():
        return FileResponse(ui_directory / "app/manifest.webmanifest",
                            media_type="application/manifest+json", headers={"Cache-Control": "no-cache"})

    @app.get("/service-worker.js", include_in_schema=False)
    def web_app_worker():
        return FileResponse(ui_directory / "service-worker.js", media_type="text/javascript",
                            headers={"Cache-Control": "no-cache", "Service-Worker-Allowed": "/"})

    register_detection(app, ui_page, store, wm, root, registry, decoder_runtime=decoder_runtime or shared_runtime)
    register_decisions(app, ui_page, root, decision_runtime or WebDecisionRuntime(root, lifecycle))

    class CompletionInput(BaseModel):
        model: Literal["DeepSeekR1", "deepseek"] = UNDERLYING_MODEL
        model_config = {"extra": "forbid"}
        prompt: StrictStr = Field(min_length=1, max_length=24000)
        watermark: dict | None = None

    @app.post("/api/completion")
    async def complete_next(body: CompletionInput):
        try:
            watermark = validate_watermark(body.watermark)
        except ValueError as error:
            raise HTTPException(422, str(error)) from error
        # Keep model configuration stable and avoid competing with active runs.
        async with store.configuration_lock:
            wm.require_idle()
            await store.require_idle()
            try:
                return await wm.runtime.complete_next(body.prompt, watermark, **({"model": body.model} if body.model != UNDERLYING_MODEL else {}))
            except (httpx.HTTPError, ValueError, KeyError, TypeError) as error:
                raise HTTPException(502, "Mistral could not return next-token logits. " + str(error)) from error

    app.mount(f"/pair-assets/{revision}", StaticFiles(directory=ui_directory), name="versioned-pair-assets")
    app.mount("/pair-assets", StaticFiles(directory=ui_directory), name="pair-assets")

    @app.get("/api/workspace")
    def workspace():
        return {"kind": "deepseek-comparison", "root": str(root),
                "api_lifetime": "web-process", "supported_models": ["deepseek", "clm"],
                "runtime_mode": "native" if lifecycle.allow_start else "fixture",
                "models": [{"key": key, **profile} for key, profile in registry.supported_profiles().items()],
                "temperature": {"default": DEFAULT_TEMPERATURE, "min": 0, "max": 2, "step": 0.05},
                "experiments": [{"id": name} for name in sorted(experiments(), reverse=True)],
                "pairs": [{k: pair[k] for k in ("id", "title", "created_at", "updated_at")} for pair in store.list()],
                "jobs_url": "/run", "inference_queue": "One local generation at a time"}

    @app.get('/api/generation-backends')
    async def generation_backends():
        from ai_lab.model_servers import available_models
        return [row for row in await available_models(root) if row['name'] == 'deepseek']

    @app.get("/api/models")
    def models():
        return {"models": [{"key": key, **profile} for key, profile in registry.supported_profiles().items()],
                "underlying_models": list(UNDERLYING_MODELS), "watermark_schemes": SCHEMES,
                "watermark_note": "SemStamp requires sentence embeddings and is not supported for text generation."}

    class ModelInput(BaseModel):
        name: str = Field(min_length=1, max_length=80)
        seed: StrictStr | StrictInt | None = None
        underlying_model: str = UNDERLYING_MODEL
        watermark: dict | None = None

    @app.post("/api/models", status_code=201)
    async def add_model(body: ModelInput):
        async with store.configuration_lock:
            key, profiles = registry.added(body.name, body.seed, body.underlying_model, body.watermark)
            wm.require_idle()
            await store.require_idle()
            registry.save(profiles)
            return {"key": key, **profiles[key]}

    @app.delete("/api/models/{key}")
    async def remove_model(key: str):
        async with store.configuration_lock:
            wm.require_idle()
            profiles = registry.removed(key)
            await store.require_idle()
            registry.save(profiles)
            return {"removed": key}

    from ai_lab.service import WatermarkUpdateInput

    @app.patch('/api/models/{key}')
    async def update_watermark(key: str, body: WatermarkUpdateInput):
        async with store.configuration_lock:
            wm.require_idle()
            await store.require_idle()
            profiles = registry.watermarked(key, scheme=body.scheme, watermark_key=body.key, settings=body.settings, underlying_model=body.underlying_model)
            registry.save(profiles)
            return {'key': key, **profiles[key]}

    @app.get("/api/experiments/{name}")
    def experiment(name: str):
        nonlocal indexed
        _, indexed = index_jobs(root)
        path = experiments().get(name)
        if path is None:
            raise HTTPException(404, "Experiment not found")
        report = json.loads(path.read_text())
        for record in report["sessions"]:
            record["model_name"] = seed_model_name(record["seed"], record.get("requested_seed"))
        report["id"] = name
        report["harbor_url"] = "/compare?" + urlencode([
            ("job", job) for job, entry in indexed.items() if entry["experiment"] == name])
        return report

    @app.get("/jobs/{job_path:path}")
    @app.get("/compare")
    @app.get("/run")
    def results_page(request: Request):
        index_jobs(root)
        # Harbor keeps its router, APIs, and assets inside the shared site shell.
        # Explicit embed links also work when browser fetch metadata is absent.
        embedded = request.query_params.get("lab_embed") == "1" or request.headers.get("sec-fetch-dest") == "iframe"
        return FileResponse(STATIC_DIR / "index.html") if embedded else ui_page("results.html")

    # More-specific routes above take precedence. Harbor keeps its native URLs,
    # static assets, jobs matrix, task details, verifier logs, and trace viewer.
    app.mount("/", harbor_app(jobs_dir, mode="jobs", static_dir=STATIC_DIR))
    return app
