"""Two independent, durable OpenCode sessions receiving the same user turns."""
import asyncio
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import time
import uuid

import httpx

from common import ROOT, PROVIDER, seed_profiles
from harness.generation_models import generation_backend
from model_profiles import DEFAULT_TEMPERATURE
from result_index import write_json
from web_viewer import session_url


def now():
    return datetime.now(timezone.utc).isoformat()


def model_id(model):
    # Older recordings used the provider model ID as their storage key.
    return model.get("model_id", model["key"])


def seed_environment(model):
    if model.get("seed") is None:
        return "# Unseeded: use the runtime's default sampling behavior.\n"
    return (f"DEEPSEEK_SEED={model.get('seed_literal', model['seed'])}\n"
            f"DEEPSEEK_EFFECTIVE_SEED={model['seed']}\n")


class OpenCode:
    def __init__(self, port=4096):
        self.port = port

    async def request(self, method, path, body=None):
        auth = None
        if password := os.environ.get("OPENCODE_SERVER_PASSWORD"):
            auth = (os.environ.get("OPENCODE_SERVER_USERNAME", "opencode"), password)
        async with httpx.AsyncClient(base_url=f"http://127.0.0.1:{self.port}", auth=auth,
                                     timeout=30, trust_env=False) as client:
            response = await client.request(method, path, params={"directory": str(ROOT)}, json=body)
            response.raise_for_status()
            return response.json() if response.content else None


class PairStore:
    def __init__(self, directory, client, profiles=seed_profiles, poll_interval=0.75):
        self.directory = Path(directory)
        self.client = client
        self.profiles = profiles
        self.poll_interval = poll_interval
        self.pairs = {}
        self.locks = {}
        self.tasks = {}
        self.configuration_lock = asyncio.Lock()
        self.on_save = None

    async def require_idle(self):
        if any(not task.done() for task in self.tasks.values()):
            raise ValueError("Wait for both replies or stop generation before changing models.")
        statuses = await self.client.request("GET", "/session/status")
        if any(status.get("type") != "idle" for status in statuses.values()):
            raise ValueError("Wait for OpenCode to finish generating before changing models.")

    def path(self, pair_id):
        if len(pair_id) != 32 or any(c not in "0123456789abcdef" for c in pair_id):
            raise ValueError("Invalid comparison ID")
        return self.directory / pair_id

    def get(self, pair_id):
        if pair_id not in self.pairs:
            self.pairs[pair_id] = json.loads((self.path(pair_id) / "pair.json").read_text())
        return self.pairs[pair_id]

    def save(self, pair):
        pair["updated_at"] = now()
        write_json(self.path(pair["id"]) / "pair.json", pair)
        if self.on_save:
            self.on_save(pair)

    def event(self, pair, kind, **data):
        with (self.path(pair["id"]) / "events.jsonl").open("a") as log:
            log.write(json.dumps({"time": now(), "event": kind, **data}, ensure_ascii=False) + "\n")

    def list(self):
        return sorted([self.get(path.parent.name) for path in self.directory.glob("*/pair.json")],
                      key=lambda pair: pair["created_at"], reverse=True)

    async def verify(self, profiles):
        config = await self.client.request("GET", "/config")
        models = config.get("provider", {}).get(PROVIDER, {}).get("models", {})
        options = next((p[1] for p in config.get("plugin", []) if isinstance(p, list)
                        and p[0].endswith("/seeded-profiles.mjs")), {})
        for key, profile in profiles.items():
            backend = generation_backend(profile)
            provider = config.get('provider', {}).get(PROVIDER, {})
            endpoint = (provider.get('options', {}).get('baseURL')
                        or models.get(key, {}).get('provider', {}).get('api'))
            if (models.get(key, {}).get('id') != backend.api_model
                    or endpoint != backend.base_url + '/v1'):
                raise ValueError('OpenCode generation routing differs from the saved profile. Restart OpenCode.')
            seed_options = models.get(key, {}).get("options", {})
            if (key not in models or key not in options.get("seeds", {})
                    or seed_options.get("seed") != profile["seed"]
                    or (profile["seed"] is None and "seed" in seed_options)
                    or options["seeds"][key] != profile["seed"]):
                raise ValueError("The saved seed differs from OpenCode's active configuration. Start a new comparison, or restart OpenCode after configuring the seed files.")
            if (models.get(key, {}).get("options", {}).get("watermark") != profile.get("watermark")
                    or options.get("watermarks", {}).get(key) != profile.get("watermark")):
                raise ValueError("The saved watermark differs from OpenCode's active configuration. Start a new comparison.")
        return config

    async def create(self, selected_models=None):
        async with self.configuration_lock:
            return await self._create(selected_models)

    async def _create(self, selected_models):
        profiles = self.profiles()
        selected_models = (list(profiles)[:2] if len(profiles) > 1 else list(profiles) * 2) if selected_models is None else selected_models
        if len(selected_models) != 2 or any(key not in profiles for key in selected_models):
            raise ValueError("Select a configured model for both Model A and Model B.")
        config = await self.verify({key: profiles[key] for key in selected_models})
        pair = {"id": uuid.uuid4().hex, "created_at": now(), "title": "New comparison",
                "models": [], "turns": []}
        self.path(pair["id"]).mkdir(parents=True)
        self.pairs[pair["id"]] = pair
        self.save(pair)
        write_json(self.path(pair["id"]) / "opencode-config.json", config)
        for source, name in ((ROOT / "sources.json", "sources.json"),
                             (ROOT / ".state/mistral-server.json", "runtime.json"),
                             (ROOT / "harness/seeded-profiles.mjs", "seeded-profiles.mjs")):
            if source.exists():
                shutil.copy2(source, self.path(pair["id"]) / name)
        try:
            for position, selected in enumerate(selected_models):
                key = "model-a" if position == 0 else "model-b"
                label = "Model A" if position == 0 else "Model B"
                profile = profiles[selected]
                session = await self.client.request("POST", "/session", {
                    "title": f"{label} | {profile['name']} | Comparison {pair['id'][:8]}", "agent": "seeded",
                    "model": {"providerID": PROVIDER, "id": selected},
                    "permission": [{"permission": "*", "pattern": "*", "action": "deny"}],
                })
                lane = {**profile, "key": key, "model_id": selected, "session_id": session["id"], "session": session,
                        "url": session_url(self.client.port, ROOT, session["id"])}
                pair["models"].append(lane)
                folder = self.path(pair["id"]) / key
                folder.mkdir()
                (folder / "session.env").write_text(
                    f"# Sampling settings for {profile['name']}\n" + seed_environment(profile))
                write_json(folder / "session.json", {"info": session, "messages": []})
                self.save(pair)
        except Exception as error:
            pair["error"] = str(error)
            self.save(pair)
            raise
        self.event(pair, "created", session_ids=[m["session_id"] for m in pair["models"]])
        return pair

    async def send(self, pair_id, prompt, request_id, temperature=DEFAULT_TEMPERATURE):
        async with self.configuration_lock:
            return await self._send(pair_id, prompt, request_id, temperature)

    async def _send(self, pair_id, prompt, request_id, temperature):
        if (isinstance(temperature, bool) or not isinstance(temperature, (int, float))
                or not math.isfinite(temperature) or not 0 <= temperature <= 2
                or abs(temperature - round(temperature, 2)) > 1e-9):
            raise ValueError("Choose a temperature between 0 and 2, with at most two decimal places.")
        temperature = round(temperature, 2)
        if not prompt.strip():
            raise ValueError("Enter a prompt for both models.")
        if len(prompt) > 24000:
            raise ValueError("The prompt is too long for this local model. Shorten it and try again.")
        async with self.locks.setdefault(pair_id, asyncio.Lock()):
            pair = self.get(pair_id)
            if len(pair["models"]) != 2:
                raise ValueError("This comparison could not initialize both sessions. Start a new comparison.")
            existing = next((t for t in pair["turns"] if t["id"] == request_id), None)
            if existing:
                if existing["prompt"] != prompt:
                    raise ValueError("This request ID was already used for a different prompt.")
                if existing.get("temperature", DEFAULT_TEMPERATURE) != temperature:
                    raise ValueError("This request ID was already used with a different temperature.")
                return pair
            if pair["turns"] and any(r["status"] in {"queued", "running"} for r in pair["turns"][-1]["responses"]):
                raise ValueError("Wait for both replies, or stop generation before sending another turn.")
            if pair["turns"] and any(r["status"] != "complete" for r in pair["turns"][-1]["responses"]):
                raise ValueError("The previous turn was incomplete. Start a new comparison to keep the two histories aligned.")
            profiles = self.profiles()
            if any(model_id(m) not in profiles for m in pair["models"]):
                raise ValueError("A model in this saved comparison was removed. Start a new comparison to continue.")
            config = await self.verify({model_id(m): m for m in pair["models"]})
            plugin = next((p[1] for p in config.get("plugin", []) if isinstance(p, list)
                           and p[0].endswith("/seeded-profiles.mjs")), {})
            if plugin.get("sampling_version") != 2:
                raise ValueError("Refresh the OpenCode configuration before using temperature controls.")
            for lane, model in enumerate(pair["models"]):
                messages = await self.client.request("GET", f"/session/{model['session_id']}/message")
                expected = [t["responses"][lane]["message_id"] for t in pair["turns"]]
                actual = [m["info"]["id"] for m in messages if m["info"]["role"] == "user"]
                if actual != expected:
                    raise ValueError("A conversation was changed separately in OpenCode. Start a new comparison to keep the shared prompts aligned.")
            if not pair["turns"]:
                pair["title"] = prompt.strip()[:90]
            turn = {"id": request_id, "prompt": prompt, "temperature": temperature, "created_at": now(), "responses": []}
            for model in pair["models"]:
                # Match OpenCode's ascending timestamp prefix so user and
                # assistant messages sort in conversation order.
                stamp = (int(time.time() * 1000) * 0x1000) & ((1 << 48) - 1)
                turn["responses"].append({"key": model["key"], "message_id": f"msg_{stamp:012x}" + uuid.uuid4().hex[:14],
                                          "status": "queued", "answer": "", "reasoning": ""})
            pair["turns"].append(turn)
            self.save(pair)
            self.event(pair, "prompt", turn=len(pair["turns"]), request_id=request_id, prompt=prompt, temperature=temperature)
            for lane, model in enumerate(pair["models"]):
                task_key = (pair_id, model["key"])
                self.tasks[task_key] = asyncio.create_task(self.generate(pair, turn, lane))
            return pair

    async def snapshot(self, pair, model):
        messages = await self.client.request("GET", f"/session/{model['session_id']}/message")
        write_json(self.path(pair["id"]) / model["key"] / "session.json",
                   {"info": model["session"], "messages": messages})
        return messages

    async def generate(self, pair, turn, lane, resume=False):
        model, result = pair["models"][lane], turn["responses"][lane]
        folder = self.path(pair["id"]) / model["key"] / f"turn-{pair['turns'].index(turn) + 1:03d}"
        try:
            result.setdefault("started_at", now())
            if not resume:
                payload = {"messageID": result["message_id"], "agent": "seeded",
                           "model": {"providerID": PROVIDER, "modelID": model_id(model)},
                           "variant": f"temperature-{turn.get('temperature', DEFAULT_TEMPERATURE):.2f}",
                           "parts": [{"type": "text", "text": turn["prompt"]}]}
                write_json(folder / "request.json", payload)
                (folder / "sampling.env").write_text(
                    seed_environment(model) +
                    f"DEEPSEEK_TEMPERATURE={turn.get('temperature', DEFAULT_TEMPERATURE)}\n")
                await self.client.request("POST", f"/session/{model['session_id']}/prompt_async", payload)
                self.event(pair, "submitted", lane=model["key"], model=model["name"], message_id=result["message_id"])
            deadline = time.monotonic() + 1200
            while time.monotonic() < deadline:
                messages = await self.snapshot(pair, model)
                answers = [m for m in messages if m["info"].get("parentID") == result["message_id"]
                           and m["info"]["role"] == "assistant"]
                if answers:
                    message = answers[-1]
                    result["answer"] = "\n".join(p["text"] for p in message["parts"] if p["type"] == "text")
                    result["reasoning"] = "\n".join(p["text"] for p in message["parts"] if p["type"] == "reasoning")
                    if result["answer"] or result["reasoning"]:
                        result["status"] = "running"
                    write_json(folder / "response.json", message)
                    if error := message["info"].get("error"):
                        raise RuntimeError(json.dumps(error, ensure_ascii=False))
                    if message["info"].get("time", {}).get("completed"):
                        result["status"] = "complete"
                        result["finished_at"] = now()
                        result["finish"] = message["info"].get("finish")
                        result["tokens"] = message["info"].get("tokens", {})
                        for field in ("answer", "reasoning"):
                            result[field + "_sha256"] = hashlib.sha256(result[field].encode()).hexdigest()
                            (folder / (field + ".txt")).write_text(result[field])
                        self.event(pair, "completed", lane=model["key"], model=model["name"], message_id=result["message_id"])
                        self.save(pair)
                        return
                if resume:
                    statuses = await self.client.request("GET", "/session/status")
                    if model["session_id"] not in statuses:
                        raise RuntimeError("Generation was interrupted before OpenCode recorded a reply. Start a new comparison.")
                self.save(pair)
                await asyncio.sleep(self.poll_interval)
            await self.client.request("POST", f"/session/{model['session_id']}/abort")
            raise RuntimeError("Generation exceeded 20 minutes and was stopped.")
        except asyncio.CancelledError:
            raise
        except Exception as error:
            result["status"], result["error"] = "error", str(error)
            result["finished_at"] = now()
            self.event(pair, "error", lane=model["key"], model=model["name"], error=str(error))
            self.save(pair)

    async def stop(self, pair_id):
        async with self.locks.setdefault(pair_id, asyncio.Lock()):
            pair = self.get(pair_id)
            if not pair["turns"]:
                return pair
            for lane, model in enumerate(pair["models"]):
                result = pair["turns"][-1]["responses"][lane]
                if result["status"] not in {"queued", "running"}:
                    continue
                await self.client.request("POST", f"/session/{model['session_id']}/abort")
                task = self.tasks.get((pair_id, model["key"]))
                if task:
                    task.cancel()
                    await asyncio.gather(task, return_exceptions=True)
                await self.snapshot(pair, model)
                result["status"] = "stopped"
                result["finished_at"] = now()
            self.event(pair, "stopped")
            self.save(pair)
            return pair

    async def recover(self):
        for pair in self.list():
            if not pair["turns"]:
                continue
            turn = pair["turns"][-1]
            for lane, result in enumerate(turn["responses"]):
                if result["status"] in {"queued", "running"}:
                    self.tasks[(pair["id"], result["key"])] = asyncio.create_task(self.generate(pair, turn, lane, resume=True))

    async def close(self):
        for task in self.tasks.values():
            task.cancel()
        await asyncio.gather(*self.tasks.values(), return_exceptions=True)
