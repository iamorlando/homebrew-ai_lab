"""Install and supervise the pinned upstream CLM API and an independent Mac encoder."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request
import venv

REVISION = 'bb42c6c5bf914fd449bed2f6ca65be80602cb1f7'
ARCHIVE_URL = f'https://codeload.github.com/Contrastive-LM/CLM/tar.gz/{REVISION}'
ARCHIVE_SHA256 = 'ddf5318c86095705c670455d46bcb6e31424f84b667ffc5746e0f71d41a3051f'
DEPENDENCIES = ['torch==2.9.1', 'transformers==4.57.3', 'numpy==2.2.6',
                'fastapi==0.141.1', 'uvicorn==0.54.0', 'requests==2.32.5']


def installation(root):
    return Path(root) / '.runtime/decisions/upstream'


def installed(root):
    target = installation(root)
    try:
        manifest = json.loads((target / 'manifest.json').read_text())
        return (manifest.get('revision') == REVISION
                and manifest.get('dependencies') == DEPENDENCIES
                and (target / '.venv/bin/python').is_file()
                and (target / 'source/src/clm/server.py').is_file())
    except (OSError, ValueError):
        return False


def setup(root):
    from ai_lab.download_ui import copy_download, phase, run_dependency
    if installed(root):
        return
    target = installation(root)
    target.mkdir(parents=True, exist_ok=True)
    source = target / 'source'
    if not source.is_dir():
        with tempfile.TemporaryDirectory(dir=target) as temporary:
            temporary = Path(temporary)
            archive = temporary / 'source.tar.gz'
            with urllib.request.urlopen(ARCHIVE_URL, timeout=60) as response, archive.open('wb') as out:
                copy_download(response, out, 'Upstream CLM server')
            phase('Verifying the upstream CLM server')
            if hashlib.sha256(archive.read_bytes()).hexdigest() != ARCHIVE_SHA256:
                raise ValueError('Pinned CLM source archive checksum mismatch.')
            with tarfile.open(archive) as bundle:
                bundle.extractall(temporary, filter='data')
            (temporary / f'CLM-{REVISION}').replace(source)
    uv = root / '.runtime/bin/uv'
    if not uv.is_file():
        uv = Path(shutil.which('uv') or '/nonexistent/uv')
    env = os.environ.copy()
    env['UV_CACHE_DIR'] = str(root / '.runtime/uv-cache')
    python = target / '.venv/bin/python'
    if not python.is_file():
        if uv.is_file():
            run_dependency([str(uv), 'venv', '--python', sys.executable, str(target / '.venv')],
                           root, 'Preparing the CLM environment', env=env)
        else:
            venv.EnvBuilder(with_pip=True).create(target / '.venv')
    installer = [str(uv), 'pip', 'install', '--python', str(python)] if uv.is_file() else [str(python), '-m', 'pip', 'install']
    run_dependency([*installer, *DEPENDENCIES], root, 'Installing CLM dependencies', env=env)
    # vLLM requires Linux/CUDA. The upstream API and heads use only these serving
    # dependencies; the separate Transformers encoder below supplies its HTTP API.
    run_dependency([*installer, '--no-deps', '--editable', str(source)], root,
                   'Installing the upstream CLM server', env=env)
    manifest = {'repository': 'https://github.com/Contrastive-LM/CLM', 'revision': REVISION,
                'archive_sha256': ARCHIVE_SHA256, 'dependencies': DEPENDENCIES,
                'encoder_backend': 'Transformers / PyTorch MPS', 'encoder_pooling': 'last-token',
                'encoder_path': str(root / '.models/clm-v0.1-8b/Qwen/Qwen3-8B'),
                'checkpoint_path': str(root / '.models/clm-v0.1-8b/CLM_v0.1-8B.pt')}
    (target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    phase('Upstream CLM server ready')


def serve(root, port=8700, encoder_port=8090):
    if not installed(root):
        raise ValueError('Run harness/clm_upstream.py setup before starting upstream CLM.')
    target = installation(root)
    python = target / '.venv/bin/python'
    encoder = root / '.models/clm-v0.1-8b/Qwen/Qwen3-8B'
    checkpoint = root / '.models/clm-v0.1-8b/CLM_v0.1-8B.pt'
    if not (encoder / 'config.json').is_file() or not checkpoint.is_file():
        raise ValueError('Upstream CLM needs the local Qwen3-8B files and CLM_v0.1-8B.pt checkpoint.')
    env = os.environ.copy()
    for key in ('TYPESAFE_API_KEY', 'JEV_API_KEY', 'CLM_API_KEY'):
        env.pop(key, None)
    env.update(HF_HOME=str(root / '.runtime/huggingface'), HF_HUB_OFFLINE='1',
               HF_HUB_DISABLE_TELEMETRY='1', TOKENIZERS_PARALLELISM='false')
    state = root / '.state'
    state.mkdir(parents=True, exist_ok=True)
    children = []
    encoder_log = (state / 'clm-upstream-encoder.log').open('a')

    def stop(_signum, _frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, stop)
    try:
        # Each listener belongs to this supervisor; never reuse another encoder.
        import socket
        for number in (port, encoder_port):
            with socket.socket() as listener:
                listener.bind(('127.0.0.1', number))
        process = subprocess.Popen([str(python), str(Path(__file__).with_name('clm_encoder.py')),
                                    '--model', str(encoder), '--port', str(encoder_port)],
                                   cwd=root, env=env, stdin=subprocess.DEVNULL,
                                   stdout=encoder_log, stderr=subprocess.STDOUT)
        children.append(process)
        deadline = time.monotonic() + 600
        while True:
            if process.poll() is not None:
                raise ValueError(f'Independent Qwen encoder exited; see {state / "clm-upstream-encoder.log"}.')
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{encoder_port}/v1/models', timeout=2) as response:
                    if response.status == 200:
                        break
            except (urllib.error.URLError, TimeoutError):
                pass
            if time.monotonic() >= deadline:
                raise ValueError('Independent Qwen encoder took too long to load.')
            time.sleep(.5)
        process = subprocess.Popen([str(python), '-m', 'clm.server', '--host', '127.0.0.1',
                                    '--port', str(port), '--emb-url', f'http://127.0.0.1:{encoder_port}/v1/embeddings',
                                    '--ckpt', str(checkpoint), '--device', 'cpu', '--action-cache', '0',
                                    '--no-download'], cwd=root, env=env, stdin=subprocess.DEVNULL)
        children.append(process)
        while all(child.poll() is None for child in children):
            time.sleep(.5)
        raise ValueError('An upstream CLM server process exited; check the upstream API and encoder logs.')
    except KeyboardInterrupt:
        return
    finally:
        for child in reversed(children):
            if child.poll() is None:
                child.terminate()
        for child in reversed(children):
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
        encoder_log.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['setup', 'serve'])
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--port', type=int, default=8700)
    parser.add_argument('--encoder-port', type=int, default=8090)
    args = parser.parse_args()
    root = args.root.resolve()
    if args.command == 'setup':
        setup(root)
    else:
        serve(root, args.port, args.encoder_port)


if __name__ == '__main__':
    main()
