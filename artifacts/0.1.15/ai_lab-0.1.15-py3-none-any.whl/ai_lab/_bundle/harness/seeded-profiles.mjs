const SYSTEM = "You are a helpful assistant. Follow the user's instructions. Do not use tools.";

export default async (_context, { provider, seeds, watermarks = {} }) => {
  const selectedSeed = (model) => {
    if (model.providerID !== provider) return undefined;
    if (!Object.hasOwn(seeds, model.id)) {
      throw new Error("Choose one of the named model profiles before sending a message.");
    }
    const seed = seeds[model.id];
    // null explicitly declares an unseeded profile; undefined is not a profile.
    if (seed !== null && (!Number.isSafeInteger(seed) || seed < 0)) {
      throw new Error("This model profile has an invalid sampling seed.");
    }
    return seed;
  };

  return {
    "chat.params": async ({ model, message }, output) => {
      const seed = selectedSeed(model);
      if (seed === undefined) return;
      const variant = message?.model?.variant;
      const match = variant?.match(/^temperature-(\d+(?:\.\d+)?)$/);
      const temperature = variant === undefined ? 0.6 : match ? Number(match[1]) : NaN;
      if (!Number.isFinite(temperature) || temperature < 0 || temperature > 2) {
        throw new Error("Temperature must be between 0 and 2.");
      }
      output.temperature = temperature;
      output.topP = 0.95;
      output.topK = undefined;
      output.maxOutputTokens = 4096;
      if (seed === null) delete output.options.seed;
      else output.options.seed = seed;
      if (watermarks[model.id]) {
        output.options.watermark = structuredClone(watermarks[model.id]);
        output.options.top_k = 40;
      } else {
        delete output.options.watermark;
        delete output.options.top_k;
      }
      delete output.options.reasoningEffort;
      delete output.options.reasoning_effort;
    },
    "experimental.chat.system.transform": async ({ model }, output) => {
      if (selectedSeed(model) === undefined) return;
      output.system.splice(0, output.system.length, SYSTEM);
    },
    // OpenCode supplies only this session's messages. Preserve the complete
    // conversation for follow-ups; never retain or combine histories here.
  };
};
