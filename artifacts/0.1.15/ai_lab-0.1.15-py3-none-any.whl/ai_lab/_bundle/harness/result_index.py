"""Index native Harbor jobs and saved interactive experiments for its viewer."""
import hashlib
import json
from pathlib import Path
import shutil
from threading import RLock

from common import ROOT, seed_model_name
from harbor_exports import EXPORT_VERSION, job_name, project_record

_index_lock = RLock()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temporary.replace(path)


def _record_entry(root, destination, previous, kind, record):
    name = job_name(kind, record)
    source = root / 'sessions' / ('watermarks' if kind == 'wm' else 'paired') / record['id']
    fingerprint = hashlib.sha256(json.dumps([EXPORT_VERSION, record], sort_keys=True).encode()).hexdigest()
    entry = {"source": str(source), "experiment": record['id'], "kind": kind, "fingerprint": fingerprint}
    target = destination / name
    if entry != previous.get(name) or not target.exists():
        if target.exists() and name not in previous:
            raise RuntimeError(f"Refusing to replace an unrecognized viewer directory: {target}")
        project_record(destination, kind, record, write_json)
    return name, entry


def index_record(root, kind, record):
    """Publish a saved change immediately, including background generation updates."""
    with _index_lock:
        destination = root / '.state/harbor-jobs'
        manifest_path = destination / '.index.json'
        previous = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
        name, entry = _record_entry(root, destination, previous, kind, record)
        previous[name] = entry
        write_json(manifest_path, previous)


def index_jobs(root=ROOT):
    with _index_lock:
        return _index_jobs(root)


def _index_jobs(root):
    destination = root / ".state/harbor-jobs"
    destination.mkdir(parents=True, exist_ok=True)
    manifest_path = destination / ".index.json"
    previous = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    indexed = {}
    for config in sorted((root / "sessions").glob("*/seed-*/jobs/*/config.json")):
        if "latest" in config.relative_to(root / "sessions").parts:
            continue
        job = config.parent
        experiment = job.parents[2]
        seed = int(job.parent.parent.name.removeprefix("seed-"))
        name = f"{experiment.name}--{seed_model_name(seed)}"
        files = [(str(p.relative_to(job)), p.stat().st_size, p.stat().st_mtime_ns)
                 for p in sorted(job.rglob("*")) if p.is_file()]
        fingerprint = hashlib.sha256(json.dumps(files).encode()).hexdigest()
        entry = {"source": str(job), "experiment": experiment.name, "fingerprint": fingerprint}
        target = destination / name
        if entry != previous.get(name) or not target.exists():
            if target.exists():
                if name not in previous:
                    raise RuntimeError(f"Refusing to replace an unrecognized viewer directory: {target}")
                shutil.rmtree(target)
            # Harbor validates that files resolve inside its jobs root. Copies
            # satisfy this and isolate the original recordings from viewer edits.
            shutil.copytree(job, target, symlinks=True)
        indexed[name] = entry
    for kind, pattern in (("comparison", "paired/*/pair.json"), ("wm", "watermarks/*/experiment.json")):
        for path in sorted((root / "sessions").glob(pattern)):
            name, entry = _record_entry(root, destination, previous, kind, json.loads(path.read_text()))
            indexed[name] = entry
    for name in previous.keys() - indexed.keys():
        target = destination / name
        if target.is_dir() and target.parent == destination and Path(name).name == name:
            shutil.rmtree(target)
    write_json(manifest_path, indexed)
    return destination, indexed
