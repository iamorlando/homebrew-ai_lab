"""Identify an existing local OpenCode viewer before trying to bind its port."""
import base64
import http.client
import json
import os
import socket
import subprocess
import time
import webbrowser
from urllib.parse import urlencode

from common import PROVIDER, seed_profiles


def session_url(port, directory, session_id):
    encoded = base64.urlsafe_b64encode(str(directory).encode()).decode().rstrip("=")
    return f"http://127.0.0.1:{port}/{encoded}/session/{session_id}"


def serve_viewer(command, env, port, directory, session_ids, url, open_browser=True):
    # `serve` and `web` expose the same UI. `web` opens the empty home route;
    # launch `serve` and open the selected conversation after it becomes ready.
    process = subprocess.Popen(command, cwd=directory, env=env)
    try:
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError(f"OpenCode exited during startup (status {process.returncode})")
            try:
                ready = existing_viewer(port, directory, session_ids)
            except RuntimeError:
                ready = False
            if ready:
                print(f"Saved session: {url}", flush=True)
                if open_browser:
                    webbrowser.open(url)
                return process.wait()
            time.sleep(0.2)
        raise RuntimeError("OpenCode did not become ready within 30 seconds")
    except KeyboardInterrupt:
        return 130
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()


def existing_viewer(port, directory, session_ids, requested_seed=None):
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=2):
            pass
    except ConnectionRefusedError:
        return False
    except OSError as error:
        raise RuntimeError(f"Cannot check local port {port}: {error}") from error

    occupied = f"Port {port} is already in use. Choose another port with --port, for example --port 4097."
    headers = {}
    if password := os.environ.get("OPENCODE_SERVER_PASSWORD"):
        user = os.environ.get("OPENCODE_SERVER_USERNAME", "opencode")
        credentials = base64.b64encode(f"{user}:{password}".encode()).decode()
        headers["Authorization"] = f"Basic {credentials}"

    def get(path):
        connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        try:
            connection.request("GET", path, headers=headers)
            response = connection.getresponse()
            if response.status != 200:
                raise ValueError(f"HTTP {response.status}")
            return json.loads(response.read())
        finally:
            connection.close()

    try:
        health = get("/global/health")
        if not isinstance(health, dict) or health.get("healthy") is not True or not health.get("version"):
            raise ValueError("Not a healthy OpenCode server")
        query = urlencode({"directory": str(directory), "limit": 1000})
        sessions = get("/session?" + query)
        if not isinstance(sessions, list):
            raise ValueError("Unexpected session response")
        available = {session.get("id") for session in sessions if isinstance(session, dict)}
        if not session_ids or not session_ids.issubset(available):
            raise ValueError("The running server does not contain the selected experiment's sessions")
        config = get("/config?" + urlencode({"directory": str(directory)}))
        models = config.get("provider", {}).get(PROVIDER, {}).get("models", {})
        if any(models.get(key, {}).get("options", {}).get("seed") != profile["seed"] for key, profile in seed_profiles().items()):
            raise ValueError("The running OpenCode server has older seed profiles. Restart it with ./harness/view-session --web.")
        if requested_seed is not None:
            selected = config.get("model", "").split("/")[-1]
            seed = models.get(selected, {}).get("options", {}).get("seed")
            if seed != requested_seed:
                raise ValueError("The running server has a different sampling seed")
    except (OSError, http.client.HTTPException, ValueError, AttributeError) as error:
        raise RuntimeError(f"{occupied}\n{error}") from error
    return True
