"""Bounded, key-free projection of Mistral's sampling trace HTTP contract."""
import json
from generation_tournament import public_generation_tournament

TRACE_LIMITS = {"max_steps": 24, "max_candidates": 16, "max_layers": 32}


def fields(value, names):
    return {key: value[key] for key in names.split() if key in value}


def public_tournament(source, vocab_size):
    """Keep the native bracket complete, key-free, and distinct from generation."""
    def require(condition):
        if not condition:
            raise ValueError("Mistral returned an invalid teaching tournament.")

    result = fields(source, "origin used_for_generation rng_version effective_seed status requested_rounds configured_depth rounds layer_indices")
    require(result.get("origin") == "teaching_simulation" and result.get("used_for_generation") is False)
    require(isinstance(result.get("effective_seed"), str) and result["effective_seed"].isdigit())
    requested, rounds = result["requested_rounds"], result["rounds"]
    require(type(requested) is int and 1 <= requested <= 4 and requested <= result["configured_depth"])
    result["draws"] = [fields(d, "draw_id token_id text probability") for d in source["draws"]]
    result["matches"] = []
    for m in source["matches"]:
        match = fields(m, "match_id round winner winner_draw_id reason")
        for side in ("left", "right"):
            match[side] = fields(m[side], "draw_id g_value")
            match[side]["source"] = fields(m[side]["source"], "type id")
        result["matches"].append(match)
    result["winner"] = fields(source["winner"], "match_id draw_id token_id") if source.get("winner") else None
    if result["status"] != "demonstrated":
        require(result["status"] in {"warmup", "repeated_context", "greedy"})
        require(rounds == 0 and not result["layer_indices"] and not result["draws"] and not result["matches"] and result["winner"] is None)
        return result
    require(rounds == requested and result["layer_indices"] == list(range(rounds)))
    draws, matches = result["draws"], result["matches"]
    require(len(draws) == 2 ** rounds and len(matches) == len(draws) - 1)
    for i, draw in enumerate(draws):
        require(draw["draw_id"] == i and type(draw["token_id"]) is int and 0 <= draw["token_id"] < vocab_size)
        require(0 < draw["probability"] <= 1 and (draw.get("text") is None or isinstance(draw["text"], str)))
    consumed = set()
    for i, match in enumerate(matches):
        require(match["match_id"] == i and type(match["round"]) is int and 0 <= match["round"] < rounds)
        require(match["winner"] in {"left", "right"})
        for side in ("left", "right"):
            entrant = match[side]
            ref = entrant["source"]
            require(type(entrant["draw_id"]) is int and 0 <= entrant["draw_id"] < len(draws) and entrant["g_value"] in (0, 1))
            require(type(ref["id"]) is int and (ref["type"], ref["id"]) not in consumed)
            consumed.add((ref["type"], ref["id"]))
            if ref["type"] == "draw":
                require(match["round"] == 0 and ref["id"] == entrant["draw_id"])
            else:
                require(ref["type"] == "match" and 0 <= ref["id"] < i)
                parent = matches[ref["id"]]
                require(parent["round"] == match["round"] - 1 and parent["winner_draw_id"] == entrant["draw_id"])
        winner, loser = match[match["winner"]], match["right" if match["winner"] == "left" else "left"]
        require(match["winner_draw_id"] == winner["draw_id"])
        require((match["reason"] == "higher_g" and winner["g_value"] > loser["g_value"]) or
                (match["reason"] == "random_tie" and winner["g_value"] == loser["g_value"]))
    winner = result["winner"]
    require(winner is not None and winner["match_id"] == len(matches) - 1)
    require(matches[-1]["round"] == rounds - 1 and winner["draw_id"] == matches[-1]["winner_draw_id"])
    require(winner["token_id"] == draws[winner["draw_id"]]["token_id"])
    return result


def public_trace(value, limits=TRACE_LIMITS):
    """Keep real values and candidate order; never normalize a displayed subset."""
    if not isinstance(value, dict) or not isinstance(value.get("steps"), list) or not value["steps"]:
        raise ValueError("This response has no sampling trace. Generate a traced sample with the updated Mistral runtime.")
    if len(value["steps"]) > limits["max_steps"]:
        raise ValueError("Mistral returned more trace steps than requested.")
    result = fields(value, "truncated truncation_reason")
    result["steps"] = []
    previous = -1
    for source in value["steps"]:
        step = fields(source, "generated_index context_length attempt selected_token_id selection_rule candidate_count candidates_truncated layers_truncated")
        if step["generated_index"] <= previous:
            raise ValueError("Mistral returned out-of-order trace steps.")
        previous = step["generated_index"]
        candidates = source["candidates"]
        if not 1 <= len(candidates) <= limits["max_candidates"]:
            raise ValueError("Mistral returned an invalid candidate count.")
        ids = [c["token_id"] for c in candidates]
        if len(set(ids)) != len(ids) or step["selected_token_id"] not in ids:
            raise ValueError("Mistral's trace is missing its selected token or repeats a token ID.")
        step["candidates"] = []
        for source_candidate in candidates:
            candidate = fields(source_candidate, "token_id text input_logit processed_logit reporting_probability pre_watermark_probability post_watermark_probability post_watermark_log_probability selection_score selection_score_status inverse_rank cdf_lower cdf_upper")
            if source_candidate.get("membership"):
                candidate["membership"] = fields(source_candidate["membership"], "kind favored")
            step["candidates"].append(candidate)
        watermark = source.get("watermark")
        step["watermark"] = fields(watermark, "scheme status bias_delta payload_position payload_symbol key_position score_kind") if watermark else None
        if watermark and watermark.get("inverse"):
            step["watermark"]["inverse"] = fields(watermark["inverse"], "uniform threshold total_weight")
        layers = source.get("layers", [])
        if len(layers) > limits["max_layers"]:
            raise ValueError("Mistral returned more trace layers than requested.")
        step["layers"] = []
        for source_layer in layers:
            layer = fields(source_layer, "index green_mass input_normalizer g_values input_probabilities probabilities")
            if any(len(layer[key]) != len(candidates) for key in ("g_values", "input_probabilities", "probabilities")):
                raise ValueError("Mistral's layer values do not align with its candidate tokens.")
            step["layers"].append(layer)
        if source.get("teaching_tournament") is not None:
            if not watermark or watermark["scheme"] != "synthid":
                raise ValueError("Only SynthID supports a teaching tournament.")
            step["teaching_tournament"] = public_tournament(source["teaching_tournament"], step["candidate_count"])
        if source.get("generation_tournament") is not None:
            step["generation_tournament"] = public_generation_tournament(
                source["generation_tournament"], step, limits.get("generation_tournament", {}).get("max_matches", 255))
        result["steps"].append(step)
    # Reject invalid JSON numbers instead of converting them to convincing charts.
    if len(json.dumps(result, allow_nan=False).encode()) > 8 * 1024 * 1024:
        raise ValueError("Mistral returned an oversized sampling trace.")
    return result
