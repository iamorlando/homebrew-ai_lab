"""Temporary generation and independent, editable known-key detection."""
from typing import Annotated, Literal
import math
from collections import OrderedDict
from copy import deepcopy
import secrets

import httpx
from fastapi import HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, StrictBool, StrictInt, StrictStr

from watermarks import SCHEMES, VOCAB_SIZE, validate_watermark
from watermark_scoring import MATCH_P_VALUE, MIN_TOKENS, key_evidence


class GenerationInput(BaseModel):
    model_config = {"extra": "forbid"}
    model: Literal["DeepSeekR1", "deepseek"] = "DeepSeekR1"
    prompt: StrictStr = Field(min_length=1, max_length=24000)
    watermark: dict
    max_tokens: StrictInt = Field(default=512, ge=64, le=2048)
    capture_trace: StrictBool = True
    temperature: float = Field(default=1.0, ge=0, le=2, strict=True, allow_inf_nan=False)


class DetectionInput(BaseModel):
    model_config = {"extra": "forbid"}
    model: Literal["DeepSeekR1", "deepseek"] = "DeepSeekR1"
    text: StrictStr = Field(min_length=1, max_length=100000)
    watermark: dict
    prompt_len: StrictInt = Field(default=0, ge=0, le=24000)
    eos_token_ids: list[Annotated[StrictInt, Field(ge=0, lt=VOCAB_SIZE)]] = Field(default_factory=list, max_length=32)
    add_special_tokens: StrictBool = False
    p_value_threshold: float = Field(default=MATCH_P_VALUE, gt=0, le=1, strict=True, allow_inf_nan=False)
    min_tokens: StrictInt = Field(default=MIN_TOKENS, ge=1, le=10000)


class InspectionInput(BaseModel):
    model_config = {"extra": "forbid"}
    model: Literal["DeepSeekR1", "deepseek"] = "DeepSeekR1"
    prompt: StrictStr = Field(min_length=1, max_length=24000)
    prefix: StrictStr = Field(max_length=100000)
    watermark: dict
    temperature: float = Field(default=1.0, ge=0, le=2, strict=True, allow_inf_nan=False)


def assess_detection(watermark, stats, threshold, min_tokens):
    evidence = key_evidence(watermark, stats)
    enough = evidence["tokens_scored"] >= min_tokens
    matches = enough and evidence["p_value"] is not None and evidence["p_value"] <= threshold
    verdict = "match" if matches else "insufficient" if not enough or evidence["p_value"] is None else "no_match"
    return {**evidence, "matches": matches, "verdict": verdict, "stats": stats,
            "scheme": watermark["scheme"], "p_value_threshold": threshold, "min_tokens": min_tokens}


class DecoderGenerationInput(BaseModel):
    model_config = {"extra": "forbid"}
    model: StrictStr = Field(min_length=1, max_length=256)
    prompt: StrictStr = Field(min_length=1, max_length=24000)
    max_tokens: StrictInt = Field(default=512, ge=64, le=2048)
    temperature: float = Field(default=1.0, ge=0, le=2, strict=True, allow_inf_nan=False)


class DecoderInput(BaseModel):
    model_config = {"extra": "forbid"}
    model: StrictStr = Field(min_length=1, max_length=256)
    text: StrictStr = Field(min_length=1, max_length=100000)
    snapshot: StrictStr | None = Field(default=None, min_length=1, max_length=128)
    scheme: Literal["synthid", "kgw", "unigram", "exponential", "inverse_transform", "mpac"] | None = None
    key: StrictStr | None = Field(default=None, pattern=r"^[0-9a-fA-F]{64}$")
    settings: dict | None = None
    prompt_len: StrictInt = Field(default=0, ge=0, le=24000)
    eos_token_ids: list[Annotated[StrictInt, Field(ge=0, lt=VOCAB_SIZE)]] = Field(default_factory=list, max_length=32)
    add_special_tokens: StrictBool = False
    p_value_threshold: float = Field(default=MATCH_P_VALUE, gt=0, le=1, strict=True, allow_inf_nan=False)
    min_tokens: StrictInt = Field(default=MIN_TOKENS, ge=1, le=10000)


def register_detection(app, ui_page, store, wm, root, registry, *, decoder_runtime=None, decoder_tools=None):
    from ai_lab.mcp_tools import LabTools, public
    from harness.generation_models import generation_backend
    # Web supplies its shared lifecycle runtime. Decoder neither creates a model
    # server nor restricts the owner's automatic-start policy.
    tools = decoder_tools if decoder_tools is not None else LabTools(root, watermark_runtime=decoder_runtime)
    tools.registry = registry
    app.state.decoder_tools = tools
    snapshots = OrderedDict()  # private, bounded, process-local generation configs

    class IdleDetector:
        """Idle checks run inside LabTools' workspace lock, never nest locks."""
        def __init__(self, runtime): self.runtime = runtime
        async def require_idle(self):
            try:
                wm.require_idle()
                await store.require_idle()
            except ValueError as error:
                raise HTTPException(409, 'Another operation is running. Retry when it finishes.') from error
            except httpx.HTTPError as error:
                raise HTTPException(503, 'The web session is unavailable. Reload the page and retry.') from error
        async def generate(self, *args, **kwargs):
            await self.require_idle()
            return await self.runtime.generate(*args, **kwargs)
        async def detect(self, *args, **kwargs):
            await self.require_idle()
            return await self.runtime.detect(*args, **kwargs)
    tools.runtime = IdleDetector(tools.runtime)

    def named_profile(model):
        ident, profile = tools.model_profile(model)
        return ident, profile, generation_backend(profile)

    def identity(ident, profile, backend):
        return {'model': profile['name'], 'profile_key': ident, 'modelLabel': backend.label,
                'underlying_model': backend.underlying_model, 'api_model': backend.api_model}

    def runtime_error(error, backend, action):
        if isinstance(error, ValueError) and 'ai-lab setup' in str(error):
            return HTTPException(503, f'The {backend.label} model or runtime needs setup. Run ai-lab setup install {backend.family} --yes, then retry. Existing verified weights are reused.')
        if isinstance(error, ValueError) and ('ai-lab services' in str(error) or 'API is unavailable' in str(error) or 'launch settings' in str(error)):
            return HTTPException(503, f'The {backend.label} API is unavailable. Web starts installed models automatically; retry, or check model setup if it persists.')
        return HTTPException(502, f'The {backend.label} {action} failed or returned unavailable evidence. Retry; web manages the model API automatically.')

    @app.exception_handler(RequestValidationError)
    async def validation_error(request, error):
        if request.url.path.startswith('/api/decoder/'):
            return JSONResponse({'detail': 'Check the model, text, scheme, key and detector options.'}, status_code=422)
        return await request_validation_exception_handler(request, error)

    @app.get('/api/decoder/models')
    async def decoder_models():
        async with tools.lock:
            profiles = []
            for ident, profile in registry.supported_profiles().items():
                backend = generation_backend(profile)
                watermark = public(profile.get('watermark')) or {}
                profiles.append({'id': ident, 'name': profile['name'], 'modelLabel': backend.label,
                    'underlying_model': backend.underlying_model, 'scheme': watermark.get('scheme'),
                    'hasKey': watermark.get('has_key', False),
                    'settings': {key: value for key, value in watermark.items() if key not in {'scheme', 'has_key'}}})
            return {'profiles': profiles, 'schemes': SCHEMES}

    @app.post('/api/decoder/generate')
    async def decoder_generate(body: DecoderGenerationInput):
        if not body.prompt.strip(): raise HTTPException(422, 'Enter a prompt.')
        async with tools.lock:
            try:
                ident, profile, backend = named_profile(body.model)
            except ValueError as error:
                raise HTTPException(422, 'Choose a saved generation model.') from error
            watermark = tools.effective_watermark(profile)
            try:
                result = await tools.runtime.generate(profile, watermark, body.prompt,
                    max_tokens=body.max_tokens, temperature=body.temperature, capture_trace=False)
                if not isinstance(result.get('answer'), str) or not result['answer'].strip():
                    raise ValueError('Empty generation')
            except (httpx.HTTPError, ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
                raise runtime_error(error, backend, 'generation') from error
            token = secrets.token_urlsafe(32)
            snapshots[token] = (ident, deepcopy(profile))
            while len(snapshots) > 32: snapshots.popitem(last=False)
            return {**identity(ident, profile, backend), 'answer': result['answer'],
                    'finish_reason': result.get('finish_reason'), 'snapshot': token,
                    'scheme': (watermark or {}).get('scheme'),
                    'settings': {key: value for key, value in (watermark or {}).items() if key not in {'key', 'scheme'}},
                    'hasKey': bool(watermark and watermark.get('key')),
                    **({'fixture': True} if result.get('fixture') is True else {})}

    @app.post('/api/decoder/detect')
    async def decode(body: DecoderInput):
        if not body.text.strip(): raise HTTPException(422, 'Enter text to decode.')
        async with tools.lock:
            try:
                if body.snapshot:
                    record = snapshots.get(body.snapshot)
                    if record is None:
                        raise HTTPException(422, 'The response settings expired. Generate again or reset to saved model settings.')
                    ident, profile = deepcopy(record)
                    if body.model not in {ident, profile['name']}:
                        raise HTTPException(422, 'The response settings belong to a different model. Reset to saved model settings.')
                    backend = generation_backend(profile)
                else:
                    ident, profile, backend = named_profile(body.model)
                watermark = tools.effective_watermark(profile, body.scheme, body.key, body.settings)
                if not watermark:
                    raise ValueError('Choose a watermarked model, or supply the original scheme and key. No test was run.')
            except ValueError as error:
                # Validation messages are useful, but must not echo explicit keys.
                detail = str(error)
                if body.key: detail = detail.replace(body.key, '[private key]')
                raise HTTPException(422, detail) from error
            try:
                detected = await tools.runtime.detect(body.text, [watermark], model=profile,
                    prompt_len=body.prompt_len, eos_token_ids=body.eos_token_ids,
                    add_special_tokens=body.add_special_tokens)
                stats = detected[0]
                n = stats.get('tokens_scored', stats.get('trials'))
                if type(n) is not int or n < 0: raise ValueError('Invalid scored-token count')
                result = {'confidence_definition': '1 - p_value from a known-key test or conservative bound against unwatermarked text; not a posterior probability of authorship.', **identity(ident, profile, backend), **assess_detection(watermark, stats, body.p_value_threshold, body.min_tokens),
                          **({'fixture': True} if stats.get('fixture') is True else {})}
            except (httpx.HTTPError, ValueError, KeyError, TypeError, AttributeError, IndexError, OverflowError) as error:
                raise runtime_error(error, backend, 'detection') from error
        # Return only statistical evidence and public identity, never a full
        # config or an arbitrary native response containing private fields.
        fields = ('ok', 'model', 'profile_key', 'underlying_model', 'api_model', 'scheme', 'verdict', 'matches',
                  'tokens_scored', 'strength', 'p_value', 'confidence', 'method', 'p_value_threshold', 'min_tokens', 'confidence_definition')
        output = {key: result[key] for key in fields if key in result}
        def numeric(value):
            return type(value) in (int, float) and math.isfinite(value) or isinstance(value, list) and len(value) <= 1024 and all(numeric(item) for item in value)
        native_fields = ('mean_g_value', 'z_score', 'mean_cost', 'green_count', 'green_fraction', 'trials', 'votes')
        output['stats'] = {key: value for key, value in result['stats'].items() if key in native_fields and numeric(value)}
        if result.get('fixture') is True: output['fixture'] = True
        if result['verdict'] == 'insufficient': output.update(confidence=None, p_value=None, matches=False)
        return output

    def config(value):
        try:
            watermark = validate_watermark(value)
            if not watermark:
                raise ValueError("Choose a watermark scheme.")
            return watermark
        except ValueError as error:
            raise HTTPException(422, str(error)) from error

    @app.get("/detection")
    @app.get("/decoder")
    def page():
        return ui_page("detection.html")

    @app.post("/api/detection/generate")
    async def generate(body: GenerationInput):
        watermark = config(body.watermark)
        if not body.prompt.strip():
            raise HTTPException(422, "Enter a prompt.")
        async with store.configuration_lock:
            wm.require_idle()
            await store.require_idle()
            try:
                return await wm.runtime.generate({"underlying_model": body.model} if body.model != "DeepSeekR1" else {}, watermark, body.prompt,
                    capture_trace=body.capture_trace, max_tokens=body.max_tokens, detailed_trace=True,
                    temperature=body.temperature, unfiltered=True)
            except (httpx.HTTPError, ValueError, KeyError, TypeError) as error:
                raise HTTPException(502, "Mistral could not generate a response. " + str(error)) from error

    @app.post("/api/detection/detect")
    async def detect(body: DetectionInput):
        watermark = config(body.watermark)
        if not body.text.strip():
            raise HTTPException(422, "Enter text to detect.")
        async with store.configuration_lock:
            wm.require_idle()
            await store.require_idle()
            try:
                stats = (await wm.runtime.detect(body.text, [watermark], prompt_len=body.prompt_len,
                    eos_token_ids=body.eos_token_ids, add_special_tokens=body.add_special_tokens, **({"model": body.model} if body.model != "DeepSeekR1" else {})))[0]
                return assess_detection(watermark, stats, body.p_value_threshold, body.min_tokens)
            except (httpx.HTTPError, ValueError, KeyError, TypeError, IndexError) as error:
                raise HTTPException(502, "Mistral could not detect this text. " + str(error)) from error

    @app.post("/api/detection/inspect")
    async def inspect(body: InspectionInput):
        watermark = config(body.watermark)
        if not body.prompt.strip():
            raise HTTPException(422, "The response's original prompt is required.")
        async with store.configuration_lock:
            wm.require_idle()
            await store.require_idle()
            try:
                return await wm.runtime.inspect_response(body.prompt, body.prefix, watermark,
                                                         temperature=body.temperature, **({"model": body.model} if body.model != "DeepSeekR1" else {}))
            except (httpx.HTTPError, ValueError, KeyError, TypeError, IndexError, OSError) as error:
                raise HTTPException(502, "Mistral could not inspect this word. " + str(error)) from error
