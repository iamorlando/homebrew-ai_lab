"""Durable named model profiles and publication to the local OpenCode instance."""
import json
from pathlib import Path
import re
import secrets
import uuid
from copy import deepcopy

from common import ROOT, PROVIDER, app_config, load_seed, seed_model_name
from inference import parse_seed
from harness.generation_models import generation_backend, supported_generation_backend, UNDERLYING_MODELS
from result_index import write_json
from watermarks import validate_watermark

UNDERLYING_MODEL = "DeepSeekR1"
DEFAULT_TEMPERATURE = 0.6


def watermark_values(scheme=None, watermark_key=None, settings=None, *, existing=None, generate_key=False):
    """Resolve explicit overrides over saved settings without mutating a profile.

    A scheme change retains the key, resets scheme-specific fields, and applies
    new settings. Only creation/persistent updates may generate a missing key.
    """
    settings = deepcopy(settings or {})
    existing = deepcopy(existing or {})
    selected = scheme or settings.get('scheme') or existing.get('scheme')
    if not selected:
        raise ValueError('Choose a watermark scheme or a saved watermarked model.')
    if scheme is not None and settings.get('scheme', scheme) != scheme:
        raise ValueError('The settings scheme and selected watermark scheme disagree.')
    config = existing if existing.get('scheme') == selected else {'scheme': selected}
    if 'key' not in config and 'key' in existing: config['key'] = existing['key']
    if generate_key and selected == 'synthid' and existing.get('scheme') != selected:
        config.update(generation_policy='tournament', depth=4)
    config.update(settings)
    if watermark_key is not None: config['key'] = watermark_key
    if 'key' not in config:
        if not generate_key:
            raise ValueError('Supply the watermark key or select a saved watermarked model. Detection never generates a key.')
        config['key'] = secrets.token_hex(32)
    return validate_watermark(config)


def profile_values(name, seed=None, underlying_model=UNDERLYING_MODEL, watermark=None):
    name = name.strip()
    if not name or len(name) > 80 or any(ord(c) < 32 for c in name):
        raise ValueError("Enter a model name of 1–80 characters, without line breaks.")
    if underlying_model is None:
        raise ValueError('Choose deepseek (DeepSeekR1) or qwen (Qwen3-8B).')
    underlying_model = generation_backend(underlying_model).underlying_model
    literal = str(seed).strip() if seed is not None else ""
    if literal and not re.fullmatch(r"(?:0[xX][0-9a-fA-F]+(?:_[0-9a-fA-F]+)*|[0-9]+(?:_[0-9]+)*)", literal):
        raise ValueError("Enter an integer seed or a hexadecimal seed beginning with 0x.")
    values = {"name": name, "seed": parse_seed(literal) if literal else None, "seed_literal": literal or None,
              "underlying_model": underlying_model}
    if watermark is not None:
        values["watermark"] = validate_watermark(watermark)
    return values


class ModelProfiles:
    def __init__(self, root=ROOT):
        self.root = Path(root)
        self.path = self.root / "harness/models.json"

    def profiles(self):
        if not self.path.exists():
            from dotenv import dotenv_values
            profiles = {}
            for index in (1, 2):
                path = self.root / f"harness/seeds/seed{index}.env"
                if not path.exists():
                    path = ROOT / f"harness/seeds/seed{index}.env"
                literal = dotenv_values(path)["DEEPSEEK_SEED"].strip()
                profiles[f"seed-{index}"] = profile_values(seed_model_name(load_seed(path), literal), literal)
            return profiles
        data = json.loads(self.path.read_text())
        if data.get("version") != 1:
            raise ValueError("Unsupported model configuration version.")
        profiles = {}
        names = set()
        for record in data["models"]:
            key = record["key"]
            if not re.fullmatch(r"[a-z0-9-]+", key) or key in profiles:
                raise ValueError("Model configuration contains an invalid or duplicate ID.")
            values = profile_values(record["name"], record.get("seed_literal"), record.get("underlying_model", UNDERLYING_MODEL), record.get("watermark"))
            if values["seed"] != record.get("seed") or values["name"].casefold() in names:
                raise ValueError("Model configuration contains inconsistent seeds or duplicate names.")
            profiles[key] = values
            names.add(values["name"].casefold())
        return profiles

    def supported_profiles(self):
        return {key: profile for key, profile in self.profiles().items()
                if generation_backend(profile).family == 'deepseek'}

    def document(self, profiles):
        return {"version": 1, "models": [{"key": key, **value} for key, value in profiles.items()]}

    def initialize(self):
        if not self.path.exists():
            write_json(self.path, self.document(self.profiles()))

    def added(self, name, seed, underlying_model, watermark=None):
        supported_generation_backend(underlying_model)
        profiles = self.profiles()
        values = profile_values(name, seed, underlying_model, watermark)
        if any(value["name"].casefold() == values["name"].casefold() for value in profiles.values()):
            raise ValueError("A model with that name already exists. Choose a different name.")
        key = "model-" + uuid.uuid4().hex
        profiles[key] = values
        return key, profiles

    def removed(self, key):
        profiles = self.profiles()
        if key not in profiles:
            raise ValueError("That model no longer exists.")
        del profiles[key]
        return profiles

    def watermarked(self, model_id, *, scheme=None, watermark_key=None, settings=None, underlying_model=None):
        profiles = self.profiles()
        if model_id not in profiles:
            raise ValueError('That model no longer exists.')
        profile = profiles[model_id]
        supported_generation_backend(profile if underlying_model is None else underlying_model)
        config = (watermark_values(scheme, watermark_key, settings,
                                   existing=profile.get('watermark'), generate_key=True)
                  if scheme or watermark_key is not None or settings is not None or profile.get('watermark')
                  else None)
        profiles[model_id] = profile_values(profile['name'], profile['seed_literal'], profile['underlying_model'] if underlying_model is None else underlying_model, config)
        return profiles

    def save(self, profiles):
        """Persist named model settings without a remote comparison helper.

        Callers hold the shared workspace configuration lock. No legacy session
        or OpenCode configuration is rewritten by supported website operations.
        """
        from ai_lab.service import atomic_json
        atomic_json(self.path, self.document(profiles))

    async def publish(self, profiles, client):
        """Replace generated configs, reload only this project, and roll back on failure.

        The caller holds PairStore.configuration_lock and checks for active work.
        Full replacement also removes deleted aliases; PATCH /config merges them.
        """
        from ai_lab.service import atomic_json
        files = {
            self.path: self.document(profiles),
            self.root / "opencode.json": app_config(profiles=profiles, plugin="./harness/seeded-profiles.mjs"),
            self.root / ".state/opencode-viewer/config/opencode/opencode.json": app_config(profiles=profiles),
        }
        previous = {path: path.read_bytes() if path.exists() else None for path in files}
        try:
            for path, document in files.items():
                atomic_json(path, document)
            await client.request("POST", "/instance/dispose")
            actual = await client.request("GET", "/config")
            models = actual.get("provider", {}).get(PROVIDER, {}).get("models", {})
            seeds = {key: value.get("options", {}).get("seed") for key, value in models.items()}
            if seeds != {key: value["seed"] for key, value in profiles.items()}:
                raise ValueError("OpenCode did not load the new model configuration.")
            if any(models[key].get('id') != generation_backend(value).api_model or
                   models[key].get('provider', {}).get('api') != generation_backend(value).base_url + '/v1'
                   for key, value in profiles.items()):
                raise ValueError('OpenCode did not load the generation backend routing.')
            if any(value["seed"] is None and "seed" in models[key].get("options", {}) for key, value in profiles.items()):
                raise ValueError("OpenCode retained a seed option for an unseeded model.")
            if any(models[key].get("options", {}).get("watermark") != value.get("watermark") for key, value in profiles.items()):
                raise ValueError("OpenCode did not load the watermark configuration.")
        except Exception:
            for path, content in previous.items():
                if content is None:
                    path.unlink(missing_ok=True)
                else:
                    temporary = path.with_suffix(path.suffix + ".tmp")
                    temporary.write_bytes(content)
                    temporary.chmod(0o600)
                    temporary.replace(path)
            try:
                await client.request("POST", "/instance/dispose")
            except Exception:
                pass
            raise
