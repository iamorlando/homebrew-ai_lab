"""Harbor viewer artifacts for local recordings (not Harbor benchmark executions)."""
import hashlib
import json
from uuid import UUID, NAMESPACE_URL, uuid5

from harbor.models.job.config import JobConfig
from harbor.models.job.result import JobResult, JobStats
from harbor.models.trial.config import TrialConfig
from harbor.models.trial.result import TrialResult
from harbor.models.trajectories import Trajectory

EXPORT_VERSION = 2
NOTE = ("Recorded by the local comparison app; no Harbor sandbox or benchmark verifier ran. "
        "Detector evidence is not a benchmark reward. Older records may lack operation timestamps; "
        "job timestamps are used as a fallback. Watermark secret keys are excluded.")


class RecordedLocalSession:
    """Identify read-only recordings without claiming a Docker environment ran."""
    def __init__(self, *args, **kwargs):
        raise RuntimeError("This is a saved local session. Run a new experiment in /pair or /wm.")


def job_name(kind, record):
    return f"{kind}-{UUID(record['id']).hex}"


def harbor_url(kind, record):
    return f"/jobs/{job_name(kind, record)}"


def safe(value):
    """Do not export private watermark configurations, including nested snapshots."""
    if isinstance(value, dict):
        return {k: safe(v) for k, v in value.items() if k not in {"watermark", "key"}}
    if isinstance(value, list):
        return [safe(v) for v in value]
    return value


def profile_settings(profile):
    return {k: profile[k] for k in ("name", "seed", "seed_literal", "underlying_model") if k in profile}


def usage(result):
    if "usage" in result:
        raw = result["usage"] or {}
        return {"n_input_tokens": raw.get("prompt_tokens"), "n_output_tokens": raw.get("completion_tokens")}
    raw = result.get("tokens", {})
    cached = raw.get("cache", {}).get("read")
    # OpenCode reports uncached input separately from cache reads and writes.
    input_tokens = raw.get("input")
    if input_tokens is not None:
        input_tokens += (cached or 0) + (raw.get("cache", {}).get("write") or 0)
    return {"n_input_tokens": input_tokens, "n_cache_tokens": cached, "n_output_tokens": raw.get("output")}


def sum_usage(records):
    totals = {}
    for record in records:
        for key, value in usage(record).items():
            if value is not None:
                totals[key] = totals.get(key, 0) + value
    return totals


def operations(kind, record):
    if kind == "comparison":
        for lane in record["models"]:
            turns = [(turn, next((r for r in turn["responses"] if r["key"] == lane["key"]), None))
                     for turn in record["turns"]]
            turns = [(t, r) for t, r in turns if r]
            if not turns:
                continue
            steps = []
            for turn, response in turns:
                steps.append({"source": "user", "message": turn["prompt"], "timestamp": turn["created_at"]})
                if response.get("answer") or response.get("reasoning"):
                    steps.append({"source": "agent", "message": response.get("answer", ""),
                                  "reasoning_content": response.get("reasoning") or None,
                                  "model_name": lane["name"], "extra": {"temperature": turn.get("temperature"),
                                  "status": response["status"]}})
            yield {"id": lane["key"], "name": f"{lane['key'].replace('-', ' ').title()} · {lane['name']}",
                   "agent": "opencode", "profile": lane, "steps": steps,
                   "status": turns[-1][1]["status"], "error": turns[-1][1].get("error"),
                   "started_at": turns[0][1].get("started_at", turns[0][0]["created_at"]),
                   "finished_at": turns[-1][1].get("finished_at"),
                   "usage": sum_usage([r for _, r in turns]),
                   "record": {"model": profile_settings(lane), "turns": [
                       {"prompt": t["prompt"], "temperature": t.get("temperature"), "response": safe(r)} for t, r in turns]}}
        return
    for agent in record["agents"]:
        entries = [("response-" + agent["id"], agent["name"], agent)]
        if agent.get("illustration"):
            sample = agent["illustration"]
            entries.append(("sample-" + sample["id"], agent["name"] + " · traced sample", sample))
        for identity, label, result in entries:
            steps = [{"source": "user", "message": agent["prompt"]}]
            if result.get("answer"):
                steps.append({"source": "agent", "message": result["answer"], "model_name": agent["model"]["name"]})
            yield {"id": identity, "name": label, "agent": "mistral-local", "profile": agent["model"],
                   "steps": steps, "usage": usage(result), "record": safe(result),
                   **{k: result.get(k) for k in ("status", "error", "created_at", "started_at", "finished_at")}}
    for position, detection in enumerate(record["detections"], 1):
        steps = [{"source": "user", "message": detection["text"]}]
        if detection["status"] == "complete":
            report = {k: v for k, v in safe(detection).items() if k not in {"text", "id", "created_at", "finished_at", "status"}}
            steps.append({"source": "agent", "message": json.dumps(report, ensure_ascii=False, indent=2),
                          "llm_call_count": 0, "extra": {"operation": "POST /v1/watermark/detect", "model_inference": False}})
        yield {"id": "detector-" + detection["id"], "name": f"Detector {position}", "agent": "mistral-detector",
               "profile": {}, "steps": steps, "usage": {}, "record": safe(detection),
               **{k: detection.get(k) for k in ("status", "error", "created_at", "started_at", "finished_at")}}


def project_record(destination, kind, record, write_json):
    """Update only our own derived files; never touch the canonical recording."""
    name = job_name(kind, record)
    target = destination / name
    job_id = uuid5(NAMESPACE_URL, f"deepseek/{name}")
    source = "wm experiments" if kind == "wm" else "interactive comparisons"
    environment = {"import_path": "harbor_exports:RecordedLocalSession", "kwargs": {"recording_only": True}}
    files = {}
    results, configs, statuses = [], [], []
    for operation in operations(kind, record):
        identity = operation["id"]
        # Operation IDs become directory names, never user-supplied display names.
        if not identity or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in identity):
            raise ValueError("Invalid recorded operation ID")
        folder = target / identity
        task_path = folder / source
        profile = operation["profile"]
        agent = {"name": operation["agent"], "model_name": f"mistral-local/{profile['name']}" if profile else None,
                 "kwargs": {"recording_only": True, **profile_settings(profile)}}
        config = TrialConfig.model_validate({"task": {"path": str(task_path), "source": source},
                    "trial_name": identity, "trials_dir": str(target), "job_id": str(job_id),
                    "agent": agent, "environment": environment, "verifier": {"disable": True}})
        status = operation["status"]
        statuses.append(status)
        terminal = status not in {"queued", "running"}
        started = operation.get("started_at") or operation.get("created_at") or record["created_at"]
        finished = (operation.get("finished_at") or record["updated_at"]) if terminal else None
        error = None
        if status in {"error", "interrupted", "stopped"}:
            error = {"exception_type": {"error": "RecordedOperationError", "interrupted": "InterruptedError",
                     "stopped": "CancelledError"}[status], "exception_message": operation.get("error") or status,
                     "exception_traceback": "", "occurred_at": finished}
        result = TrialResult.model_validate({"id": str(uuid5(job_id, identity)), "task_name": operation["name"],
                  "trial_name": identity, "trial_uri": folder.resolve().as_uri(), "task_id": {"path": str(task_path)},
                  "task_checksum": hashlib.sha256(operation["steps"][0]["message"].encode()).hexdigest(),
                  "source": source, "config": config.model_dump(mode="json"),
                  "agent_info": {"name": operation["agent"], "version": "recorded",
                                 "model_info": {"name": profile["name"], "provider": "mistral-local"} if profile else None},
                  "agent_result": {**operation["usage"], "metadata": {"status": status, "recording_only": True}},
                  "started_at": started, "finished_at": finished, "exception_info": error})
        steps = [{"step_id": i, **step} for i, step in enumerate(operation["steps"], 1)]
        trajectory = Trajectory.model_validate({"session_id": str(result.id),
                     "agent": {"name": operation["agent"], "version": "recorded", "model_name": profile.get("name")},
                     "steps": steps, "notes": NOTE, "extra": {"status": status, "scheme": record.get("scheme")}})
        files[f"{identity}/config.json"] = config.model_dump(mode="json")
        files[f"{identity}/result.json"] = result.model_dump(mode="json")
        files[f"{identity}/agent/trajectory.json"] = trajectory.to_json_dict()
        files[f"{identity}/artifacts/recording.json"] = operation["record"]
        files[f"{identity}/{source}/instruction.md"] = "\n\n".join(step["message"] for step in steps if step["source"] == "user")
        results.append(result)
        configs.append(config)
    stats = JobStats.from_trial_results([r for r in results if r.finished_at])
    stats.n_running_trials = statuses.count("running")
    stats.n_pending_trials = statuses.count("queued")
    stats.n_cancelled_trials = statuses.count("stopped") + statuses.count("interrupted")
    config = JobConfig.model_validate({"job_name": name, "jobs_dir": str(destination), "agents": [c.agent for c in configs],
                 "tasks": [c.task for c in configs], "environment": environment, "verifier": {"disable": True},
                 "extra_instructions": [NOTE]})
    result = JobResult(id=job_id, started_at=record["created_at"], updated_at=record["updated_at"],
                       finished_at=record["updated_at"] if not any(s in {"queued", "running"} for s in statuses) else None,
                       n_total_trials=len(results), stats=stats)
    files["config.json"] = config.model_dump(mode="json")
    files["result.json"] = result.model_dump(mode="json")
    files["recording.json"] = {"title": record["title"], "scheme": record.get("scheme"), "note": NOTE,
                               "source_url": (f"/wm?id={record['id']}" if kind == "wm" else f"/pair?conversation={record['id']}"),
                               "export_version": EXPORT_VERSION}
    owned_path = target / ".projection.json"
    previous = json.loads(owned_path.read_text()) if owned_path.exists() else []
    for relative, value in files.items():
        if isinstance(value, str):
            path = target / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            temporary = path.with_suffix(path.suffix + ".tmp")
            temporary.write_text(value)
            temporary.replace(path)
        else:
            write_json(target / relative, value)
    for relative in set(previous) - files.keys():
        path = target / relative
        if path.resolve().is_relative_to(target.resolve()):
            path.unlink(missing_ok=True)
    write_json(owned_path, list(files))
    return name
