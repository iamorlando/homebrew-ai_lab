"""Project the native production bracket and verify its connection to the emitted token."""
import math


def public_generation_tournament(source, step, max_matches=255):
    def require(condition):
        if not condition:
            raise ValueError("Mistral returned an invalid production tournament or a winner different from its emitted token.")

    def fields(value, names):
        return {key: value[key] for key in names.split() if key in value}

    def integer(value, minimum=0):
        return type(value) is int and value >= minimum

    try:
        result = fields(source, "origin used_for_generation status configured_depth rounds total_draws total_matches rng_version effective_seed rng_provenance sampling_version truncated truncation_reason")
        require(result["origin"] == "production" and type(result["used_for_generation"]) is bool)
        seed = result["effective_seed"]
        require(seed is None or (isinstance(seed, str) and seed.isascii() and seed.isdigit() and int(seed) < 2**64))
        require(type(result["truncated"]) is bool)
        result["draws"] = [fields(d, "draw_id token_id text text_status probability") for d in source["draws"]]
        result["collapsed_subtrees"] = [fields(s, "root_match_id round first_draw_id draw_count match_count winner_draw_id token_id") for s in source["collapsed_subtrees"]]
        result["matches"] = []
        require(len(source["matches"]) <= max_matches)
        for m in source["matches"]:
            match = fields(m, "match_id round winner winner_draw_id reason")
            for side in ("left", "right"):
                match[side] = fields(m[side], "draw_id token_id g_value")
                match[side]["source"] = fields(m[side]["source"], "kind id")
            result["matches"].append(match)
        result["winner"] = fields(source["winner"], "match_id draw_id token_id") if source.get("winner") else None
        if result["status"] != "applied":
            require(result["status"] in {"warmup", "repeated_context", "no_production_bracket", "watermark_disabled", "greedy", "unsupported_sampling", "unsupported_depth"})
            require(not result["used_for_generation"] and result["winner"] is None)
            require(result["rounds"] == result["total_draws"] == result["total_matches"] == 0)
            require(not result["draws"] and not result["matches"] and not result["collapsed_subtrees"])
            return result
        depth = result["configured_depth"]
        require(integer(depth, 1) and depth <= 20 and result["rounds"] == depth)
        require(result["used_for_generation"] and step["selection_rule"] == "synthid_tournament")
        require(step["watermark"]["scheme"] == "synthid" and step["watermark"]["status"] == "applied")
        require(seed is not None and result["rng_provenance"] == "sequence_seed")
        require(result["total_draws"] == 2**depth and result["total_matches"] == 2**depth - 1)
        require(all(c.get("post_watermark_probability") is None for c in step["candidates"]))
        draws, nodes = {}, {}
        for draw in result["draws"]:
            identity, token = draw["draw_id"], draw["token_id"]
            require(integer(identity) and identity < result["total_draws"] and identity not in draws)
            require(integer(token) and token < step["candidate_count"])
            require(isinstance(draw["probability"], (int, float)) and math.isfinite(draw["probability"]) and 0 < draw["probability"] <= 1)
            require(draw.get("text") is None or isinstance(draw["text"], str))
            draws[identity] = draw
            nodes[("draw", identity)] = (identity, token, -1)
        for subtree in result["collapsed_subtrees"]:
            identity = subtree["root_match_id"]
            require(integer(identity) and identity < result["total_matches"] and ("collapsed_subtree", identity) not in nodes)
            require(integer(subtree["round"]) and subtree["round"] < depth)
            require(subtree["draw_count"] == 2**(subtree["round"] + 1) and subtree["match_count"] == subtree["draw_count"] - 1)
            require(integer(subtree["first_draw_id"]) and subtree["first_draw_id"] + subtree["draw_count"] <= result["total_draws"])
            draw = draws[subtree["winner_draw_id"]]
            require(draw["token_id"] == subtree["token_id"] and subtree["first_draw_id"] <= draw["draw_id"] < subtree["first_draw_id"] + subtree["draw_count"])
            nodes[("collapsed_subtree", identity)] = (draw["draw_id"], draw["token_id"], subtree["round"])
        consumed = set()
        for match in sorted(result["matches"], key=lambda m: m["round"]):
            identity, round_index = match["match_id"], match["round"]
            require(integer(identity) and identity < result["total_matches"] and ("match", identity) not in nodes and ("collapsed_subtree", identity) not in nodes)
            require(integer(round_index) and round_index < depth and match["winner"] in {"left", "right"})
            for side in ("left", "right"):
                entrant = match[side]
                ref = entrant["source"]["kind"], entrant["source"]["id"]
                require(ref not in consumed and ref in nodes and type(entrant["g_value"]) is int and entrant["g_value"] in (0, 1))
                require(nodes[ref] == (entrant["draw_id"], entrant["token_id"], round_index - 1))
                consumed.add(ref)
            winner, loser = match[match["winner"]], match["right" if match["winner"] == "left" else "left"]
            require(match["winner_draw_id"] == winner["draw_id"])
            require((match["reason"] == "higher_g" and winner["g_value"] > loser["g_value"]) or
                    (match["reason"] == "random_tie" and winner["g_value"] == loser["g_value"]))
            nodes[("match", identity)] = (winner["draw_id"], winner["token_id"], round_index)
        winner = result["winner"]
        require(winner is not None and winner["token_id"] == step["selected_token_id"])
        root = ("match", winner["match_id"])
        if root not in nodes:
            root = ("collapsed_subtree", winner["match_id"])
        require(nodes.get(root) == (winner["draw_id"], winner["token_id"], depth - 1) and root not in consumed)
        require(all(ref in consumed or ref == root for ref in nodes if ref[0] != "draw"))
        require(len(result["matches"]) + sum(s["match_count"] for s in result["collapsed_subtrees"]) == result["total_matches"])
        require(not result["collapsed_subtrees"] or result["truncated"])
        return result
    except (KeyError, TypeError, IndexError, OverflowError) as error:
        raise ValueError("Mistral returned an incomplete production tournament.") from error
