"""Direct local generation and anonymous detection through Mistral's HTTP API."""
import asyncio
import json
import os
from pathlib import Path
from urllib.parse import urlsplit
from functools import lru_cache

import httpx

import inference
from harness.generation_models import generation_backend
from sampling_trace import TRACE_LIMITS, public_trace

SYSTEM = ("You are a helpful conversational assistant. Answer the user's prompt directly. "
          "When appropriate, give a substantive answer of at least four sentences. "
          "Use fewer sentences when the requested format or a simple answer makes that more appropriate.")


def generation_prefix(prompt, model=None):
    if generation_backend(model).family == 'qwen':
        # Exact pinned official template for system + user, enable_thinking=False.
        return (f'<|im_start|>system\n{SYSTEM}<|im_end|>\n'
                f'<|im_start|>user\n{prompt}<|im_end|>\n'
                '<|im_start|>assistant\n<think>\n\n</think>\n\n')
    return f"<｜begin▁of▁sentence｜>{SYSTEM}<｜User｜>{prompt}<｜Assistant｜><think>\n</think>\n\n"


@lru_cache(maxsize=2)
def response_tokenizer(model=None):
    from tokenizers import Tokenizer
    backend = generation_backend(model)
    path = backend.asset_dir / 'tokenizer.json'
    if backend.family == 'deepseek':
        expected = inference.SOURCES['assets']['sha256']['tokenizer.json']
    else:
        from ai_lab.downloads import catalog
        expected = next(file['sha256'] for file in catalog()[backend.family]['files'] if file['path'].endswith('/tokenizer.json'))
    if inference.sha256(path) != expected:
        raise ValueError('The local tokenizer does not match the serving model assets.')
    return Tokenizer.from_file(str(path))


class WatermarkRuntime:
    def __init__(self, *, allow_start=True, transport=None, fixture_endpoints=None):
        self.allow_start = allow_start
        fixture_file = os.environ.get('AI_LAB_GENERATION_FIXTURE_FILE')
        if fixture_file and fixture_endpoints is None:
            document = json.loads(Path(fixture_file).read_text())
            if document.get('version') != 1 or set(document) != {'version', 'endpoints'}:
                raise ValueError('Generation fixture must contain version=1 and endpoints only.')
            fixture_endpoints = document['endpoints']
        self.fixture_endpoints = {}
        if fixture_endpoints is not None:
            if allow_start:
                raise ValueError('Generation HTTP fixtures require allow_start=False; they never start native APIs.')
            if not isinstance(fixture_endpoints, dict) or not fixture_endpoints:
                raise ValueError('Generation fixture endpoints must be a nonempty family-to-loopback-URL map.')
            for family, endpoint in fixture_endpoints.items():
                backend = generation_backend(family)
                if family != backend.family or not isinstance(endpoint, str):
                    raise ValueError('Generation fixture keys must be deepseek or qwen.')
                url = urlsplit(endpoint)
                if (url.scheme != 'http' or url.hostname not in {'127.0.0.1', '::1'} or not url.port
                        or url.username or url.password or url.path not in {'', '/'} or url.query or url.fragment):
                    raise ValueError('Generation fixtures require an explicit HTTP loopback port and no path or credentials.')
                self.fixture_endpoints[family] = endpoint.rstrip('/')
        self.http_options = {'transport': transport} if transport is not None else {}
        self.generation_lock = asyncio.Lock()
        self.detection_lock = asyncio.Lock()

    def base_url(self, model=None):
        backend = generation_backend(model)
        return self.fixture_endpoints.get(backend.family, backend.base_url)

    def fixture_metadata(self, model=None):
        backend = generation_backend(model)
        return {'fixture': True} if backend.family in self.fixture_endpoints else {}

    async def ensure_server(self, model=None):
        backend = generation_backend(model)
        if self.allow_start:
            await asyncio.to_thread(inference.start, **({'model': backend} if backend.family != 'deepseek' else {}))
            return
        try:
            async with httpx.AsyncClient(base_url=self.base_url(backend), timeout=2,
                                         trust_env=False, **self.http_options) as client:
                response = await client.get('/v1/models')
                response.raise_for_status()
                health = response.json()
                if backend.family in self.fixture_endpoints:
                    expected = 'ai-lab-fixture-' + backend.family
                    if any(row.get('id') == expected for row in health.get('data', [])):
                        return
                elif inference.api_model_matches(health, backend):
                    # Read-only requests can share a running backend launched
                    # elsewhere. A known owned receipt still proves stale
                    # runtime/template settings and must not be bypassed.
                    current = inference.owned_state(backend)
                    if current is None or inference.launch_matches(current, backend):
                        return
        except (httpx.HTTPError, ValueError, AttributeError, TypeError):
            pass
        if backend.family not in self.fixture_endpoints:
            current = inference.owned_state(backend)
            if current and not inference.launch_matches(current, backend):
                raise ValueError(inference.restart_guidance(backend))
        raise ValueError(f'The {backend.label} API is unavailable. Retry the selected operation in ai-lab web or MCP; if setup is missing, run ai-lab setup install {backend.family} --yes.')

    async def complete_next(self, prompt, watermark=None, *, temperature=1, seed=None, model=None):
        """One raw-prefix decision with optional, unsaved watermark settings."""
        backend = generation_backend(model)
        async with self.generation_lock:
            await self.ensure_server(backend)
            limits = {"max_steps": 1, "max_candidates": 128 if watermark else 16,
                      "max_layers": 4 if watermark and watermark["scheme"] == "synthid" else 0}
            body = {"model": backend.api_model, "prompt": prompt, "max_tokens": 1,
                    "temperature": temperature, "top_k": 0, "top_p": 1, "min_p": 0,
                    "repetition_penalty": 1, "presence_penalty": 0,
                    "frequency_penalty": 0, "dry_multiplier": 0,
                    "stream": False, "n": 1, "logprobs": 16,
                    "sampling_trace": dict(limits)}
            if seed is not None:
                body["seed"] = inference.parse_seed(seed)
            if watermark:
                body["watermark"] = watermark
                if watermark["scheme"] == "synthid":
                    body["sampling_trace"]["generation_tournament"] = {"max_matches": 255}
            async with httpx.AsyncClient(base_url=self.base_url(backend), timeout=180, trust_env=False, **self.http_options) as client:
                response = await client.post("/v1/completions", json=body)
                response.raise_for_status()
                result = response.json()
            trace = public_trace(result["choices"][0].get("sampling_trace"), body["sampling_trace"])
            actual = trace["steps"][0].get("watermark")
            if len(trace["steps"]) != 1 or (actual or {}).get("scheme") != (watermark or {}).get("scheme"):
                raise ValueError("Mistral's next-token trace does not match the requested watermark scheme.")
            if watermark and watermark["scheme"] == "synthid":
                self.validate_tournament(trace, watermark)
            return {"prompt": prompt, "model": backend.underlying_model, "temperature": temperature,
                    "watermark": {k: v for k, v in watermark.items() if k != "key"} if watermark else None,
                    "step": trace["steps"][0], "usage": result.get("usage", {}),
                    "finish_reason": result["choices"][0].get("finish_reason"), **self.fixture_metadata(backend)}

    async def inspect_response(self, prompt, prefix, watermark, *, temperature=1, model=None):
        """Fresh native next-token alternatives at any editable response position."""
        backend = generation_backend(model)
        base = generation_prefix(prompt, backend)
        full = base + prefix
        def position():
            tokenizer = response_tokenizer(**({'model': backend} if backend.family != 'deepseek' else {}))
            count = len(tokenizer.encode(full, add_special_tokens=False).ids)
            start = len(tokenizer.encode(base, add_special_tokens=False).ids)
            return count, max(0, count - start)
        context_tokens, response_position = await asyncio.to_thread(position)
        if context_tokens >= 8192:
            raise ValueError('This position exceeds the local model’s 8,192-token context window.')
        adjusted = dict(watermark)
        if 'start_position' in adjusted:
            adjusted['start_position'] += response_position
        result = await self.complete_next(full, adjusted, temperature=temperature, **({'model': backend} if backend.family != 'deepseek' else {}))
        if result['step']['context_length'] != context_tokens:
            raise ValueError('The serving tokenizer disagrees with the response position; alternatives were not applied.')
        # This is a new request, not a replay of the original sampler's history.
        result.pop('prompt', None)
        return {**result, 'response_position': response_position, 'origin': 'prefix_inspection'}

    async def generate(self, profile, watermark, prompt, *, capture_trace=False, max_tokens=1024, detailed_trace=False, temperature=0.8, unfiltered=False):
        backend = generation_backend(profile)
        settings = watermark or {}
        async with self.generation_lock:
            if self.allow_start:
                build = await asyncio.to_thread(inference.verify_installation, **({'model': backend} if backend.family != 'deepseek' else {}))
                if watermark and not build.get("watermark_support"):
                    raise ValueError(f"Install the watermark-enabled runtime with ai-lab setup install {backend.family} --yes.")
            await self.ensure_server(backend)
            # Each official template closes thinking in its own format so the
            # answer alone starts at watermark position zero.
            body = {"model": backend.api_model,
                    "prompt": generation_prefix(prompt, backend),
                    "temperature": temperature, "top_p": 0.95, "top_k": 40,
                    "max_tokens": max_tokens, "stream": False}
            if watermark:
                body["watermark"] = watermark
            if unfiltered:
                body.update(top_p=1, top_k=0, min_p=0, repetition_penalty=1,
                            frequency_penalty=0, presence_penalty=0, dry_multiplier=0)
            if profile.get("seed") is not None:
                body["seed"] = profile["seed"]
            if capture_trace:
                # Completions uses numeric logprobs; chat's boolean is invalid here.
                limits = ({"max_steps": 24, "max_candidates": 128,
                           "max_layers": 4 if settings.get("scheme") == "synthid" else 0}
                          if detailed_trace or settings.get("generation_policy") == "tournament" else dict(TRACE_LIMITS))
                if settings.get("scheme") == "synthid" and (detailed_trace or settings.get("generation_policy") == "tournament"):
                    limits["generation_tournament"] = {"max_matches": 255}
                body.update(logprobs=10, n=1, sampling_trace=dict(limits))
            async with httpx.AsyncClient(base_url=self.base_url(backend), timeout=1200, trust_env=False, **self.http_options) as client:
                response = await client.post("/v1/completions", json=body)
                response.raise_for_status()
                result = response.json()
            answer = result["choices"][0]["text"]
            if not isinstance(answer, str) or not answer.strip():
                raise ValueError("Mistral returned an empty answer. Try generating again.")
            generated = {"answer": answer, "usage": result.get("usage", {}),
                         "finish_reason": result["choices"][0].get("finish_reason"), **self.fixture_metadata(backend)}
            if capture_trace:
                try:
                    generated["sampling_trace"] = public_trace(result["choices"][0].get("sampling_trace"), limits)
                    if "generation_tournament" in limits:
                        self.validate_tournament(generated["sampling_trace"], watermark)
                    generated["trace_settings"] = {**limits, "scheme": settings.get("scheme"),
                                                   "configured_depth": settings.get("depth"),
                                                   "generation_policy": settings.get("generation_policy", "probability_updates")}
                    if detailed_trace:
                        generated["trace_settings"]["detailed"] = True
                except (ValueError, KeyError, TypeError) as error:
                    # A trace failure must never discard a successfully generated answer.
                    generated["trace_error"] = str(error)
            return generated

    @staticmethod
    def validate_tournament(trace, watermark):
        for step in trace["steps"]:
            report = step.get("generation_tournament")
            if not report or report["configured_depth"] != watermark["depth"]:
                raise ValueError("Mistral returned a missing or mismatched production tournament. Rebuild the updated runtime.")
            if watermark.get("generation_policy", "probability_updates") == "tournament":
                if report["status"] not in {"applied", "warmup", "repeated_context", "greedy"}:
                    raise ValueError("Mistral did not execute the requested tournament generation policy.")
            elif report["status"] not in {"no_production_bracket", "greedy"}:
                raise ValueError("Mistral's tournament report disagrees with the generation policy.")

    async def detect(self, text, candidates, *, prompt_len=0, eos_token_ids=None, add_special_tokens=False, model=None):
        """Inputs are response text and anonymous configs only; never agent records."""
        backend = generation_backend(model)
        async with self.detection_lock:
            if not candidates:
                return []
            await self.ensure_server(backend)
            results = []
            async with httpx.AsyncClient(base_url=self.base_url(backend), timeout=180, trust_env=False, **self.http_options) as client:
                # Preserve the caller's shuffled order for evidence-to-name mapping.
                # The serving model alias selects a tokenizer, never an agent.
                for watermark in candidates:
                    response = await client.post("/v1/watermark/detect", json={
                        "watermark": watermark,
                        "input": {"type": "text", "model": backend.api_model,
                                  "text": text, "add_special_tokens": add_special_tokens},
                        "prompt_len": prompt_len, "eos_token_ids": eos_token_ids or [],
                    })
                    response.raise_for_status()
                    results.append({**response.json(), **self.fixture_metadata(backend)})
            return results
