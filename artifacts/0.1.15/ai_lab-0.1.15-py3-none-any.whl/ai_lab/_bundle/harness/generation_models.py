"""Shared identities and routing for native generation (not decision encoders)."""
from dataclasses import dataclass
from pathlib import Path

from project_paths import ROOT


@dataclass(frozen=True)
class GenerationBackend:
    family: str
    underlying_model: str
    label: str
    port: int
    model_path: str
    asset_path: str
    filename: str
    template_file: str
    template_sha256: str
    state_name: str

    @property
    def base_url(self):
        return f'http://127.0.0.1:{self.port}'

    @property
    def model_dir(self):
        return ROOT / self.model_path

    @property
    def asset_dir(self):
        return ROOT / self.asset_path

    @property
    def api_model(self):
        # Pinned native binary exposes default for each single-model API.
        # Backend identity comes from its endpoint and owned launch command.
        return 'default'

    @property
    def identity(self):
        return str(self.model_dir)

    @property
    def pidfile(self):
        return ROOT / '.state' / (self.state_name + '.json')

    @property
    def log_name(self):
        return self.state_name + '.log'


GENERATION_BACKENDS = (
    GenerationBackend('deepseek', 'DeepSeekR1', 'DeepSeek R1', 11435,
        '.models/deepseek-r1', '.models/deepseek-assets',
        'DeepSeek-R1-0528-Qwen3-8B-Q4_K_M.gguf', 'deepseek-chat.jinja',
        'f3ee548562d647b506a7b60a4cf0a955d1aab29a3f358a625ce721f325d06d44', 'mistral-server'),
    GenerationBackend('qwen', 'Qwen3-8B', 'Qwen3-8B', 11439,
        '.models/qwen3-8b', '.models/clm-v0.1-8b/Qwen/Qwen3-8B',
        'Qwen3-8B-Q4_K_M.gguf', 'qwen-chat.jinja',
        '3b296655c957f3c81658af9d85175dcbfc38f84c7dc350ade496c8935dcf6239', 'qwen-server'),
)
# Legacy identities remain readable so upgrades preserve saved profiles and files.
# Only DeepSeek is offered for generation; CLM is a separate decision encoder.
UNDERLYING_MODELS = ('DeepSeekR1',)


def generation_backend(value=None):
    """Resolve a family, persisted underlying model, or profile; reject unknowns."""
    if isinstance(value, GenerationBackend):
        if value in GENERATION_BACKENDS:
            return value
        raise ValueError('Unknown generation backend.')
    if isinstance(value, dict):
        if 'underlying_model' in value and value['underlying_model'] is None:
            raise ValueError('A profile must name its generation backend.')
        value = value.get('underlying_model', 'DeepSeekR1')
    if value is None:
        value = 'DeepSeekR1'
    for backend in GENERATION_BACKENDS:
        if value in {backend.family, backend.underlying_model, backend.identity, backend.api_model}:
            return backend
    raise ValueError('Choose deepseek (DeepSeekR1) or qwen (Qwen3-8B).')


def supported_generation_backend(value=None):
    """Validate public generation without repurposing saved legacy profiles."""
    try:
        backend = generation_backend(value)
    except ValueError as error:
        raise ValueError('Choose deepseek (DeepSeekR1) or a saved DeepSeek profile.') from error
    if backend.family != 'deepseek':
        raise ValueError('Standalone Qwen is no longer supported. Choose a DeepSeek profile; CLM retains its required base weights.')
    return backend
