"""Offline lifecycle and OpenAI-compatible access for the local mistral.rs build."""
import hashlib
import errno
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
import urllib.request

from project_paths import ROOT
from harness.generation_models import generation_backend
SOURCES = json.loads((ROOT / 'sources.json').read_text())
STATE = ROOT / '.state'
PIDFILE = STATE / 'mistral-server.json'
BUILD_FILE = STATE / 'mistral-build.json'
MODEL = SOURCES['model']['api_model']
MODEL_DIR = ROOT / '.models/deepseek-r1'
ASSET_DIR = ROOT / '.models/deepseek-assets'
PORT = 11435
BASE_URL = f'http://127.0.0.1:{PORT}'
HTTP = urllib.request.build_opener(urllib.request.ProxyHandler({}))
# First launch prepares embedded Metal kernels through macOS, including on M1.
STARTUP_TIMEOUT = 600
_verified = None


def parse_seed(value):
    text = str(value)
    seed = int(text, 16 if text.lower().startswith('0x') else 10)
    if not 0 <= seed <= 2**53 - 1:
        raise ValueError('Seed must be between 0 and 9007199254740991 for exact OpenCode JSON transport.')
    return seed


def sha256(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verified_chat_template_sha256(model=None):
    """Verify the current template even when installation checks are cached."""
    backend = generation_backend(model)
    digest = sha256(ROOT / backend.template_file)
    if digest != backend.template_sha256:
        raise RuntimeError(f'The {backend.label} chat template differs from its pinned checksum.')
    return digest


def verify_installation(model=None):
    global _verified
    backend = generation_backend(model)
    if _verified is None:
        _verified = {}
    if backend.family in _verified:
        return _verified[backend.family]
    if not BUILD_FILE.exists():
        raise RuntimeError(f'Runtime missing. Run ai-lab setup install {backend.family} --yes.')
    build = json.loads(BUILD_FILE.read_text())
    binary = Path(build['binary'])
    if build['commit'] != SOURCES['runtime']['commit'] or sha256(binary) != build['binary_sha256']:
        raise RuntimeError(f'mistral.rs build differs from its saved provenance; rerun ai-lab setup repair-runtime --model {backend.family} --yes.')
    if build.get('watermark_library', {}).get('commit') != SOURCES['watermark_library']['commit']:
        raise RuntimeError(f'Watermark library differs from the pinned revision; rerun ai-lab setup repair-runtime --model {backend.family} --yes.')
    if backend.family == 'deepseek':
        files = [(MODEL_DIR / SOURCES['model']['filename'], SOURCES['model']['weights_sha256'])]
        files += [(ASSET_DIR / name, expected) for name, expected in SOURCES['assets']['sha256'].items()]
    else:
        from ai_lab.downloads import catalog
        files = [(ROOT / file['path'], file['sha256']) for file in catalog()[backend.family]['files']]
    for path, expected in files:
        if sha256(path) != expected:
            raise RuntimeError(f'{backend.label} file differs from its pinned checksum: {path.name}')
    verified_chat_template_sha256(backend)
    _verified[backend.family] = build
    return build


def environment():
    env = os.environ.copy()
    env.update(HF_HOME=str(ROOT / '.runtime/huggingface'), HF_HUB_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1', HF_HUB_DISABLE_IMPLICIT_TOKEN='1', RUST_LOG='info')
    return env


def command(model=None):
    backend = generation_backend(model)
    binary = verify_installation(model)['binary']
    return [binary, 'serve', '-m', str(backend.model_dir), '-f', backend.filename,
            '--tok-model-id', str(backend.asset_dir), '--jinja-explicit', str(ROOT / backend.template_file),
            '--host', '127.0.0.1', '--port', str(backend.port),
            '--max-seqs', '1', '--prefix-cache-n', '0', '--paged-attn', 'off',
            '--max-model-len', '8192', '--no-ui', '--token-source', 'none']


def api(path, body=None, timeout=10, *, model=None):
    backend = generation_backend(model)
    request = urllib.request.Request(backend.base_url + path, data=None if body is None else json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
    with HTTP.open(request, timeout=timeout) as response:
        return json.load(response)


def owned_state(model=None):
    backend = generation_backend(model)
    pidfile = backend.pidfile
    if not pidfile.exists():
        return None
    saved = json.loads(pidfile.read_text())
    result = subprocess.run(['ps', '-p', str(saved['pid']), '-o', 'command='], capture_output=True, text=True)
    actual = result.stdout.strip()
    if (actual == ' '.join(saved['command']) and saved.get('port') == backend.port
            and saved.get('family', 'deepseek') == backend.family
            and str(backend.model_dir) in saved['command']):
        return saved
    return None


def launch_matches(saved, model=None):
    """Readiness includes the template loaded at launch; ownership does not."""
    backend = generation_backend(model)
    return (saved.get('chat_template_sha256') == backend.template_sha256
            and saved.get('command') == command(backend)
            and saved.get('build', {}).get('binary_sha256') == verify_installation(backend)['binary_sha256']
            and verified_chat_template_sha256(backend) == backend.template_sha256)


def restart_guidance(model=None):
    backend = generation_backend(model)
    return (f'The existing {backend.label} API does not match the current launch settings or loaded chat template. '
            f'Stop it through its original launcher (Ctrl+C in that terminal), then run '
            'retry the selected operation in ai-lab web or MCP.')


def port_available(model=None):
    backend = generation_backend(model)
    with socket.socket() as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(('127.0.0.1', backend.port))
        except OSError as error:
            if error.errno != errno.EADDRINUSE:
                raise
            return False
    return True


def stop(model=None):
    backend = generation_backend(model)
    saved = owned_state(model)
    if saved:
        os.killpg(saved['pid'], signal.SIGTERM)
        deadline = time.monotonic() + 20
        while owned_state(model) and time.monotonic() < deadline:
            time.sleep(0.1)
        if owned_state(model):
            os.killpg(saved['pid'], signal.SIGKILL)
        deadline = time.monotonic() + 10
        while not port_available(model) and time.monotonic() < deadline:
            time.sleep(0.1)
        if not port_available(model):
            raise RuntimeError('The managed server has not released its port.')
    backend.pidfile.unlink(missing_ok=True)
    return saved


def start(model=None):
    backend = generation_backend(model)
    expected = command(model)
    template_sha256 = verified_chat_template_sha256(backend)
    current = owned_state(model)
    if current:
        if not launch_matches(current, backend):
            raise RuntimeError(restart_guidance(backend))
        if not model_matches(api('/v1/models', model=model), backend):
            raise RuntimeError(f'The managed API reports a different generation model. {restart_guidance(backend)}')
        return current
    if not port_available(model):
        raise RuntimeError(f'Port {backend.port} is occupied by another process; leaving it untouched.')
    STATE.mkdir(exist_ok=True)
    with (STATE / backend.log_name).open('a') as log:
        process = subprocess.Popen(['/usr/bin/sandbox-exec', '-f', str(ROOT / 'offline.sb'), *expected],
                                   cwd=ROOT, env=environment(), stdin=subprocess.DEVNULL,
                                   stdout=log, stderr=log, start_new_session=True)
    saved = {'pid': process.pid, 'port': backend.port, 'family': backend.family, 'model': backend.underlying_model, 'command': expected, 'offline': True,
             'prefix_cache_n': 0, 'started_at_ns': time.time_ns(), 'build': verify_installation(model),
             'chat_template_sha256': template_sha256}
    backend.pidfile.write_text(json.dumps(saved, indent=2) + '\n')
    deadline = time.monotonic() + STARTUP_TIMEOUT
    try:
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError(f'{backend.label} exited; see .state/{backend.log_name}.')
            try:
                models = api('/v1/models', timeout=2, model=model)
                if model_matches(models, backend):
                    return saved
            except (OSError, ValueError):
                pass
            time.sleep(0.25)
        raise RuntimeError(f'{backend.label} startup timed out; see .state/{backend.log_name}.')
    except BaseException:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=20)
        backend.pidfile.unlink(missing_ok=True)
        raise


def restart(model=None):
    previous = stop(model)
    current = start(model)
    if previous and previous['started_at_ns'] == current['started_at_ns']:
        raise RuntimeError('Server was not restarted.')
    return {'previous_pid': previous['pid'] if previous else None, 'current': current,
            'fresh_process_verified': True, 'prefix_cache_disabled': True}


def runtime_info(model=None):
    backend = generation_backend(model)
    current = start(model)
    return {'build': verify_installation(model), 'server': current, 'models': api('/v1/models', model=model),
            'system': api('/v1/system/info', model=model), 'model_sha256': sha256(backend.model_dir / backend.filename)}


def api_model_matches(response, model=None):
    """Recognize the serving alias without adopting or controlling its process.

    Each single-backend endpoint exposes the pinned native alias ``default``.
    Saved profiles select that endpoint and apply their own request settings;
    their names and IDs are not native model identities or launch receipts.
    """
    backend = generation_backend(model)
    if not isinstance(response, dict):
        return False
    rows = response.get('data')
    if (not isinstance(rows, list) or not rows
            or any(not isinstance(row, dict) or not isinstance(row.get('id'), str)
                   or not row['id'] for row in rows)):
        return False
    return any(row['id'] == backend.api_model for row in rows)


def model_matches(response, model=None):
    """Lifecycle readiness requires this workspace's owned, current launch."""
    backend = generation_backend(model)
    if not api_model_matches(response, backend):
        return False
    owned = owned_state(backend)
    if not owned:
        return False
    return launch_matches(owned, backend)
