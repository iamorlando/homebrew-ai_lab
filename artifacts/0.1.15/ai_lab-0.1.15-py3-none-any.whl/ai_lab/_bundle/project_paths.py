"""Runtime data may live outside an installed application bundle."""
import os
from pathlib import Path

RESOURCES = Path(__file__).resolve().parent
ROOT = Path(os.environ.get('DEEPSEEK_ROOT', RESOURCES)).expanduser().resolve()
