"""Merge uvx stdio configurations without relying on an unpublished package."""
import base64
import csv
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path
import shutil
import sys
import tomllib
import uuid
import zipfile

import tomlkit

from ai_lab import __version__
from ai_lab.credentials import sync_jev_key
from ai_lab.paths import BUNDLE, CHECKOUT, RESOURCES, state_path

CLIENTS = ('codex', 'claude', 'claude-desktop', 'cursor', 'opencode')
SERVER_NAME = 'ai-lab'


def atomic_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(f'.{path.name}.{uuid.uuid4().hex}.tmp')
    try:
        with temporary.open('xb') as stream:
            temporary.chmod(0o600); stream.write(data)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def package_metadata():
    if not BUNDLE.is_dir():
        project = tomllib.loads((CHECKOUT / 'pyproject.toml').read_text())['project']
        requires = list(project['dependencies'])
        extras = list(project.get('optional-dependencies', {}))
        for extra, dependencies in project.get('optional-dependencies', {}).items():
            requires.extend(f'{dependency}; extra == "{extra}"' for dependency in dependencies)
        return project['requires-python'], requires, extras
    metadata = importlib.metadata.distribution('ai-lab').metadata
    if metadata['Version'] != __version__:
        raise ValueError('Installed AI Lab metadata does not match its code. Reinstall the CLI before configuring MCP.')
    return metadata['Requires-Python'], metadata.get_all('Requires-Dist') or [], metadata.get_all('Provides-Extra') or []


def package_files():
    directory = Path(__file__).parent
    files = {}
    for path in directory.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            files['ai_lab/' + path.relative_to(directory).as_posix()] = path.read_bytes()
    if not BUNDLE.is_dir():
        mappings = tomllib.loads((CHECKOUT / 'pyproject.toml').read_text())['tool']['hatch']['build']['targets']['wheel']['force-include']
        for source, target in mappings.items():
            path = RESOURCES / source
            if path.is_dir():
                for child in path.rglob('*'):
                    if child.is_file() and '__pycache__' not in child.parts and child.suffix != '.pyc':
                        files[target + '/' + child.relative_to(path).as_posix()] = child.read_bytes()
            else:
                files[target] = path.read_bytes()
    return files


def stage_package(root):
    """Make a reproducible private wheel from the installed public app resources.

    uvx resolves this wheel's normal dependencies and MCP extra itself. It has no
    references to a Homebrew Cellar or development venv, and includes no models,
    workspace state, credentials or saved prompts.
    """
    files = package_files()
    python, requires, extras = package_metadata()
    metadata = ['Metadata-Version: 2.4', 'Name: ai-lab', f'Version: {__version__}',
                'Summary: AI Lab local model and watermark tools', f'Requires-Python: {python}']
    metadata.extend(f'Provides-Extra: {extra}' for extra in extras)
    metadata.extend(f'Requires-Dist: {requirement}' for requirement in requires)
    info = f'ai_lab-{__version__}.dist-info'
    files[info + '/METADATA'] = ('\n'.join(metadata) + '\n\n').encode()
    files[info + '/WHEEL'] = b'Wheel-Version: 1.0\nGenerator: ai-lab-mcp-install\nRoot-Is-Purelib: true\nTag: py3-none-any\n'
    files[info + '/entry_points.txt'] = b'[console_scripts]\nai-lab = ai_lab.cli:main\nai-lab-mcp = ai_lab.mcp_server:main\n'
    record = io.StringIO(newline='')
    writer = csv.writer(record)
    for name, data in sorted(files.items()):
        digest = base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b'=').decode()
        writer.writerow([name, 'sha256=' + digest, len(data)])
    writer.writerow([info + '/RECORD', '', ''])
    files[info + '/RECORD'] = record.getvalue().encode()
    archive = io.BytesIO()
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as wheel:
        for name, data in sorted(files.items()):
            member = zipfile.ZipInfo(name, (2020, 1, 1, 0, 0, 0))
            member.compress_type = zipfile.ZIP_DEFLATED
            member.external_attr = 0o644 << 16
            wheel.writestr(member, data)
    data = archive.getvalue()
    digest = hashlib.sha256(data).hexdigest()
    path = state_path(root) / 'mcp-package' / digest[:20] / f'ai_lab-{__version__}-py3-none-any.whl'
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        atomic_write(path, data)
    return path.resolve()


def launch_config(root, package=None):
    root = Path(root).resolve()
    if package is None:
        package = 'ai-lab[mcp] @ ' + stage_package(root).as_uri()
    return {'command': shutil.which('uvx') or 'uvx',
            'args': ['--python', '3.13', '--from', package, 'ai-lab-mcp', '--root', str(root)],
            'env': {'AI_LAB_ROOT': str(root)}}


def target_path(client, root, scope='user'):
    home = Path.home()
    if scope == 'project':
        if client == 'codex': return Path(root) / '.codex/config.toml'
        if client == 'claude': return Path(root) / '.mcp.json'
        if client == 'cursor': return Path(root) / '.cursor/mcp.json'
        raise ValueError('Project scope is supported for Codex, Claude Code and Cursor. Use user scope for this client.')
    if client == 'codex': return Path(os.environ.get('CODEX_HOME', home / '.codex')) / 'config.toml'
    if client == 'claude': return home / '.claude.json'
    if client == 'cursor': return home / '.cursor/mcp.json'
    if client == 'opencode': return Path(os.environ.get('XDG_CONFIG_HOME', home / '.config')) / 'opencode/opencode.json'
    if client == 'claude-desktop':
        if sys.platform == 'darwin': return home / 'Library/Application Support/Claude/claude_desktop_config.json'
        if sys.platform == 'win32': return Path(os.environ.get('APPDATA', home / 'AppData/Roaming')) / 'Claude/claude_desktop_config.json'
        return home / '.config/Claude/claude_desktop_config.json'
    raise ValueError('Unsupported MCP client.')


def client_entry(client, launch):
    entry = dict(launch)
    if client == 'codex':
        entry.update(startup_timeout_sec=120, tool_timeout_sec=3600)
    elif client == 'claude': entry['type'] = 'stdio'
    elif client == 'opencode':
        entry = {'type': 'local', 'command': [launch['command'], *launch['args']],
                 'environment': launch['env'], 'enabled': True, 'timeout': 120000}
    return entry


def configure(root, client, *, config_file=None, scope='user', package=None, force=False, dry_run=False):
    if client not in CLIENTS: raise ValueError('Unsupported MCP client.')
    root = Path(root).resolve()
    launch = launch_config(root, package)
    entry = client_entry(client, launch)
    path = Path(config_file).expanduser().resolve() if config_file else target_path(client, root, scope)
    if path.is_symlink(): path = path.resolve()
    text = path.read_text(encoding='utf-8-sig') if path.exists() else ''
    if client == 'codex':
        try: document = tomlkit.parse(text)
        except Exception as error: raise ValueError(f'{path} is not valid TOML; its contents were left untouched.') from error
        section = document.setdefault('mcp_servers', tomlkit.table())
    else:
        try: document = json.loads(text) if text else {}
        except ValueError as error: raise ValueError(f'{path} is not valid JSON; its contents were left untouched.') from error
        if not isinstance(document, dict): raise ValueError(f'{path} must contain a JSON object; left untouched.')
        section = document.setdefault('mcp' if client == 'opencode' else 'mcpServers', {})
    if not isinstance(section, dict): raise ValueError(f'The MCP section in {path} is invalid; left untouched.')
    existing = section.get(SERVER_NAME)
    if existing == entry:
        if not dry_run: sync_jev_key(root)
        return {'client': client, 'path': str(path), 'status': 'already_configured', 'entry': entry}
    if existing is not None and not force:
        raise ValueError(f'{path} already has a different ai-lab MCP entry. Use --force to replace only that entry.')
    section[SERVER_NAME] = entry
    updated = tomlkit.dumps(document) if client == 'codex' else json.dumps(document, ensure_ascii=False, indent=2) + '\n'
    result = {'client': client, 'path': str(path), 'status': 'planned' if dry_run else 'installed', 'entry': entry,
              'restart': 'Restart the target client to load its new stdio MCP server.',
              'models': 'Local APIs are started separately with ai-lab services. Jev is hosted.'}
    if not dry_run:
        sync_jev_key(root)
        if path.exists():
            backup = path.with_name(path.name + '.bak-' + uuid.uuid4().hex[:12])
            atomic_write(backup, path.read_bytes())
            result['backup'] = str(backup)
        atomic_write(path, updated.encode())
    return result
