"""Chat UI adapter for the committed native transport and genuine MCP connector."""
import asyncio
from copy import deepcopy
import json
import os

from ai_lab.agent_types import TurnResult
from ai_lab.mcp_client import MCPClient, MCPClientError, ToolTurn, ai_lab_client, load_mcp_config
from ai_lab.native_chat import NativeChat
from ai_lab.paths import load_backend


PLAIN_SYSTEM = ('You are a local AI Lab chat assistant. Preserve the conversation context and answer clearly. '
                'Explain local API failures; do not use a hosted provider or invent results.')
SYSTEM = (PLAIN_SYSTEM + ' The supplied functions are live and execute after approval. '
          'When a function is requested or useful, make one direct call and stop. '
          'Begin the call immediately with the exact prefix <tool_call>{"name": '
          'and complete the JSON object with the declared function name and an "arguments" JSON object. '
          'Keep nested arguments as JSON objects and close the call with }</tool_call>. '
          'Begin with that prefix, with no preceding explanation or deliberation. '
          'Then stop and wait: the next request will contain the actual result as a role=tool message. '
          'Only after that result, answer using its returned data. Never simulate a call or predict its result. '
          'For built-in decision tools, specify model="contrastive" (native CLM) unless the user chooses another local provider.')


class AgentBackend:
    def __init__(self, root, *, model=None, model_name=None, scheme=None, settings=None,
                 seed=None, temperature=.8, max_tokens=1024, timeout=180,
                 self_mcp=False, external_config=None, allow_tools=(),
                 tool_choice='auto', chat=None, client_factory=None, mcp_env=None):
        if model is not None and model_name is not None:
            raise ValueError('Select only --name or --model.')
        if allow_tools and not self_mcp:
            raise ValueError('--allow-tool requires --self-mcp; external approvals use their explicit config.')
        if not .05 <= timeout <= 300:
            raise ValueError('Agent request timeout must be between .05 and 300 seconds.')
        if tool_choice not in {'auto', 'required'}:
            raise ValueError('Tool choice must be auto or required.')
        self.tools_enabled = bool(self_mcp or external_config is not None or client_factory is not None)
        if tool_choice == 'required' and not self.tools_enabled:
            raise ValueError('Required tools need an MCP connection: use --self-mcp or --mcp-config.')
        self.tool_choice = tool_choice
        self.root = root
        load_backend(root)
        self.chat = chat or NativeChat(root, model=model, model_name=model_name,
                                       scheme=None if scheme == 'model' else scheme,
                                       settings=settings, seed=seed, temperature=temperature,
                                       max_tokens=max_tokens, timeout=timeout)
        self.selection = deepcopy(self.chat.selection)
        self.backend_label = self.selection['underlying_model']
        profile_label = None
        if self.selection.get('profile_key'):
            from model_profiles import ModelProfiles
            profile_label = ModelProfiles(root).supported_profiles()[self.selection['profile_key']]['name']
        self.profile_label = profile_label or self.backend_label
        self.watermark_label = (self.selection.get('watermark') or {}).get('scheme', 'none')
        self.timeout = timeout
        self.last_result = None
        self.last_messages = None
        self._closed = False
        self._client = None
        self._client_lock = asyncio.Lock()
        if client_factory is not None:
            self._client_factory = client_factory
        elif self_mcp:
            local_env = {name: os.environ[name] for name in
                         ('AI_LAB_LAYA_URL', 'AI_LAB_DECISIONS_URL', 'AI_LAB_CLM_UPSTREAM_URL')
                         if name in os.environ}
            local_env.update(mcp_env or {})
            self._client_factory = lambda: ai_lab_client(root, external_config=external_config,
                                                        allow_tools=allow_tools, offline=True, env=local_env)
        elif external_config is not None:
            configs = load_mcp_config(external_config)
            self._client_factory = lambda: MCPClient(configs)
        else:
            self._client_factory = None

    async def _connect(self):
        async with self._client_lock:
            if self._closed:
                raise ValueError('Chat agent is closed.')
            if self._client is None:
                client = self._client_factory()
                await client.__aenter__()
                self._client = client
            return self._client

    async def _disconnect(self):
        async with self._client_lock:
            if self._client is not None:
                client, self._client = self._client, None
                await client.aclose()

    async def __call__(self, messages, events):
        if self._closed:
            raise ValueError('Chat agent is closed.')
        if not messages or messages[-1].get('role') != 'user':
            raise ValueError('A user message is required.')
        if len(messages[-1].get('content', '')) > 24000:
            raise ValueError('The message exceeds 24,000 characters.')
        choice = events.tool_choice if events.tool_choice is not None else self.tool_choice
        if choice not in {'auto', 'required'}:
            raise ValueError('Tool choice must be auto or required.')
        if choice == 'required' and not self.tools_enabled:
            raise ValueError('Required tools need an MCP connection: use --self-mcp or --mcp-config.')
        sent = [{'role': 'system', 'content': SYSTEM if self._client_factory else PLAIN_SYSTEM}] + deepcopy(messages)
        first_completion = True

        async def complete(history, tools):
            nonlocal first_completion
            request_choice = choice if first_completion else 'auto'
            if request_choice == 'required' and not tools:
                raise MCPClientError('Required tools need at least one discovered MCP tool; no native request sent.')
            first_completion = False
            events.status(f'Waiting for {self.backend_label}…')
            try:
                message = await self.chat.complete(history, tools, tool_choice=request_choice)
            except ValueError as error:
                # Preserve public native API guidance through ToolTurn.
                raise MCPClientError(str(error)) from None
            self.last_result = deepcopy(self.chat.last_result)
            if request_choice == 'required' and not message.get('tool_calls'):
                raise MCPClientError('Required turn returned no native tool calls; no tool was dispatched.')
            return message

        async def approve(request):
            events.status(f'Approval required for {request["server"]}: {request["tool"]}')
            return await events.approve(f'{request["server"]}: {request["tool"]}\n'
                                        + json.dumps(request['arguments'], ensure_ascii=False, indent=2))

        try:
            if self._client_factory is None:
                answer = await complete(sent, [])
                continuation = [answer]
            else:
                events.status('Connecting MCP tools…')
                client = await self._connect()
                turn = ToolTurn(client, sent, complete, completion_timeout=self.timeout)
                result = await turn.run(approve=approve)
                if result['status'] != 'completed':
                    raise ValueError(result.get('error', 'Tool turn did not complete.'))
                continuation = result['messages'][len(sent):]
            answer = continuation[-1].get('content')
            if not isinstance(answer, str) or not answer.strip():
                raise ValueError('The native model did not return a final assistant answer.')
            self.last_messages = deepcopy(continuation)
            return TurnResult(answer, continuation)
        except asyncio.CancelledError:
            # Stop awaits connector shutdown, including pending approvals/tools.
            # A later user turn opens a new owned client; no action is replayed.
            await self._disconnect()
            raise

    async def aclose(self):
        self._closed = True
        try:
            await self._disconnect()
        finally:
            await self.chat.aclose()
