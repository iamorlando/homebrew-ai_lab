"""Owned stdio MCP sessions and resumable, approval-aware tool continuation.

This module has no generation-backend dependency. Hosts supply actual assistant
messages through a completion callback; plain text is never parsed as tool calls.
"""
import asyncio
from collections.abc import Mapping
from contextlib import AsyncExitStack
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import timedelta
import hashlib
import inspect
import json
import logging
import math
import os
from pathlib import Path
import re
import sys
import tempfile
from types import MappingProxyType

from jsonschema import validators
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from ai_lab.decision_descriptions import LOCAL_DECISION_DESCRIPTIONS, LOCAL_DECISION_POLICY
from ai_lab.paths import CHECKOUT
from ai_lab.mcp_schema import TransportSchemaError, transport_schema

_NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}\Z')
_ENV = re.compile(r'[A-Za-z_][A-Za-z0-9_]*\Z')
_REFERENCE = re.compile(r'\$\{([A-Za-z_][A-Za-z0-9_]*)\}')
LOCAL_DECISIONS = ('contrastive', 'clm-upstream', 'laya')


class MCPClientError(ValueError):
    """A public, credential-free connector failure."""


def _json_copy(value, limit=1024 * 1024):
    data = json.dumps(value, ensure_ascii=False, allow_nan=False)
    if len(data.encode('utf-8')) > limit:
        raise MCPClientError('MCP data exceeds the configured size limit.')
    return json.loads(data)


def _timeout(value):
    if type(value) not in (int, float) or not math.isfinite(value) or not .05 <= value <= 300:
        raise MCPClientError('MCP timeout_seconds must be between 0.05 and 300.')
    return float(value)


def _local_refs(value, depth=0):
    if depth > 64:
        raise MCPClientError('MCP schema nesting exceeds the limit.')
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {'$ref', '$dynamicRef', '$recursiveRef'} and (
                    not isinstance(child, str) or not child.startswith('#')):
                raise MCPClientError('MCP schemas may only use local references.')
            _local_refs(child, depth + 1)
    elif isinstance(value, list):
        for child in value:
            _local_refs(child, depth + 1)


@dataclass(frozen=True)
class ServerConfig:
    name: str
    command: str = field(repr=False)
    args: tuple[str, ...] = field(default=(), repr=False)
    env: Mapping[str, str] = field(default_factory=dict, repr=False)
    cwd: str | None = field(default=None, repr=False)
    timeout_seconds: float = 30
    allow_tools: frozenset[str] = field(default_factory=frozenset)
    local_decisions_only: bool = False
    private_env: frozenset[str] | None = field(default=None, repr=False)
    private_values: tuple[str, ...] = field(default=(), repr=False)

    def __post_init__(self):
        if not isinstance(self.name, str) or not _NAME.fullmatch(self.name):
            raise MCPClientError('MCP server names must be 1–64 letters, digits, dots, underscores or hyphens.')
        if not isinstance(self.command, str) or not self.command.strip() or '\0' in self.command:
            raise MCPClientError('MCP server command must be a nonempty string.')
        if not isinstance(self.args, (list, tuple)) or any(not isinstance(v, str) or '\0' in v for v in self.args):
            raise MCPClientError('MCP server args must be a list of strings.')
        if not isinstance(self.env, Mapping) or any(not isinstance(k, str) or not _ENV.fullmatch(k) or
                not isinstance(v, str) or '\0' in v for k, v in self.env.items()):
            raise MCPClientError('MCP environment must map variable names to strings.')
        if self.cwd is not None and (not isinstance(self.cwd, str) or '\0' in self.cwd):
            raise MCPClientError('MCP cwd must be a path string.')
        if not isinstance(self.allow_tools, (list, tuple, set, frozenset)) or any(
                not isinstance(v, str) or not v for v in self.allow_tools):
            raise MCPClientError('MCP allow_tools must contain exact tool names.')
        if type(self.local_decisions_only) is not bool:
            raise MCPClientError('MCP local_decisions_only must be boolean.')
        if not isinstance(self.private_values, (list, tuple)) or any(
                not isinstance(v, str) for v in self.private_values):
            raise MCPClientError('MCP private values must be strings.')
        if self.private_env is not None and (not isinstance(self.private_env, (set, frozenset)) or
                any(not isinstance(k, str) for k in self.private_env)):
            raise MCPClientError('MCP private_env must be a set of variable names.')
        _timeout(self.timeout_seconds)
        object.__setattr__(self, 'args', tuple(self.args))
        object.__setattr__(self, 'env', MappingProxyType(dict(self.env)))
        object.__setattr__(self, 'allow_tools', frozenset(self.allow_tools))
        object.__setattr__(self, 'private_values', tuple(self.private_values))
        if self.private_env is not None:
            object.__setattr__(self, 'private_env', frozenset(self.private_env))


def load_mcp_config(path, *, environ=None):
    """Read explicit JSON mcpServers config; never rewrite it or log its values."""
    environ = os.environ if environ is None else environ
    path = Path(path).expanduser().resolve()
    try:
        if path.stat().st_size > 1024 * 1024:
            raise MCPClientError('MCP configuration exceeds 1 MiB.')
        document = json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError) as error:
        if isinstance(error, MCPClientError):
            raise
        raise MCPClientError('Cannot read MCP configuration as a JSON object.') from None
    if not isinstance(document, dict) or not isinstance(document.get('mcpServers'), dict):
        raise MCPClientError('MCP configuration must contain an mcpServers object.')
    result = []
    for name, entry in document['mcpServers'].items():
        if not isinstance(entry, dict):
            raise MCPClientError('Each MCP server entry must be an object.')
        if type(entry.get('disabled', False)) is not bool:
            raise MCPClientError('MCP disabled must be boolean.')
        if entry.get('disabled', False):
            continue
        if entry.get('type', 'stdio') != 'stdio' or 'url' in entry:
            raise MCPClientError('Only local stdio MCP servers are supported.')
        environment = entry.get('env', {})
        if not isinstance(environment, dict):
            raise MCPClientError('MCP env must be an object.')
        resolved, private_values = {}, []
        for key, value in environment.items():
            if not isinstance(value, str):
                raise MCPClientError('MCP environment values must be strings.')
            def replace(match):
                variable = match.group(1)
                if variable not in environ:
                    raise MCPClientError(f'MCP environment variable {variable} is missing.')
                if not isinstance(environ[variable], str):
                    raise MCPClientError('Referenced MCP environment values must be strings.')
                private_values.append(environ[variable])
                return environ[variable]
            resolved[key] = _REFERENCE.sub(replace, value)
        cwd = entry.get('cwd')
        if cwd is not None and not isinstance(cwd, str):
            raise MCPClientError('MCP cwd must be a path string.')
        directory = Path(cwd).expanduser() if cwd is not None else path.parent
        if not directory.is_absolute():
            directory = path.parent / directory
        result.append(ServerConfig(name, entry.get('command'), entry.get('args', ()), resolved,
                     str(directory.resolve()), entry.get('timeout_seconds', 30),
                     entry.get('allow_tools', ()), private_values=tuple(private_values)))
    return tuple(result)


def self_server_config(root, *, allow_tools=(), offline=True, env=None):
    """Launch this source/installed version's OWN server with an explicit data root.

    Offline discovery requires an explicit local decision provider in decision
    tool arguments. It does not start that provider or any generation model.
    """
    environment = dict(env or {})
    public_env = {'AI_LAB_ROOT', 'PYTHONPATH', 'AI_LAB_LAYA_URL',
                  'AI_LAB_DECISIONS_URL', 'AI_LAB_CLM_UPSTREAM_URL'}
    environment.update(AI_LAB_ROOT=str(Path(root).expanduser().resolve()), PYTHONPATH=str(CHECKOUT))
    if offline:
        environment.update(TYPESAFE_API_KEY='', JEV_API_KEY='')
    return ServerConfig('ai-lab', sys.executable,
                        ('-m', 'ai_lab.mcp_server', '--root', environment['AI_LAB_ROOT']),
                        environment, str(CHECKOUT), 30, frozenset(allow_tools), offline,
                        frozenset(environment) - public_env)


def ai_lab_client(root, *, external_config=None, allow_tools=(), offline=True, env=None):
    """Built-in self-MCP plus optional external servers; no config needed for self."""
    configs = (self_server_config(root, allow_tools=allow_tools, offline=offline, env=env),)
    if external_config is not None:
        configs += load_mcp_config(external_config)
    return MCPClient(configs)


class MCPClient:
    """Async context manager; a dedicated task owns every SDK context and child."""

    def __init__(self, servers, *, max_tools=256, max_pages=32, max_result_bytes=1024 * 1024):
        self._configs = tuple(servers)
        if len(self._configs) > 8 or any(not isinstance(c, ServerConfig) for c in self._configs):
            raise MCPClientError('Configure at most eight MCP servers.')
        if len({c.name for c in self._configs}) != len(self._configs):
            raise MCPClientError('MCP server names must be unique; ai-lab is reserved for self-MCP.')
        for value in (max_tools, max_pages, max_result_bytes):
            if type(value) is not int or value < 1:
                raise MCPClientError('MCP limits must be positive integers.')
        self.max_tools, self.max_pages, self.max_result_bytes = max_tools, max_pages, max_result_bytes
        secrets = {v for c in self._configs for k, v in c.env.items()
                   if v and (c.private_env is None or k in c.private_env)} | {
                   v for c in self._configs for v in c.private_values if v}
        # JSON text results and SDK validation logs can contain escaped values.
        self._secrets = sorted(secrets | {json.dumps(v, ensure_ascii=True)[1:-1] for v in secrets} |
                               {json.dumps(v, ensure_ascii=False)[1:-1] for v in secrets} |
                               {repr(v)[1:-1] for v in secrets}, key=len, reverse=True)
        self._sessions, self._routes = {}, {}
        self._model_schemas = {}
        self._runner = None
        self._ready = None
        self._stop = asyncio.Event()
        self._closing = False
        self._close_task = None
        self._calls = set()

    def _redact(self, value):
        if isinstance(value, str):
            # Preserve JSON numbers and syntax in text-only structured results.
            try:
                decoded = json.loads(value)
            except (ValueError, RecursionError):
                decoded = None
            if isinstance(decoded, (dict, list)):
                return json.dumps(self._redact(decoded), ensure_ascii=False, allow_nan=False)
            for secret in self._secrets:
                value = value.replace(secret, '[redacted]')
            return value
        if isinstance(value, dict):
            return {self._redact(k): self._redact(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._redact(v) for v in value]
        return value

    def _message(self, message):
        result = {key: self._redact(value) for key, value in message.items()}
        # Protocol identity is not credential data, even if a short env value
        # coincidentally appears in a role, opaque tool name or call ID.
        for key in ('role', 'tool_call_id'):
            if key in message:
                result[key] = message[key]
        if isinstance(message.get('tool_calls'), list):
            calls = []
            for call in message['tool_calls']:
                if not isinstance(call, dict):
                    calls.append(call)
                    continue
                redacted = {key: self._redact(value) for key, value in call.items()}
                for key in ('id', 'type'):
                    if key in call:
                        redacted[key] = call[key]
                function = call.get('function')
                if isinstance(function, dict):
                    redacted['function'] = {key: self._redact(value) for key, value in function.items()}
                    if 'name' in function:
                        redacted['function']['name'] = function['name']
                calls.append(redacted)
            result['tool_calls'] = calls
        return result

    def _public_schema(self, schema):
        """Redact annotations without changing parameter or constraint identity.

        Structural JSON Schema tokens (e.g. type=string) are protocol, not
        credential payloads. Sensitive arbitrary constraints/parameter names
        cannot be replaced safely, so discovery fails rather than lying.
        """
        def sensitive(value):
            if isinstance(value, str):
                return any(secret in value for secret in self._secrets)
            if isinstance(value, dict):
                return any(sensitive(k) or sensitive(v) for k, v in value.items())
            if isinstance(value, list):
                return any(sensitive(v) for v in value)
            return False

        maps = {'properties', 'patternProperties', '$defs', 'definitions', 'dependentSchemas'}
        single = {'additionalProperties', 'unevaluatedProperties', 'propertyNames', 'items',
                  'additionalItems', 'unevaluatedItems', 'contains', 'not', 'if', 'then', 'else', 'contentSchema'}
        arrays = {'allOf', 'anyOf', 'oneOf', 'prefixItems'}
        def visit(node):
            if not isinstance(node, dict):
                return deepcopy(node)
            result = {}
            for keyword, value in node.items():
                if keyword in {'title', 'description', '$comment', 'examples'}:
                    result[keyword] = self._redact(value)
                elif keyword == 'default' and sensitive(value):
                    continue
                elif keyword == 'type':
                    result[keyword] = deepcopy(value)
                elif keyword in maps and isinstance(value, dict):
                    if any(sensitive(name) for name in value):
                        raise MCPClientError('MCP schema contains private parameter identity; discovery refused.')
                    result[keyword] = {name: visit(child) for name, child in value.items()}
                elif keyword in single:
                    result[keyword] = [visit(child) for child in value] if isinstance(value, list) else visit(value)
                elif keyword in arrays and isinstance(value, list):
                    result[keyword] = [visit(child) for child in value]
                else:
                    if sensitive(keyword) or sensitive(value):
                        raise MCPClientError('MCP schema contains private constraints; discovery refused.')
                    result[keyword] = deepcopy(value)
            return result
        result = visit(schema)
        validators.validator_for(result).check_schema(result)
        return result

    async def __aenter__(self):
        if self._runner is not None or self._closing:
            raise MCPClientError('An MCP client context can only be entered once.')
        self._ready = asyncio.get_running_loop().create_future()
        self._runner = asyncio.create_task(self._own_sessions())
        try:
            await asyncio.shield(self._ready)
        except BaseException:
            if not self._ready.done():
                self._ready.cancel()
            await self.aclose()
            raise
        return self

    async def __aexit__(self, *exception):
        await self.aclose()

    async def _own_sessions(self):
        current = None
        client = self
        class PrivateLogFilter(logging.Filter):
            def filter(self, record):
                message = record.getMessage()
                if record.exc_info:
                    message += '\n' + logging.Formatter().formatException(record.exc_info)
                record.msg, record.args = client._redact(message), ()
                record.exc_info, record.exc_text = None, None
                return True
        log_filter = PrivateLogFilter()
        loggers = [logging.getLogger(name) for name in
                   ('mcp.client.stdio', 'mcp.client.session', 'mcp.shared.session')]
        for logger in loggers:
            logger.addFilter(log_filter)
        try:
            async with AsyncExitStack() as stack:
                for config in self._configs:
                    current = config.name
                    # Server stderr is private, even if the server prints its credentials.
                    errlog = stack.enter_context(tempfile.TemporaryFile(mode='w+'))
                    read, write = await stack.enter_async_context(stdio_client(StdioServerParameters(
                        command=config.command, args=list(config.args), env=dict(config.env), cwd=config.cwd), errlog=errlog))
                    session = await stack.enter_async_context(ClientSession(
                        read, write, read_timeout_seconds=timedelta(seconds=config.timeout_seconds)))
                    self._sessions[config.name] = session
                    async with asyncio.timeout(config.timeout_seconds):
                        await session.initialize()
                        cursor, seen = None, set()
                        for _ in range(self.max_pages):
                            page = await session.list_tools(cursor=cursor)
                            for tool in page.tools:
                                self._add_tool(config, tool)
                            cursor = page.nextCursor
                            if cursor is None:
                                break
                            if cursor in seen:
                                raise MCPClientError('MCP discovery returned a repeated page cursor.')
                            seen.add(cursor)
                        else:
                            raise MCPClientError('MCP discovery exceeds the page limit.')
                if not self._ready.done():
                    self._ready.set_result(None)
                await self._stop.wait()
        except asyncio.CancelledError:
            if not self._ready.done():
                self._ready.cancel()
        except Exception as error:
            if not self._ready.done():
                # SDK task groups wrap a discovery refusal in ExceptionGroups.
                # Expose only our credential-free errors, never SDK/server text.
                pending, failure = [error], None
                for _ in range(64):
                    if not pending:
                        break
                    candidate = pending.pop()
                    if isinstance(candidate, MCPClientError):
                        failure = str(candidate)
                        break
                    if isinstance(candidate, BaseExceptionGroup):
                        pending.extend(candidate.exceptions)
                message = f'Cannot initialize MCP server {current or "configuration"}'
                message += f': {failure}' if failure else '; check the command, protocol and timeout.'
                self._ready.set_exception(MCPClientError(self._redact(message)))
        finally:
            for logger in loggers:
                logger.removeFilter(log_filter)
            self._sessions.clear()
            self._closing = True

    def _add_tool(self, config, tool):
        schema = _json_copy(tool.inputSchema, 256 * 1024)
        description = tool.description or ''
        output = tool.outputSchema
        _local_refs(schema)
        if output is not None:
            _local_refs(_json_copy(output, 256 * 1024))
        if config.local_decisions_only and tool.name in {'answer_decisions', 'rank_decisions'}:
            schema.setdefault('properties', {})['model'] = {'type': 'string', 'enum': list(LOCAL_DECISIONS)}
            schema['required'] = list(dict.fromkeys([*schema.get('required', []), 'model']))
            # This connection requires an explicit local provider. Retaining the
            # server's hosted-default prose would contradict that enforced view.
            description = LOCAL_DECISION_DESCRIPTIONS[tool.name]
        validator = validators.validator_for(schema)
        validator.check_schema(schema)
        safe = re.sub(r'[^A-Za-z0-9_]', '_', self._redact(tool.name))[:30]
        digest = hashlib.sha256(json.dumps([config.name, tool.name]).encode()).hexdigest()[:10]
        prefix = re.sub(r'[^A-Za-z0-9_]', '_', self._redact(config.name))[:20]
        name = f'{prefix}__{safe}_{digest}'
        if name in self._routes or len(self._routes) >= self.max_tools:
            raise MCPClientError('MCP discovery has duplicate tools or exceeds the tool limit.')
        public = {'name': name, 'server': config.name, 'tool': tool.name,
                  'description': description, 'inputSchema': schema,
                  'annotations': tool.annotations.model_dump(exclude_none=True) if tool.annotations else {},
                  'requires_approval': tool.name not in config.allow_tools}
        public = {key: self._public_schema(value) if key == 'inputSchema' else self._redact(value)
                  for key, value in public.items()}
        # The opaque identifier is generated here; coincidental matches to short
        # env values (e.g. a flag "1" in the digest) must not break dispatch.
        public['name'] = name
        try:
            native_schema = transport_schema(public['inputSchema'])
        except TransportSchemaError as error:
            raise MCPClientError(str(error)) from None
        self._model_schemas[name] = native_schema
        self._routes[name] = (config, tool.name, validator(schema), public)

    def catalog(self):
        return deepcopy([route[3] for route in self._routes.values()])

    def model_tools(self):
        return [{'type': 'function', 'function': {'name': tool['name'], 'description': tool['description'],
                'strict': True, 'parameters': deepcopy(self._model_schemas[tool['name']])}}
                for tool in self.catalog()]

    async def aclose(self):
        # A caller's cancellation must not interrupt the shutdown sequence.
        caller = asyncio.current_task()
        if self._close_task is None:
            self._closing = True
            self._close_task = asyncio.create_task(self._cleanup(skip_task=caller if caller in self._calls else None))
        try:
            await asyncio.shield(self._close_task)
        except asyncio.CancelledError:
            # An approval callback may itself close the client. It must not
            # await a cleanup task which is waiting for that same operation.
            if caller in self._calls:
                raise
            await asyncio.shield(self._close_task)
            raise

    async def _cleanup(self, *, skip_task=None):
        self._closing = True
        if self._runner is not None and self._ready is not None and (
                not self._ready.done() or self._ready.cancelled()):
            self._runner.cancel()
        active = tuple(task for task in self._calls if task is not skip_task)
        for task in active:
            task.cancel()
        if active:
            await asyncio.gather(*active, return_exceptions=True)
        self._stop.set()
        if self._runner is not None:
            await self._runner

    @staticmethod
    def _error(code, message):
        return {'status': 'error', 'isError': True, 'content': [], 'structuredContent': None,
                'error': {'code': code, 'message': message}}

    async def call_tool(self, name, arguments=None, *, approve=None):
        """Return actual result, denied, or requires_approval. No implicit retries."""
        if self._closing:
            return self._error('closed', 'MCP client is closed or not connected.')
        # Own the complete operation, including an async approval wait. Closing
        # the client cancels it before an approval can dispatch a late call.
        task = asyncio.create_task(self._call_tool(name, arguments, approve=approve))
        self._calls.add(task)
        try:
            return await task
        finally:
            self._calls.discard(task)

    async def _call_tool(self, name, arguments=None, *, approve=None):
        if self._closing or not self._sessions:
            return self._error('closed', 'MCP client is closed or not connected.')
        if name not in self._routes:
            return self._error('unknown_tool', 'Choose a tool from MCP discovery.')
        config, remote, validator, public = self._routes[name]
        try:
            arguments = _json_copy({} if arguments is None else arguments, 64 * 1024)
            if not isinstance(arguments, dict):
                raise ValueError()
            validator.validate(arguments)
        except Exception:
            return self._error('invalid_arguments', 'Tool arguments do not match the discovered schema.')
        request = {**deepcopy(public), 'arguments': self._redact(arguments)}
        if public['requires_approval']:
            if approve is None:
                return {'status': 'requires_approval', 'isError': False, 'approval': request}
            try:
                async with asyncio.timeout(300):
                    accepted = approve(request)
                    if inspect.isawaitable(accepted):
                        accepted = await accepted
            except asyncio.CancelledError:
                raise
            except Exception:
                return self._error('approval_failed', 'Tool approval failed or timed out; tool was not called.')
            if accepted is not True:
                return {'status': 'denied', 'isError': True, 'content': [], 'structuredContent': None,
                        'error': {'code': 'approval_denied', 'message': 'The host denied this tool call.'}}
        if self._closing:
            return self._error('closed', 'MCP client closed before the tool call.')
        return await self._execute(config, remote, arguments)

    async def _execute(self, config, remote, arguments):
        try:
            async with asyncio.timeout(config.timeout_seconds):
                result = await self._sessions[config.name].call_tool(remote, arguments,
                    read_timeout_seconds=timedelta(seconds=config.timeout_seconds))
            data = _json_copy(result.model_dump(mode='json', by_alias=True, exclude_none=True), self.max_result_bytes)
            return {'status': 'error' if result.isError else 'ok', 'isError': bool(result.isError),
                'content': [{key: value if key == 'type' else self._redact(value)
                             for key, value in block.items()} for block in data.get('content', [])],
                'structuredContent': self._redact(data.get('structuredContent'))}
        except asyncio.CancelledError:
            raise
        except Exception as error:
            timeout = isinstance(error, TimeoutError) or getattr(getattr(error, 'error', None), 'code', None) == -32001
            return self._error('timeout' if timeout else 'tool_failed',
                'MCP tool timed out; it was not retried.' if timeout else
                'MCP tool failed, returned invalid data or disconnected; it was not retried.')


class ToolTurn:
    """One finite assistant turn, resumable after host approval without replay.

    complete(messages, tools) must return an actual OpenAI-style assistant
    message. Calling run() again after requires_approval resumes the same turn.
    """

    def __init__(self, client, messages, complete, *, max_rounds=8, max_calls=16, completion_timeout=180):
        if any(type(n) is not int or not 1 <= n <= 64 for n in (max_rounds, max_calls)):
            raise MCPClientError('Tool continuation limits must be integers between 1 and 64.')
        self.client, self.complete = client, complete
        messages = _json_copy(messages)
        if not isinstance(messages, list) or any(not isinstance(m, dict) for m in messages):
            raise MCPClientError('Conversation messages must be a list of message objects.')
        self.messages = [client._message(m) for m in messages]
        self.max_rounds, self.max_calls = max_rounds, max_calls
        self.completion_timeout = _timeout(completion_timeout)
        self._rounds = self._calls = self._index = 0
        self._pending, self._seen = [], set()
        self._terminal = None
        self._busy = False

    def _result(self, status, **extra):
        return {'status': status, 'messages': deepcopy(self.messages), **extra}

    def _record(self, call, result):
        self.messages.append({'role': 'tool', 'tool_call_id': call['id'],
                              'content': json.dumps(result, ensure_ascii=False, allow_nan=False)})

    def _assistant(self, value):
        value = _json_copy(value)
        if not isinstance(value, dict) or value.get('role') != 'assistant' or (
                value.get('content') is not None and not isinstance(value['content'], str)):
            raise MCPClientError('Completion must return an assistant message.')
        calls = [] if value.get('tool_calls') is None else value['tool_calls']
        if not isinstance(calls, list) or len(calls) + self._calls > self.max_calls:
            raise MCPClientError('Assistant tool calls exceed the call limit.')
        parsed, ids = [], set()
        for call in calls:
            if not isinstance(call, dict) or call.get('type') != 'function':
                raise MCPClientError('Assistant returned an invalid native tool call.')
            ident, function = call.get('id'), call.get('function')
            if not isinstance(ident, str) or not ident or ident in self._seen or ident in ids or not isinstance(function, dict):
                raise MCPClientError('Assistant tool-call IDs must be nonempty and unique.')
            name, args = function.get('name'), function.get('arguments')
            if name not in self.client._routes or not isinstance(args, str):
                raise MCPClientError('Assistant must select a discovered tool and JSON arguments.')
            try:
                args = _json_copy(json.loads(args), 64 * 1024)
                if not isinstance(args, dict):
                    raise ValueError()
            except (ValueError, TypeError):
                raise MCPClientError('Assistant tool arguments must be a JSON object.') from None
            ids.add(ident)
            parsed.append({'id': ident, 'name': name, 'arguments': args})
        self._seen.update(ids)
        self.messages.append(self.client._message(value))
        self._pending, self._index = parsed, 0

    async def run(self, *, approve=None):
        if self._busy:
            raise MCPClientError('This tool turn is already running.')
        if self._terminal is not None:
            return deepcopy(self._terminal)
        self._busy = True
        try:
            while True:
                while self._index < len(self._pending):
                    call = self._pending[self._index]
                    result = await self.client.call_tool(call['name'], call['arguments'], approve=approve)
                    if result['status'] == 'requires_approval':
                        return self._result('requires_approval', approval=result['approval'])
                    self._record(call, result)
                    self._calls += 1
                    self._index += 1
                self._pending = []
                if self._rounds >= self.max_rounds:
                    raise MCPClientError('Tool continuation reached the assistant-round limit.')
                self._rounds += 1
                async with asyncio.timeout(self.completion_timeout):
                    message = await self.complete(deepcopy(self.messages), self.client.model_tools())
                self._assistant(message)
                if not self._pending:
                    self._terminal = self._result('completed')
                    return deepcopy(self._terminal)
        except asyncio.CancelledError:
            for call in self._pending[self._index:]:
                self._record(call, self.client._error('cancelled',
                    'Turn cancelled; any in-flight action may have completed and will not be retried.'))
            self._terminal = self._result('cancelled')
            raise
        except Exception as error:
            message = str(error) if isinstance(error, MCPClientError) else 'Model completion failed or timed out.'
            self._terminal = self._result('error', error=self.client._redact(message))
            return deepcopy(self._terminal)
        finally:
            self._busy = False
