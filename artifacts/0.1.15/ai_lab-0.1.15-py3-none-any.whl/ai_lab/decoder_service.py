"""Read-only host for the website's actual model-aware decoder HTTP routes."""
from pathlib import Path

import httpx
from fastapi import FastAPI

from ai_lab.paths import load_backend


class DecoderError(ValueError):
    """Only public, key-free route messages may be shown by the UI."""


class DecoderService:
    def __init__(self, root, *, runtime=None):
        root = Path(root).resolve()
        if not (root / 'sources.json').is_file():
            raise ValueError('Choose an existing AI Lab workspace with --root or AI_LAB_ROOT; decoder never provisions a workspace.')
        load_backend(root)
        from ai_lab.coordination import WorkspaceLock
        from ai_lab.mcp_tools import LabTools
        from detection_lab import register_detection
        from model_profiles import ModelProfiles
        from watermark_runtime import WatermarkRuntime

        class ReadOnlyTools(LabTools):
            def __init__(self):
                # Deliberately skip prepare(): discovery must not provision or
                # migrate manifests/templates/profiles, or start Decisions APIs.
                self.root = root
                self.registry = ModelProfiles(root)
                self.runtime = runtime or WatermarkRuntime(allow_start=False)
                self.lock = WorkspaceLock(root)

            async def close(self):
                # WatermarkRuntime owns only per-request HTTP contexts. This
                # host does not instantiate LabTools' Decisions runtime.
                pass

        class IdleWatermarks:
            def require_idle(self):
                # This host owns no generation tasks. Shared workspace locking
                # serializes detection with other cooperating app processes.
                pass

        class IdleStore:
            async def require_idle(self):
                pass

        tools = ReadOnlyTools()
        if tools.runtime.allow_start:
            raise ValueError('Decoder runtime must use allow_start=False.')
        self.app = FastAPI(title='AI Lab decoder service')
        register_detection(self.app, lambda _: None, IdleStore(), IdleWatermarks(), root,
                           tools.registry, decoder_runtime=tools.runtime, decoder_tools=tools)
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=self.app),
                                       base_url='http://decoder.local', trust_env=False, timeout=180)
        self.closed = False

    async def _request(self, method, path, body=None):
        try:
            response = await self.client.request(method, path, json=body)
            value = response.json()
        except (httpx.HTTPError, ValueError):
            raise DecoderError('Decoder service is unavailable. Retry discovery or detection.') from None
        if response.is_error:
            # Routes intentionally suppress request-validation inputs and native
            # exception text. Never propagate arbitrary error objects/tracebacks.
            detail = value.get('detail') if isinstance(value, dict) else None
            raise DecoderError(detail if isinstance(detail, str) else 'Check text, model and detector options, then retry.')
        return value

    async def catalog(self):
        return await self._request('GET', '/api/decoder/models')

    async def detect(self, body):
        return await self._request('POST', '/api/decoder/detect', body)

    async def close(self):
        if not self.closed:
            self.closed = True
            try:
                await self.client.aclose()
            finally:
                await self.app.state.decoder_tools.close()
