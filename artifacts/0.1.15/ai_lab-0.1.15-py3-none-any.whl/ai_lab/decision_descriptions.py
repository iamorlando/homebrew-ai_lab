"""Shared MCP decision metadata; provider results and validation stay unchanged."""

LOCAL_DECISION_POLICY = (
    'Requires explicit model=laya, contrastive (native CLM) or clm-upstream. '
    'Uses only the selected already-running local API; there is no hosted default or fallback. '
    'Does not start or download models. '
)

_ANSWER_INPUT = (
    'Answer 1–64 typed questions about a text/JSON state. '
    'Each ID maps to {type: choice|score|noul, instructions, criteria}. '
    'Choice criteria are named options; score criteria are 2–10 ordered levels; noul asks yes/no. '
)

_ACTION_METADATA = (
    'rl_agent.act_probability, when present in a provider answer, is separate action-head metadata, '
    'never P(true) or an option/level probability. '
)

# The primary fields follow harness.decisions.validate_answers. Auxiliary-field
# details below are scoped to the pinned @receptron/laya 0.1.2 types/implementation;
# they are not promises about every provider's optional fields or calibration.
ANSWER_RESULT_SEMANTICS = (
    'Result semantics: for a noul question, report answers.<question_id>.noul as measured P(true). '
    'For choice, answers.<question_id>.choice is the selected option ID and '
    'answers.<question_id>.probabilities maps option IDs to their measured probabilities. '
    'For score, answers.<question_id>.score is the returned level score from 0 to levels-1 and '
    'answers.<question_id>.probabilities maps zero-based level IDs (strings) to their measured probabilities. '
    + _ACTION_METADATA
)

RANK_RESULT_SEMANTICS = (
    'Result semantics: ranked[].candidate is the original candidate, ranked[].prob is its measured '
    'choice probability, and ranked[].rank starts at 1 in descending probability order. '
    + _ACTION_METADATA
)

PUBLIC_DECISION_DESCRIPTIONS = {
    'answer_decisions': (
        _ANSWER_INPUT +
        'Defaults to hosted Jev; specify contrastive for native CLM. Its installed local API starts automatically when needed; models are never downloaded implicitly. '
        'Returns actual probabilities and usage, without fabricated explanations or fallback to another model. '
        + ANSWER_RESULT_SEMANTICS
    ),
    'rank_decisions': (
        "Rank 2–255 candidate answers/actions using the selected provider's structured choice API. "
        'Defaults to hosted Jev; specify contrastive for native CLM with automatic selected API startup and no implicit downloads. '
        'Returns the original candidates and measured probabilities. ' + RANK_RESULT_SEMANTICS
    ),
}

LOCAL_DECISION_DESCRIPTIONS = {
    'answer_decisions': (
        _ANSWER_INPUT + LOCAL_DECISION_POLICY +
        'Returns actual probabilities and usage without fabricated explanations. ' + ANSWER_RESULT_SEMANTICS
    ),
    'rank_decisions': (
        "Rank 2–255 candidate answers/actions using the selected local provider's structured choice API. "
        + LOCAL_DECISION_POLICY +
        'Returns the original candidates and measured probabilities. ' + RANK_RESULT_SEMANTICS
    ),
}
