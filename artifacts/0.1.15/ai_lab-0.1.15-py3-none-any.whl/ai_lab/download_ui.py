"""Noninteractive model-setup guidance and an in-place download progress display."""
from contextlib import contextmanager
from contextvars import ContextVar
import subprocess
import sys

from rich.console import Console, Group
from rich.live import Live
from rich.progress import (BarColumn, DownloadColumn, Progress, SpinnerColumn,
                           TaskProgressColumn, TextColumn, TimeRemainingColumn,
                           TransferSpeedColumn)
from rich.table import Column
from rich.text import Text

_active = ContextVar('ai_lab_download_display', default=None)


def size_label(size):
    return f'{size / 1e9:.2f} GB' if size >= 1e9 else f'{size / 1e6:.1f} MB'


def model_choice_label(row):
    label = row['label'].split(' (')[0]
    if row['missing_bytes']:
        return f"{label}  ·  {size_label(row['missing_bytes'])} weights missing at selected root"
    ready = row.get('dependencies_ready', row.get('installed', False))
    return f"{label}  ·  weights verified · {'ready' if ready else 'runtime setup required'}"


def model_details(row):
    lines = [f"{row['label'].split(' (')[0]}: {row['dependencies']}"]
    lines.extend(f"Missing: {f['path']} ({f['bytes']} bytes; {f['reason']})" for f in row.get('missing_files', []))
    lines.extend(f"Existing files may be at {r['root']} (size only, unverified). Inspect: {r['command']}"
                 for r in row.get('other_roots', []))
    return '\n'.join(lines)


def select_models(rows):
    """Legacy internal callers must supply explicit acceptance, never open a picker."""
    raise ValueError('Model setup requires explicit selection and --yes. Use ai-lab setup install MODEL --yes.')


class DownloadDisplay:
    def __init__(self, total=None, *, console=None, completion='Setup complete'):
        self.console = console or Console(file=sys.stderr)
        self.completion = completion
        self.total, self.completed = total, 0
        self.overall = Progress(TextColumn('Selected models'), BarColumn(), TaskProgressColumn(),
                                DownloadColumn(), console=self.console, auto_refresh=False)
        self.overall_id = self.overall.add_task('Models', total=total, visible=total is not None)
        columns = [TextColumn('{task.description}', table_column=Column(max_width=26, overflow='ellipsis', no_wrap=True)),
                   BarColumn(), DownloadColumn()]
        if self.console.width >= 80:
            columns += [TransferSpeedColumn(), TimeRemainingColumn()]
        self.file = Progress(*columns, console=self.console, auto_refresh=False)
        self.file_id = self.file.add_task('', total=None, visible=False)
        self.status = Progress(SpinnerColumn(), TextColumn('{task.description}'), console=self.console,
                               auto_refresh=False)
        self.status_id = self.status.add_task('Preparing downloads', total=None)
        self.live = Live(Group(Text('AI LAB  /  DOWNLOADS', style='bold cyan'), self.overall, self.file, self.status),
                         console=self.console, refresh_per_second=5, redirect_stdout=False, redirect_stderr=False)

    def __enter__(self):
        self.token = _active.set(self)
        if self.console.is_terminal:
            self.live.start(refresh=True)
        return self

    def __exit__(self, kind, error, traceback):
        try:
            self.phase(('Setup interrupted' if issubclass(kind, (KeyboardInterrupt, SystemExit)) else 'Setup failed')
                       if kind else self.completion, done=True)
            if self.console.is_terminal:
                self.live.stop()
        finally:
            _active.reset(self.token)

    def phase(self, label, *, done=False):
        self.status.update(self.status_id, description=label, total=1 if done else None,
                           completed=1 if done else 0)

    @contextmanager
    def transfer(self, label, total=None, *, completed=0, weights=False):
        self.file.reset(self.file_id, description=label, total=total, completed=completed, visible=True)
        self.phase(f'Downloading {label}' if completed < (total or float('inf')) else f'Checking {label}')
        base = self.completed
        def update(count):
            self.file.update(self.file_id, completed=count)
            if weights:
                self.overall.update(self.overall_id, completed=base + count)
        update(completed)
        yield update
        if weights:
            self.completed = base + (total or 0)
            self.overall.update(self.overall_id, completed=self.completed)


@contextmanager
def transfer(label, total=None, *, completed=0, weights=False):
    active = _active.get()
    if active:
        with active.transfer(label, total, completed=completed, weights=weights) as update:
            yield update
    else:
        with DownloadDisplay(completion='Download complete') as display, display.transfer(label, total, completed=completed) as update:
            yield update


def phase(label):
    if active := _active.get():
        active.phase(label)


def verification_phase(label, *, large=False):
    if active := _active.get():
        active.phase(label)
    elif large:
        print(label, file=sys.stderr, flush=True)


def copy_download(response, output, label, *, expected_size=None, size_error='Download exceeds its pinned size.'):
    total = expected_size
    if total is None:
        try:
            total = int(getattr(response, 'headers', {}).get('Content-Length', ''))
        except (ValueError, TypeError):
            pass
    count = 0
    with transfer(label, total) as update:
        while data := response.read(1024 * 1024):
            count += len(data)
            if expected_size is not None and count > expected_size:
                raise ValueError(size_error)
            output.write(data)
            update(count)
    return count


def run_dependency(command, root, label, **kwargs):
    """Keep package-manager chatter in a private log instead of scrolling the UI."""
    from ai_lab.paths import state_path
    path = state_path(root) / 'model-install.log'
    phase(label)
    with path.open('a') as log:
        path.chmod(0o600)
        log.write(f'\n{label}\n'); log.flush()
        try:
            return subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True, **kwargs)
        except subprocess.CalledProcessError as error:
            raise ValueError(f'{label} failed. See {path} for details.') from error
