"""Negotiate named sessions with the API that already owns the workspace.

Older private services and websites use ``model`` for both IDs and names.
Inspect their actual schema before a write; never retry a session mutation.
"""
from ai_lab.client import LabError


def session_input(schema):
    try:
        value = schema['paths']['/api/lab/sessions']['post']['requestBody']['content']['application/json']['schema']
        if '$ref' in value:
            reference = value['$ref']
            if not reference.startswith('#/components/schemas/'):
                raise ValueError
            value = schema['components']['schemas'][reference[len('#/components/schemas/'):]]
        if value.get('type') != 'object' or value.get('additionalProperties') is not False:
            raise ValueError
        return value
    except (KeyError, TypeError, AttributeError, ValueError):
        raise LabError('The existing API has an unsupported session schema. Restart it through its original '
                       'launcher, then reopen ai-lab completion.', 'incompatible_api') from None


def create_named_session(client, name, body, *, expected_key=None):
    """Keep modern exact names; translate only the known older model-only schema."""
    schema = session_input(client.request('GET', '/api/lab/schema'))
    properties, required = schema.get('properties', {}), schema.get('required', [])
    if not isinstance(properties, dict) or not isinstance(required, list):
        raise LabError('The existing API returned an invalid session schema.', 'incompatible_api')
    if ('model_name' in properties and 'model' in properties
            and isinstance(properties['model_name'], dict) and 'model' not in required
            and 'model_name' not in required):
        result = client.request('POST', '/api/lab/sessions', {'model_name': name, **body})
        if expected_key is not None:
            check_profile(result, expected_key, name)
        return result
    if (set(properties) != {'model', 'scheme', 'watermark', 'name', 'temperature'}
            or required != ['model'] or not isinstance(properties['model'], dict)
            or properties['model'].get('type') != 'string'):
        raise LabError('The existing API has an unsupported session selector. Restart it through its original '
                       'launcher, then reopen ai-lab completion.', 'incompatible_api')
    catalog = client.request('GET', '/api/lab/models')
    models = catalog.get('models') if isinstance(catalog, dict) else None
    if (not isinstance(models, list) or any(not isinstance(row, dict)
            or not isinstance(row.get('key'), str) or not row['key']
            or not isinstance(row.get('name'), str) for row in models)):
        raise LabError('The existing API returned an invalid saved-model catalog.', 'incompatible_api')
    matches = [row for row in models if row['name'] == name]
    if not matches:
        raise LabError('Unknown model name. Use ai-lab models list; --name requires the saved name, '
                       'including case.', 'api_error', 422)
    if len(matches) != 1:
        raise LabError('Ambiguous model name. Use ai-lab models list and select a unique name.',
                       'api_error', 422)
    key = matches[0]['key']
    if expected_key is not None and key != expected_key:
        raise LabError('The selected model changed. Refresh the model list and choose again.', 'api_error', 409)
    if len([row for row in models if row['key'] == key or row['name'] == key]) != 1:
        raise LabError('This older API cannot distinguish the selected profile ID from another model name. '
                       'Restart its original launcher after updating, then reopen ai-lab completion.',
                       'incompatible_api', 422)
    result = client.request('POST', '/api/lab/sessions', {'model': key, **body})
    check_profile(result, key, name)
    return result


def check_profile(result, key, name):
    if (not isinstance(result, dict) or not isinstance(result.get('id'), str) or not result['id']
            or result.get('model') != key
            or not isinstance(result.get('profile'), dict) or result['profile'].get('name') != name):
        raise LabError('The existing API returned an unexpected model profile. No completion was requested. '
                       'Restart its original launcher, then retry.', 'incompatible_api')
