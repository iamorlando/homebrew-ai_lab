"""Separate installed application resources from mutable user data."""
import os
import json
from pathlib import Path
import sys

CHECKOUT = Path(__file__).resolve().parent.parent
BUNDLE = Path(__file__).resolve().parent / '_bundle'
RESOURCES = BUNDLE if BUNDLE.is_dir() else CHECKOUT
_ROOT_ORIGINS = {}


def root_path(value=None):
    if value or os.environ.get('AI_LAB_ROOT'):
        root, origin = Path(value or os.environ['AI_LAB_ROOT']), '--root' if value else 'AI_LAB_ROOT'
    elif not BUNDLE.is_dir() and (CHECKOUT / 'sources.json').exists():
        root, origin = CHECKOUT, 'source-checkout'
    else:
        root = Path(os.environ.get('AI_LAB_HOME', Path.home() / '.local/share/ai-lab'))
        origin = 'AI_LAB_HOME' if os.environ.get('AI_LAB_HOME') else 'installed-default'
    root = root.expanduser().resolve()
    _ROOT_ORIGINS[str(root)] = origin
    return root


def root_details(root):
    """Unknown callers are explicit roots; only the installed default can reuse."""
    root = Path(root).expanduser().resolve()
    origin = _ROOT_ORIGINS.get(str(root), 'explicit')
    return {'root': str(root), 'root_origin': origin,
            'automatic_reuse': origin == 'installed-default'}


def known_model_roots(root):
    """Inspect exact supported locations, never crawl the user's home directory.

    An optional model-roots.json is a user-owned list of at most eight prior
    roots. It contains paths only, and is never populated from profile/secrets.
    """
    root = Path(root).expanduser().resolve()
    home = Path.home()
    candidates = [home / '.local/share/ai-lab', home / 'dev/deepseek', home / 'dev/ai_experiments']
    if not BUNDLE.is_dir() and (CHECKOUT / 'sources.json').is_file():
        candidates.append(CHECKOUT)
    record = root / '.state/ai-lab/model-roots.json'
    try:
        if not record.is_symlink() and record.stat().st_size <= 8192:
            prior = json.loads(record.read_text())
            if isinstance(prior, list) and len(prior) <= 8:
                candidates.extend(Path(p).expanduser() for p in prior
                                  if isinstance(p, str) and len(p) <= 4096 and Path(p).expanduser().is_absolute())
    except (OSError, ValueError):
        pass
    return list(dict.fromkeys(p.resolve() for p in candidates if p.resolve() != root and p.is_dir()))


def load_backend(root):
    os.environ['DEEPSEEK_ROOT'] = str(root)
    for path in (RESOURCES, RESOURCES / 'harness'):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))


def require_owned_path(root, relative):
    """Reject managed write paths through links before creating or chmodding.

    The explicitly selected root can itself resolve through a link. Below that
    root, each managed path component must be owned by this workspace; dangling
    and in-root links are custom overrides too and remain untouched.
    """
    root = Path(root).resolve()
    relative = Path(relative)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('Managed paths must be relative to the selected data root.')
    path = root
    for part in relative.parts:
        path = path / part
        if path.is_symlink():
            raise ValueError(f'Custom runtime/source override is preserved: {path} is a managed-path link. '
                             'Choose an owned data root before initializing or repairing it.')
    return path


def state_path(root):
    path = require_owned_path(root, '.state/ai-lab')
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    path.chmod(0o700)
    return path
