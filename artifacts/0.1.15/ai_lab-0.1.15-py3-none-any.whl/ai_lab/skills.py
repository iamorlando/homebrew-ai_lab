"""Explicit skill installation, wrapping the single shipped CLI guide."""
import argparse
from contextlib import contextmanager
import errno
import hashlib
from importlib.resources import files
import json
import os
from pathlib import Path
import stat
import uuid


AGENTS = ('codex', 'claude')
SCOPES = ('project', 'user')


def add_parser(subparsers):
    parser = subparsers.add_parser('skills', help='Install the advanced AI Lab skill for an explicit agent and scope')
    parser.add_argument('--json', action='store_true', default=argparse.SUPPRESS)
    actions = parser.add_subparsers(dest='action', required=True)
    install = actions.add_parser('install', help='Install the shipped CLI guide as an agent skill')
    install.add_argument('--json', action='store_true', default=argparse.SUPPRESS)
    install.add_argument('--agent', choices=AGENTS, required=True)
    install.add_argument('--scope', choices=SCOPES, required=True)
    install.add_argument('--project', help='Project directory for project scope (default: current directory)')
    install.add_argument('--path', help='Exact destination skill directory; overrides the standard scope path')
    install.add_argument('--force', action='store_true', help='Atomically replace a differing existing SKILL.md')
    return parser


def skill_document():
    # No duplicate template: this is the guide printed by ai-lab --skill.
    from ai_lab.cli import SKILL
    if not isinstance(SKILL, str) or not SKILL.strip():
        raise ValueError('The shipped AI Lab guide is empty.')
    metadata = files('ai_lab').joinpath('skill_metadata.md').read_text(encoding='utf-8')
    guide = SKILL.strip() + '\n'
    return (metadata.rstrip() + '\n\n' + guide).encode('utf-8'), hashlib.sha256(SKILL.encode('utf-8')).hexdigest()


def destination(agent, scope, *, project=None, path=None):
    if agent not in AGENTS or scope not in SCOPES:
        raise ValueError('Choose agent codex/claude and scope project/user explicitly.')
    if project is not None and scope != 'project':
        raise ValueError('--project applies only to project scope.')
    if path is not None:
        selected = Path(path).expanduser()
    else:
        base = Path(project).expanduser() if project is not None else (Path.cwd() if scope == 'project' else Path.home())
        selected = base / ('.agents' if agent == 'codex' else '.claude') / 'skills' / 'ai-lab'
    # Never resolve symlinks away before checking the destination boundary.
    selected = selected.absolute()
    if '..' in selected.parts:
        raise ValueError('The skill destination must not contain parent traversal (..).')
    return selected


@contextmanager
def _directory(path):
    """Walk/create components using no-follow directory descriptors.

    Every subsequent file operation stays relative to the opened destination,
    even if a pathname component is swapped during installation.
    """
    if os.name != 'posix' or not hasattr(os, 'O_NOFOLLOW'):
        raise ValueError('Safe atomic skill installation requires a POSIX filesystem.')
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    descriptor = os.open(path.anchor, flags)
    try:
        for component in path.parts[1:]:
            try:
                child = os.open(component, flags, dir_fd=descriptor)
            except FileNotFoundError:
                try:
                    os.mkdir(component, 0o700, dir_fd=descriptor)
                except FileExistsError:
                    pass
                child = os.open(component, flags, dir_fd=descriptor)
            except OSError as error:
                if error.errno in {errno.ELOOP, errno.ENOTDIR}:
                    raise ValueError('Skill destination components must be real directories, never symlinks.') from None
                raise
            os.close(descriptor)
            descriptor = child
        yield descriptor
    finally:
        os.close(descriptor)


def _existing(descriptor):
    try:
        file = os.open('SKILL.md', os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=descriptor)
    except FileNotFoundError:
        return None
    except OSError as error:
        if error.errno == errno.ELOOP:
            raise ValueError('Existing SKILL.md must be a regular file, never a symlink.') from None
        raise
    if not stat.S_ISREG(os.fstat(file).st_mode):
        os.close(file)
        raise ValueError('Existing SKILL.md must be a regular file.')
    with os.fdopen(file, 'rb') as stream:
        return stream.read()


def install_skill(agent, scope, *, project=None, path=None, force=False):
    target = destination(agent, scope, project=project, path=path)
    content, guide_sha256 = skill_document()
    with _directory(target) as directory:
        current = _existing(directory)
        if current == content:
            status = 'unchanged'
        else:
            if current is not None and not force:
                raise ValueError(f'{target / "SKILL.md"} differs from the shipped skill; use --force to replace it.')
            temporary = f'.ai-lab-{uuid.uuid4().hex}.tmp'
            file = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory)
            try:
                with os.fdopen(file, 'wb') as stream:
                    # Explicit mode also handles an unusually restrictive umask.
                    os.fchmod(stream.fileno(), 0o600)
                    stream.write(content)
                    stream.flush()
                    os.fsync(stream.fileno())
                try:
                    # link is an atomic no-clobber publish even under concurrent installs.
                    os.link(temporary, 'SKILL.md', src_dir_fd=directory, dst_dir_fd=directory, follow_symlinks=False)
                    status = 'installed'
                except FileExistsError:
                    current = _existing(directory)
                    if current == content:
                        status = 'unchanged'
                    elif not force:
                        raise ValueError(f'{target / "SKILL.md"} differs from the shipped skill; use --force to replace it.')
                    else:
                        os.replace(temporary, 'SKILL.md', src_dir_fd=directory, dst_dir_fd=directory)
                        status = 'replaced'
            finally:
                try:
                    os.unlink(temporary, dir_fd=directory)
                except FileNotFoundError:
                    pass
    return {'agent': agent, 'scope': scope, 'status': status, 'path': str(target / 'SKILL.md'),
            'guide_source': 'ai_lab.cli.SKILL', 'guide_sha256': guide_sha256,
            'skill_sha256': hashlib.sha256(content).hexdigest()}


def run(args, root):
    result = install_skill(args.agent, args.scope, project=getattr(args, 'project', None),
                           path=getattr(args, 'path', None), force=getattr(args, 'force', False))
    if getattr(args, 'json', False):
        print(json.dumps(result))
    else:
        print(f"{result['status']}: {result['path']}")
    return 0
