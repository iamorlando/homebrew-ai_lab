"""MCP operations use shared validation and direct model APIs, never a daemon."""
import asyncio
from copy import deepcopy
import json
from pathlib import Path
import time
import uuid

from fastapi import HTTPException

from ai_lab.coordination import WorkspaceLock, website_model_write
from ai_lab.downloads import DEFAULT_MODELS, install
from ai_lab.model_servers import available_models
from ai_lab.paths import load_backend
from ai_lab.service import atomic_json
from ai_lab.setup import prepare


def public(value):
    """Hide watermark keys in ordinary results; explicit config retrieval opts in."""
    if isinstance(value, dict):
        result = {key: public(child) for key, child in value.items() if key != 'key'}
        if 'key' in value and 'scheme' in value: result['has_key'] = True
        return result
    if isinstance(value, list): return [public(child) for child in value]
    return value


class LabTools:
    def __init__(self, root, *, decision_runtime=None, watermark_runtime=None):
        self.root = Path(root).resolve()
        prepare(self.root); load_backend(self.root)
        from model_profiles import ModelProfiles
        from ai_lab.web_runtime import WebLifecycle, WebGenerationRuntime, WebDecisionRuntime
        # Construction and discovery are read-only; only an execution operation
        # enters the same ownership controller used by the website.
        self.lifecycle = WebLifecycle(self.root)
        self.decisions = decision_runtime or WebDecisionRuntime(self.root, self.lifecycle)
        self.runtime = watermark_runtime or WebGenerationRuntime(self.lifecycle)
        self.registry = ModelProfiles(self.root)
        self.lock = WorkspaceLock(self.root)
        self.inspections = self.root / '.state/ai-lab/mcp-inspections'

    async def close(self):
        try:
            await self.decisions.close()
        finally:
            await self.lifecycle.close()

    async def list_models(self):
        return {'root': str(self.root), 'default_decision_model': 'jev',
                'models': [row for row in await available_models(self.root, self.decisions)
                           if row['name'] in {'deepseek', 'contrastive', 'jev'}],
                'profiles': [{'key': key, **public(profile)} for key, profile in self.registry.supported_profiles().items()]}

    async def create_model(self, name, seed=None, watermark=None, *, underlying_model='deepseek'):
        from harness.generation_models import supported_generation_backend as generation_backend
        backend = generation_backend(underlying_model)
        # Use the website's existing publication transaction when it is alive.
        body = {'name': name, 'seed': seed, 'underlying_model': backend.underlying_model, 'watermark': watermark}
        response = await website_model_write(self.root, 'POST', body=body)
        if response is not None:
            result = json.loads(response.body)
            if response.status_code >= 400: raise ValueError(str(result.get('detail', 'Model creation failed.')))
            key = result.pop('key')
            return {'key': key, **public(result)}
        async with self.lock:
            key, profiles = self.registry.added(name, seed, backend.underlying_model, watermark)
            atomic_json(self.registry.path, self.registry.document(profiles))
            return {'key': key, **public(profiles[key])}

    async def create_watermarked_model(self, name, scheme, seed=None, settings=None, *, key=None, underlying_model='deepseek'):
        from model_profiles import watermark_values
        config = watermark_values(scheme, key, settings, generate_key=True)
        return await self.create_model(name, seed, config, underlying_model=underlying_model)

    def model_profile(self, model, profiles=None):
        profiles = self.registry.supported_profiles() if profiles is None else profiles
        matches = [key for key, profile in profiles.items() if key == model or profile['name'] == model]
        if len(matches) != 1:
            raise ValueError('Choose a saved generation profile key or unique exact name from list_models.')
        return matches[0], deepcopy(profiles[matches[0]])

    def generation_profile(self, model, profiles=None):
        """Saved exact identities take precedence; ambiguous names never become aliases."""
        from harness.generation_models import supported_generation_backend as generation_backend
        profiles = self.registry.supported_profiles() if profiles is None else profiles
        if any(key == model or profile['name'] == model for key, profile in profiles.items()):
            ident, profile = self.model_profile(model, profiles)
        else:
            ident, profile = None, {'underlying_model': generation_backend(model).underlying_model}
        return ident, profile, generation_backend(profile)

    @staticmethod
    def effective_watermark(profile, scheme=None, key=None, settings=None):
        from model_profiles import watermark_values
        if scheme == 'none':
            if key is not None or settings is not None:
                raise ValueError('Watermark key/settings require an enabled scheme.')
            return None
        if scheme is None and key is None and settings is None:
            return deepcopy(profile.get('watermark'))
        return watermark_values(scheme, key, settings, existing=profile.get('watermark'))

    def get_model_config(self, model, include_watermark_key=False):
        model_id, profile = self.model_profile(model)
        return {'key': model_id, **(profile if include_watermark_key else public(profile))}

    async def update_watermarked_model(self, model, scheme=None, key=None, settings=None, *, underlying_model=None):
        from ai_lab.service import WatermarkUpdateInput
        body = WatermarkUpdateInput(scheme=scheme, key=key, settings=settings, underlying_model=underlying_model).model_dump(exclude_none=True)
        model_id, _ = self.model_profile(model)
        response = await website_model_write(self.root, 'PATCH', key=model_id, body=body)
        if response is not None:
            result = json.loads(response.body)
            if response.status_code in {404, 405}:
                raise ValueError('The running website cannot update this profile. Restart ai-lab web with the updated CLI and retry.')
            if response.status_code >= 400: raise ValueError(str(result.get('detail', 'Model update failed.')))
            return {'key': result.pop('key'), **public(result)}
        async with self.lock:
            profiles = self.registry.watermarked(model_id, scheme=scheme, watermark_key=key, settings=settings, underlying_model=underlying_model)
            atomic_json(self.registry.path, self.registry.document(profiles))
            return {'key': model_id, **public(profiles[model_id])}

    async def generate_text(self, prompt, model='deepseek', scheme=None, key=None, settings=None, *,
                            seed=None, max_tokens=1024, temperature=.8, capture_trace=False):
        import inference
        if not isinstance(prompt, str) or not 1 <= len(prompt) <= 24000 or not prompt.strip():
            raise ValueError('Supply a prompt of 1–24,000 characters.')
        if type(max_tokens) is not int or not 1 <= max_tokens <= 4096:
            raise ValueError('max_tokens must be an integer between 1 and 4096.')
        if type(temperature) not in (int, float) or not 0 <= temperature <= 2:
            raise ValueError('Temperature must be between 0 and 2.')
        if type(capture_trace) is not bool:
            raise ValueError('capture_trace must be a boolean.')
        async with self.lock:
            model_id, profile, backend = self.generation_profile(model)
            watermark = self.effective_watermark(profile, scheme, key, settings)
            if seed is not None:
                profile['seed'] = inference.parse_seed(seed)
            # Manual readiness comes first so an empty workspace gets launch
            # guidance, rather than an installation exception or implicit start.
            await self.runtime.ensure_server(backend)
            result = await self.runtime.generate(profile, watermark, prompt, max_tokens=max_tokens,
                                                 temperature=temperature, capture_trace=capture_trace)
        return {'ok': True, 'model': model, 'profile_key': model_id,
                'underlying_model': backend.underlying_model, 'api_model': backend.api_model,
                'seed': profile.get('seed'), 'watermark': public(watermark), **public(result)}

    async def detect_watermark(self, text, model='deepseek', scheme=None, key=None, settings=None, *,
                               prompt_len=0, eos_token_ids=None, add_special_tokens=False,
                               p_value_threshold=.001, min_tokens=20):
        from detection_lab import DetectionInput, assess_detection
        from model_profiles import watermark_values
        async with self.lock:
            profiles = self.registry.supported_profiles()
            model_id, profile, backend = self.generation_profile(model, profiles)
            config = watermark_values(scheme, key, settings, existing=profile.get('watermark'))
            body = DetectionInput(text=text, watermark=config, prompt_len=prompt_len,
                                  eos_token_ids=[] if eos_token_ids is None else eos_token_ids,
                                  add_special_tokens=add_special_tokens,
                                  p_value_threshold=p_value_threshold, min_tokens=min_tokens)
            if not body.text.strip(): raise ValueError('Enter text to detect.')
            detected = await self.runtime.detect(body.text, [config], prompt_len=body.prompt_len,
                       eos_token_ids=body.eos_token_ids, add_special_tokens=body.add_special_tokens, model=profile)
            try:
                stats = detected[0]
                n = stats.get('tokens_scored', stats.get('trials'))
                if type(n) is not int or n < 0: raise ValueError('Invalid scored-token count')
                result = assess_detection(config, stats, body.p_value_threshold, body.min_tokens)
            except (AttributeError, ValueError, TypeError, KeyError, IndexError, OverflowError) as error:
                raise ValueError('The native watermark detector returned invalid evidence.') from error
        return {'ok': True, 'model': model, 'underlying_model': backend.underlying_model, 'api_model': backend.api_model,
                'profile_key': model_id, 'watermark': public(config), **public(result),
                **({'fixture': True} if stats.get('fixture') is True else {}),
                'confidence_definition': '1 - p_value from a known-key test or conservative bound against unwatermarked text; not a posterior probability of authorship.'}

    async def detect_text(self, text, model='deepseek', scheme=None, key=None, settings=None, *,
                          prompt_len=0, eos_token_ids=None, add_special_tokens=False,
                          p_value_threshold=.001, min_tokens=20):
        """Decoder-facing alias of the same native, model-aware MCP detector."""
        return await self.detect_watermark(text, model, scheme, key, settings,
            prompt_len=prompt_len, eos_token_ids=eos_token_ids, add_special_tokens=add_special_tokens,
            p_value_threshold=p_value_threshold, min_tokens=min_tokens)

    def explain_watermarks(self, scheme=None):
        from watermarks import SCHEMES
        schemes = [deepcopy(row) for row in SCHEMES if scheme is None or row['id'] == scheme]
        if not schemes: raise ValueError('Unknown scheme. Choose synthid, kgw, unigram, exponential, inverse_transform or mpac.')
        return {'schemes': schemes, 'green_red_lists': 'KGW and Unigram have binary green/red membership. SynthID has per-layer binary g values. Other schemes have different scores or groups.',
                'tournaments': 'Only SynthID tournament generation produces a production bracket. Probability updates and teaching simulations must not be presented as that bracket.',
                'model_default': 'New SynthID profiles use tournament generation with depth 4 (16 contestants).',
                'unsupported': [{'name': 'SemStamp', 'reason': 'Requires a sentence embedding and rejection pipeline; not a supported token watermark.'}]}

    async def download_models(self, models=None):
        aliases = {'contrastive': 'clm', 'jev': None}
        names = models if models is not None else list(DEFAULT_MODELS)
        if not names: raise ValueError('Choose at least one model, or omit models to download all missing local families.')
        families = list(dict.fromkeys(aliases.get(name, name) for name in names if aliases.get(name, name) is not None))
        if any(name not in DEFAULT_MODELS for name in families): raise ValueError('Choose deepseek, clm, contrastive or jev.')
        if not families: return {'installed': [], 'reason': 'Jev is hosted and has no local weights.'}
        result = await asyncio.to_thread(install, self.root, families, True)
        return {**result, 'servers_started': False, 'next_step': 'Open ai-lab web; both DeepSeek and CLM APIs stay running for the web process lifetime.'}

    async def answer_decisions(self, state, questions, model='jev'):
        from decisions import DecisionInput
        body = DecisionInput(model=model, state=state, questions=questions).model_dump(exclude_none=True)
        try:
            result, latency = await self.decisions.decide(body)
        except HTTPException as error:
            if model == 'jev' and error.status_code == 403:
                raise ValueError('Jev needs TYPESAFE_API_KEY or JEV_API_KEY. Export it and rerun ai-lab mcp install to save it privately in this workspace.') from error
            raise ValueError(str(error.detail)) from error
        return {**result, 'provider': model, 'latency_ms': round(latency, 2)}

    async def rank_decisions(self, context, answers, question=None, model='jev'):
        from decisions import RankInput
        body = RankInput(model=model, context=context, answers=answers, question=question)
        result = await self.answer_decisions(body.context, {'ranking': {'type': 'choice', 'instructions': body.question,
                                               'criteria': {str(i): value for i, value in enumerate(body.answers)}}}, model)
        probabilities = result['answers']['ranking']['probabilities']
        order = sorted(range(len(body.answers)), key=lambda i: -probabilities[str(i)])
        return {'model': result['model'], 'provider': model, 'usage': result.get('usage', {}), 'latency_ms': result['latency_ms'],
                'ranked': [{'rank': rank+1, 'candidate': body.answers[i], 'prob': probabilities[str(i)]} for rank, i in enumerate(order)]}

    async def inspect_next_token(self, model, prompt, temperature=1, *, scheme=None, key=None, settings=None):
        if not isinstance(prompt, str) or not 1 <= len(prompt) <= 24000:
            raise ValueError('Supply an exact raw prefix of 1–24,000 characters.')
        if type(temperature) not in (int, float) or not 0 <= temperature <= 2:
            raise ValueError('Temperature must be between 0 and 2.')
        async with self.lock:
            model_id, profile = self.model_profile(model)
            watermark = profile.get('watermark')
            if scheme is not None or key is not None or settings is not None:
                from model_profiles import watermark_values
                watermark = watermark_values(scheme, key, settings, existing=watermark)
            result = await self.runtime.complete_next(prompt, watermark, temperature=temperature, seed=profile['seed'], model=profile)
            ident = str(uuid.uuid4())
            record = {'id': ident, 'created_at': time.time(), 'model_key': model_id, 'result': result}
            atomic_json(self.inspections / f'{ident}.json', record)
        from harness.generation_models import supported_generation_backend as generation_backend
        backend = generation_backend(profile)
        return {'inspection_id': ident, 'profile_key': model_id, 'underlying_model': backend.underlying_model,
                'api_model': backend.api_model, **public(result)}

    def _read(self, path):
        if path.stat().st_size > 32 * 1024 * 1024: raise ValueError('This saved trace is too large for MCP inspection.')
        value = json.loads(path.read_text())
        if not isinstance(value, dict): raise ValueError('Invalid saved result.')
        return value

    def list_results(self):
        groups = (('inspection', self.inspections, '*.json'), ('session', self.root / '.state/ai-lab/sessions', '*.json'),
                  ('watermark', self.root / 'sessions/watermarks', '*/experiment.json'))
        results = []
        for source, folder, pattern in groups:
            for path in sorted(folder.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)[:100]:
                value = self._read(path)
                ident = path.parent.name if source == 'watermark' else path.stem
                item = {'source': source, 'source_id': ident, 'name': value.get('name', value.get('title', ident)),
                        'status': value.get('status'), 'updated_at': value.get('updated_at', value.get('created_at'))}
                if source == 'watermark': item['agents'] = [{'id': a['id'], 'name': a.get('name')} for a in value.get('agents', [])]
                results.append(item)
        return {'results': results, 'limit_per_source': 100}

    def trace_step(self, source_id, source='inspection', step=0, agent_id=None):
        uuid.UUID(source_id)
        if type(step) is not int or step < 0: raise ValueError('Step must be a nonnegative, zero-based index.')
        if source == 'inspection':
            value = self._read(self.inspections / f'{source_id}.json')
            results = [value['result']['step']]
        elif source == 'session':
            value = self._read(self.root / f'.state/ai-lab/sessions/{source_id}.json')
            results = [result['step'] for result in value['results']]
        elif source == 'watermark':
            value = self._read(self.root / f'sessions/watermarks/{source_id}/experiment.json')
            agents = [agent for agent in value['agents'] if agent['id'] == agent_id]
            if len(agents) != 1: raise ValueError('Choose the saved watermark agent ID for this experiment.')
            results = (agents[0].get('sampling_trace') or {}).get('steps', [])
        else: raise ValueError('Choose inspection, session or watermark as the source.')
        if step >= len(results): raise ValueError('That step has no saved native trace.')
        from sampling_trace import public_trace
        candidate = results[step]
        # Apply the same bounded, key-free native validation used by the website.
        limits = {'max_steps': 1, 'max_candidates': max(1, len(candidate.get('candidates', []))),
                  'max_layers': len(candidate.get('layers', [])), 'generation_tournament': {'max_matches': 255}}
        return public_trace({'steps': [candidate]}, limits)['steps'][0]

    def green_red_lists(self, source_id, source='inspection', step=0, layer=None, agent_id=None):
        trace = self.trace_step(source_id, source, step, agent_id)
        candidates = trace['candidates']
        groups = {'green': [], 'red': [], 'other': []}
        coverage = 'Captured native candidates only; missing vocabulary membership is not inferred.'
        membership_source = 'candidates'
        report = trace.get('generation_tournament') or {}
        if report.get('used_for_generation'):
            membership_source = 'production_tournament'
            rounds = {match['round'] for match in report['matches']}
            if layer is None and rounds: layer = max(rounds)
            if layer is not None and (type(layer) is not int or layer not in rounds):
                raise ValueError('That production tournament round was not captured.')
            draws = {draw['draw_id']: draw for draw in report['draws']}
            captured_tokens = set()
            for match in report['matches']:
                if match['round'] != layer: continue
                for side in ('left', 'right'):
                    entrant = match[side]
                    row = {**draws[entrant['draw_id']], 'g_value': entrant['g_value'],
                           'match_id': match['match_id'], 'round': layer}
                    groups['green' if entrant['g_value'] == 1 else 'red'].append(row)
                    captured_tokens.add(entrant['token_id'])
            groups['other'] = [dict(candidate) for candidate in candidates if candidate['token_id'] not in captured_tokens]
            coverage = ('Green/red entries are captured native tournament entrants in the selected round, '
                        'identified by draw_id. Other candidates have no captured membership for that round. '
                        'Collapsed matches and missing vocabulary membership are not inferred.')
        else:
            if layer is None and trace['layers']: layer = len(trace['layers']) - 1
            if layer is not None:
                if type(layer) is not int or not 0 <= layer < len(trace['layers']):
                    raise ValueError('That watermark layer was not captured.')
                selected_layer = trace['layers'][layer]
                membership_source = 'probability_layer'
            else: selected_layer = None
            for index, candidate in enumerate(candidates):
                row = dict(candidate)
                membership = candidate.get('membership') or {}
                if selected_layer is not None:
                    g = selected_layer['g_values'][index]; row['g_value'] = g
                    group = 'green' if g == 1 else ('red' if g == 0 else 'other')
                elif membership.get('kind') == 'green' and type(membership.get('favored')) is bool:
                    group = 'green' if membership['favored'] else 'red'
                else: group = 'other'
                groups[group].append(row)
        return {'source': source, 'source_id': source_id, 'step': step, 'layer': layer,
                'watermark': trace.get('watermark'), 'captured_candidates': len(candidates),
                'vocabulary_size': trace['candidate_count'], 'candidates_truncated': trace.get('candidates_truncated', True),
                'membership_source': membership_source, 'captured_memberships': len(groups['green']) + len(groups['red']),
                'tournament_truncated': report.get('truncated'), 'coverage': coverage, **groups}

    def tournament_results(self, source_id, source='inspection', step=0, agent_id=None):
        trace = self.trace_step(source_id, source, step, agent_id)
        report = trace.get('generation_tournament')
        return {'source': source, 'source_id': source_id, 'step': step, 'selected_token_id': trace['selected_token_id'],
                'production': report, 'teaching': trace.get('teaching_tournament'),
                'status': report.get('status') if report else 'not_captured',
                'note': 'Production and teaching traces are returned separately. Missing or truncated matches are never reconstructed.'}
