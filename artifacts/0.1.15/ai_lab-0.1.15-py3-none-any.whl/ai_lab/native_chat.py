"""Shared local model chat callback for the MCP ToolTurn connector."""
from copy import deepcopy
import asyncio
import json

import httpx

from ai_lab.mcp_tools import LabTools, public


class NativeChat:
    """Snapshot one profile on a shared backend; never adopt/start its process.

    ``complete(messages, tools)`` returns only the actual native assistant message.
    Use it as ToolTurn's callback. ``last_result`` reports identity/usage separately.
    """
    def __init__(self, root, model=None, *, model_name=None, scheme=None, key=None, settings=None,
                 seed=None, temperature=.8, max_tokens=1024, timeout=180,
                 transport=None, fixture_endpoints=None):
        import math
        if type(temperature) not in (int, float) or not math.isfinite(temperature) or not 0 <= temperature <= 2:
            raise ValueError('Temperature must be between 0 and 2.')
        if type(max_tokens) is not int or not 1 <= max_tokens <= 4096:
            raise ValueError('max_tokens must be an integer between 1 and 4096.')
        if type(timeout) not in (int, float) or not math.isfinite(timeout) or not .05 <= timeout <= 1200:
            raise ValueError('Chat timeout must be between .05 and 1200 seconds.')
        # Use the same exact-name/profile/backend and watermark rules as MCP.
        lab = LabTools(root)
        if model is not None and model_name is not None:
            raise ValueError('Choose either model or model_name, not both.')
        if model_name is None:
            self.profile_key, self._profile, self.backend = lab.generation_profile(model)
        else:
            if not isinstance(model_name, str):
                raise ValueError('model_name must be an exact saved profile name.')
            profiles = lab.registry.supported_profiles()
            matches = [ident for ident, profile in profiles.items() if profile['name'] == model_name]
            if len(matches) != 1:
                raise ValueError('Choose one exact case-sensitive saved profile name.')
            self.profile_key = matches[0]
            self._profile = deepcopy(profiles[self.profile_key])
            from harness.generation_models import supported_generation_backend
            self.backend = supported_generation_backend(self._profile)
        self._watermark = lab.effective_watermark(self._profile, scheme, key, settings)
        import inference
        if seed is not None:
            self._profile['seed'] = inference.parse_seed(seed)
        from watermark_runtime import WatermarkRuntime
        self.runtime = WatermarkRuntime(allow_start=False, transport=transport, fixture_endpoints=fixture_endpoints)
        self.temperature, self.max_tokens, self.timeout = temperature, max_tokens, timeout
        self.last_result = None
        self._closed = False
        self._requests = set()

    @property
    def selection(self):
        return {'profile_key': self.profile_key, 'underlying_model': self.backend.underlying_model,
                'api_model': self.backend.api_model, 'seed': self._profile.get('seed'),
                'watermark': public(self._watermark)}

    async def aclose(self):
        self._closed = True
        for task in tuple(self._requests):
            task.cancel()
        await asyncio.gather(*tuple(self._requests), return_exceptions=True)

    async def complete(self, messages, tools, *, tool_choice='auto'):
        if self._closed:
            raise ValueError('Native chat adapter is closed.')
        task = asyncio.create_task(self._complete(messages, tools, tool_choice=tool_choice))
        self._requests.add(task)
        try:
            return await task
        finally:
            self._requests.discard(task)

    async def _complete(self, messages, tools, *, tool_choice):
        try:
            body = json.loads(json.dumps({'messages': messages, 'tools': tools}, allow_nan=False))
        except (ValueError, TypeError, RecursionError):
            raise ValueError('Chat messages and tools must be JSON data.') from None
        if not isinstance(messages, list) or any(not isinstance(m, dict) for m in messages) or not isinstance(tools, list):
            raise ValueError('Chat messages and tools must be lists.')
        if len(json.dumps(body).encode()) > 1024 * 1024:
            raise ValueError('Chat input exceeds the 1 MiB limit.')
        body.update(model=self.backend.api_model, temperature=self.temperature, max_tokens=self.max_tokens, stream=False)
        if tools:
            body['tool_choice'] = deepcopy(tool_choice)
        else:
            body.pop('tools')
        if self._profile.get('seed') is not None:
            body['seed'] = self._profile['seed']
        if self._watermark:
            body['watermark'] = deepcopy(self._watermark)
        try:
            await self.runtime.ensure_server(self.backend)
        except (ValueError, RuntimeError) as error:
            raise ValueError(f'{error} If this API was already running during an upgrade, stop it in its owning '
                             'terminal and reopen ai-lab web to load the updated '
                             'runtime and chat template.') from None
        try:
            async with self.runtime.generation_lock:
                async with httpx.AsyncClient(base_url=self.runtime.base_url(self.backend), timeout=self.timeout,
                                             trust_env=False, **self.runtime.http_options) as client:
                    response = await client.post('/v1/chat/completions', json=body)
                    response.raise_for_status()
                    if len(response.content) > 1024 * 1024:
                        raise ValueError('Native chat result exceeds the 1 MiB limit.')
                    result = response.json()
            message = result['choices'][0]['message']
            if not isinstance(message, dict) or message.get('role') != 'assistant':
                raise ValueError('Invalid native assistant message.')
            if message.get('content') is not None and not isinstance(message['content'], str):
                raise ValueError('Invalid native assistant content.')
            if not message.get('tool_calls') and not (message.get('content') or '').strip():
                raise ValueError('Native model returned an empty assistant message.')
        except httpx.HTTPError:
            raise ValueError(f'{self.backend.label} native chat request failed. Check its API, then reopen ai-lab web and retry.') from None
        except (KeyError, IndexError, TypeError):
            raise ValueError('The native model returned an invalid chat response.') from None
        self.last_result = {**self.selection, 'usage': result.get('usage', {}),
                            'finish_reason': result['choices'][0].get('finish_reason'),
                            **self.runtime.fixture_metadata(self.backend)}
        return deepcopy(message)
