"""Reference-free argument schemas for a native tool-call envelope.

The native strict grammar embeds parameters under ``arguments``. A local JSON
Pointer in the original schema would then resolve against the envelope instead
of the parameters document. Expand supported references before embedding, while
leaving discovery and the host's original validator untouched.
"""
import json
import re
from urllib.parse import unquote

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError


class TransportSchemaError(ValueError):
    """Discovery cannot safely represent this schema in the native envelope."""


_MAPS = {'properties', 'patternProperties', '$defs', 'definitions', 'dependentSchemas'}
_SINGLE = {'additionalProperties', 'unevaluatedProperties', 'propertyNames', 'items',
           'unevaluatedItems', 'contains', 'not', 'if', 'then', 'else', 'contentSchema'}
_ARRAYS = {'allOf', 'anyOf', 'oneOf', 'prefixItems'}
_SCOPES = {'$id', '$anchor', '$dynamicAnchor', '$recursiveAnchor', '$dynamicRef',
           '$recursiveRef', '$vocabulary'}
_DIALECT = 'https://json-schema.org/draft/2020-12/schema'


def transport_schema(schema):
    """Expand acyclic local pointers, preserving Draft 2020-12 assertions.

Unsupported dialect/resource/dynamic scopes fail discovery rather than emit a
weaker schema. Only schema positions are visited: a literal ``$ref`` inside an
enum, default or example is data. Expansion is bounded in depth, work and size.
    """
    nodes, size = 0, 0

    def charge(value, depth):
        nonlocal nodes, size
        nodes += 1
        if depth > 64 or nodes > 16384:
            raise TransportSchemaError('MCP transport schema expansion exceeds the nesting/work limit.')
        # Count JSON container punctuation and scalar encodings incrementally,
        # including duplicated reference targets, before allocating the result.
        if isinstance(value, (dict, list)):
            size += 2 + len(value)
        else:
            size += len(json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8'))
        if size > 256 * 1024:
            raise TransportSchemaError('MCP transport schema expansion exceeds the size limit.')

    def data(value, depth):
        charge(value, depth)
        if isinstance(value, dict):
            return {data(k, depth + 1): data(v, depth + 1) for k, v in value.items()}
        if isinstance(value, list):
            return [data(v, depth + 1) for v in value]
        return value

    def pointer(ref):
        if not isinstance(ref, str) or not ref.startswith('#'):
            raise TransportSchemaError('MCP transport schemas require local JSON Pointer references.')
        try:
            fragment = unquote(ref[1:], errors='strict')
        except UnicodeError:
            raise TransportSchemaError('MCP transport schema has an invalid reference.') from None
        if fragment and not fragment.startswith('/'):
            raise TransportSchemaError('MCP transport schema anchors are not supported.')
        path, target = [], schema
        for token in fragment[1:].split('/') if fragment else ():
            # JSON Pointer permits only ~0 and ~1 escape sequences.
            if re.search(r'~(?![01])', token):
                raise TransportSchemaError('MCP transport schema has an invalid reference.')
            token = token.replace('~1', '/').replace('~0', '~')
            try:
                if isinstance(target, list):
                    if not token.isascii() or not token.isdecimal() or (len(token) > 1 and token[0] == '0'):
                        raise ValueError
                    index = int(token)
                    target = target[index]
                    path.append(index)
                else:
                    target = target[token]
                    path.append(token)
            except (KeyError, IndexError, TypeError, ValueError):
                raise TransportSchemaError('MCP transport schema has an unresolved reference.') from None
        if not isinstance(target, (dict, bool)):
            raise TransportSchemaError('MCP transport reference must resolve to a schema.')
        return tuple(path), target

    def visit(node, path, active, depth):
        charge(node, depth)
        if isinstance(node, bool):
            return node
        if not isinstance(node, dict):
            raise TransportSchemaError('MCP transport schema is not an object or boolean.')
        if _SCOPES.intersection(node) or ('$schema' in node and node['$schema'] != _DIALECT):
            raise TransportSchemaError('MCP transport schema uses an unsupported dialect or reference scope.')
        result = {}
        for keyword, value in node.items():
            if keyword == '$ref':
                continue
            charge(keyword, depth + 1)
            if keyword in _MAPS:
                charge(value, depth + 1)
                result[keyword] = {}
                for name, child in value.items():
                    charge(name, depth + 2)
                    child_path = (*path, keyword, name)
                    result[keyword][name] = visit(child, child_path, (*active, child_path), depth + 2)
            elif keyword in _SINGLE:
                child_path = (*path, keyword)
                result[keyword] = visit(value, child_path, (*active, child_path), depth + 1)
            elif keyword in _ARRAYS:
                charge(value, depth + 1)
                result[keyword] = [visit(child, (*path, keyword, i), (*active, (*path, keyword, i)), depth + 2)
                                   for i, child in enumerate(value)]
            else:
                result[keyword] = data(value, depth + 1)
        if '$ref' in node:
            target_path, target = pointer(node['$ref'])
            if target_path in active:
                raise TransportSchemaError('MCP transport schema has cyclic references.')
            expanded = visit(target, target_path, (*active, target_path), depth + 1)
            if not result:
                return expanded
            # $ref siblings are independent assertions. Merging properties or
            # required lists would change additionalProperties semantics. Keep
            # the target in allOf at this same scope so unevaluated* sees its
            # successful annotations along with the existing sibling branches.
            result.setdefault('allOf', []).append(expanded)
        return result

    try:
        Draft202012Validator.check_schema(schema)
        result = visit(schema, (), ((),), 0)
        Draft202012Validator.check_schema(result)
        if len(json.dumps(result, ensure_ascii=False, allow_nan=False).encode('utf-8')) > 256 * 1024:
            raise TransportSchemaError('MCP transport schema expansion exceeds the size limit.')
    except TransportSchemaError:
        raise
    except (ValueError, TypeError, AttributeError, RecursionError, SchemaError):
        raise TransportSchemaError('MCP transport schema is invalid.') from None
    return result
