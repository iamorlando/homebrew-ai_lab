"""Presentation of native evidence. Never infer missing probabilities or matches."""
import json

from rich.table import Table
from rich.text import Text


def escaped(value):
    return json.dumps(value, ensure_ascii=False)


def probability(value):
    return '—' if value is None else f'{value:.3%}'


def captured(value):
    return 'unavailable' if value is None else str(value)


def selected_result(session):
    results = session.get('results', [])
    return results[min(session.get('selected_step', 0), len(results)-1)] if results else None


def candidate_rows(session):
    result = selected_result(session)
    if not result:
        return []
    step = result['step']
    layers = step.get('layers', [])
    index = session.get('selected_layer', -1)
    layer = layers[index] if 0 <= index < len(layers) else None
    rows = []
    for i, candidate in enumerate(step['candidates']):
        row = dict(candidate)
        membership = candidate.get('membership') or {}
        row['group'] = ('Green' if membership.get('favored') else 'Red') if membership.get('kind') == 'green' else (
            ('Favored' if membership.get('favored') else 'Unfavored') if membership else '—')
        if layer:
            row.update(pre_watermark_probability=layer['input_probabilities'][i],
                       post_watermark_probability=layer['probabilities'][i],
                       group='g = 1' if layer['g_values'][i] == 1 else 'g = 0')
        rows.append(row)
    return rows


def distribution(session, *, bars=True):
    result = selected_result(session)
    if not result:
        return Text('Submit a prefix to inspect the next token.\nFull-vocabulary probabilities will appear here.', style='#879bb7')
    step = result['step']
    candidates = sorted(candidate_rows(session), key=lambda c: c.get('reporting_probability') or 0, reverse=True)[:10]
    table = Table(expand=True, box=None, padding=(0, 1))
    table.add_column('Token', ratio=1)
    table.add_column('Model p', no_wrap=True, width=8)
    if bars:
        table.add_column('', ratio=1, no_wrap=True, overflow='crop')
    table.add_column('After p', no_wrap=True, width=8)
    maximum = max((c.get('reporting_probability') or 0 for c in candidates), default=1) or 1
    for c in candidates:
        value = c.get('reporting_probability')
        bar = '━' * round((value or 0) / maximum * 16)
        cells = [Text(escaped(c['text']), style='#67dbe8' if c['token_id'] == step['selected_token_id'] else 'white'), probability(value)]
        if bars:
            cells.append(Text(bar, style='#488dfa'))
        table.add_row(*cells, probability(c.get('post_watermark_probability')))
    mass = max(0, 1 - sum(c.get('reporting_probability') or 0 for c in candidates))
    table.add_row('Other tokens', probability(mass), *([''] if bars else []), '—')
    return table


def token_detail(session):
    result = selected_result(session)
    if not result:
        return 'Select a token or tournament contestant to inspect it.'
    step = result['step']
    token = session.get('selected_token_id')
    candidate = next((c for c in candidate_rows(session) if c['token_id'] == token), None)
    if not candidate:
        draws = [d for d in (step.get('generation_tournament') or {}).get('draws', []) if d['token_id'] == token]
        evidence = '\n'.join(f"Draw {d['draw_id']} {escaped(d.get('text', '[not captured]'))} · input p {probability(d.get('probability'))}" for d in draws)
        return (f'Inspecting token {token} · outside captured alternatives.\n{evidence}\n'
                'Model p / after p / final log p unavailable.')
    layer = session.get('selected_layer', -1)
    scope = f'Layer {layer + 1}' if 0 <= layer < len(step.get('layers', [])) else 'Final distribution'
    return (f"Inspecting {escaped(candidate['text'])} · ID {token}\n"
            f"Emitted token #{step['selected_token_id']} · {candidate['group']}\n"
            f"Model p {probability(candidate.get('reporting_probability'))} · logit {captured(candidate.get('input_logit'))}\n"
            f"{scope}: before p {probability(candidate.get('pre_watermark_probability'))} · after p {probability(candidate.get('post_watermark_probability'))}\n"
            f"Final log p {captured(candidate.get('post_watermark_log_probability'))}\n"
            f"Score {captured(candidate.get('selection_score'))}")


def bracket(tree, step):
    """Render native sources and return the captured match nodes by match ID."""
    report = step.get('generation_tournament') or {}
    tree.clear()
    match_nodes = {}
    if report.get('origin') != 'production' or not report.get('used_for_generation') or report.get('status') != 'applied':
        status = report.get('status', 'not applicable')
        tree.root.set_label(Text(f'No production bracket · {status}', style='#879bb7'))
        tree.root.add_leaf('Choose SynthID / Tournament · actual bracket, then run a prefix.')
        tree.root.expand()
        return match_nodes
    if report['winner']['token_id'] != step['selected_token_id']:
        tree.root.set_label('Invalid trace: winner differs from emitted token')
        return match_nodes
    draws = {d['draw_id']: d for d in report['draws']}
    matches = {m['match_id']: m for m in report['matches']}
    collapsed = {s['root_match_id']: s for s in report.get('collapsed_subtrees', [])}
    tree.root.set_label(Text(f"Winner #{report['winner']['token_id']} · {report['total_draws']:,} draws · depth {report['configured_depth']}", style='bold #67dbe8'))
    visited = set()
    def draw_label(draw_id):
        d = draws.get(draw_id, {})
        return f"draw {draw_id} · {escaped(d.get('text', '[not captured]'))} · #{d.get('token_id', '?')}"
    def visit(parent, source, prefix=''):
        identity = (source['kind'], source['id'])
        if identity in visited:
            parent.add_leaf('Repeated source in trace; unavailable')
            return
        visited.add(identity)
        kind, ident = identity
        if kind == 'draw':
            d = draws.get(ident, {})
            parent.add_leaf(Text(prefix + draw_label(ident)), data={'token_id': d.get('token_id')})
        elif kind == 'collapsed_subtree':
            s = collapsed.get(ident)
            if s:
                parent.add_leaf(Text(prefix + f"Collapsed subtree {ident} → {draw_label(s['winner_draw_id'])}", style='#e5be72'), data={'token_id': draws.get(s['winner_draw_id'], {}).get('token_id')})
            else:
                parent.add_leaf('Collapsed subtree not captured')
        elif kind == 'match' and ident in matches:
            m = matches[ident]
            label = f"{prefix}R{m['round']+1} · match {ident} → {draw_label(m['winner_draw_id'])}"
            node = parent.add(Text(label, style='#9cbef7'), data={'match': m}, expand=True)
            match_nodes[ident] = node
            for side in ('left', 'right'):
                contestant = m[side]
                marker = '● ' if m['winner'] == side else '○ '
                visit(node, contestant['source'], f"{marker}g={contestant['g_value']} · ")
        else:
            parent.add_leaf(f'Match {ident} not captured')
    winner = report['winner']['match_id']
    visit(tree.root, {'kind': 'match' if winner in matches else 'collapsed_subtree', 'id': winner})
    tree.root.expand()
    return match_nodes
