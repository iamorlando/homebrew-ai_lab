"""Provision only the pinned local inference runtime required for completions."""
import asyncio
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from ai_lab.paths import RESOURCES, load_backend, require_owned_path, state_path
from ai_lab.service import atomic_json
from ai_lab import runtime


def prepare(root):
    root = Path(root).resolve()
    # Validate the entire bounded initialization set before the first write.
    # This also covers models-run initialization before runtime repair is called.
    require_owned_path(root, '.state/ai-lab')
    require_owned_path(root, 'harness/models.json')
    root.mkdir(parents=True, exist_ok=True)
    state_path(root)
    # Upgrade only a known shipped template/manifest pair. Custom
    # manifests/templates stay user-owned; no process is started or stopped.
    source, template = root / 'sources.json', root / 'deepseek-chat.jinja'
    if source.is_file() and not source.is_symlink() and not template.is_symlink():
        previous = json.loads(source.read_text())
        bundled = json.loads((RESOURCES / 'sources.json').read_text())
        previous_derivations = {
            '06ff98c593789cfe9501ed3cc7a74f63a537201baf092d1a2c905c8aee3cc83b':
                'Pinned official tokenizer_config.json chat_template plus an explicit <think> generation prefix.',
            '1e13074a59efca0dfc4c62ad280365ce78747782fa945bd9e841b51efda97a0b':
                'Pinned official tokenizer_config.json chat_template plus an explicit <think> generation prefix. MCP tool schema insertion and native mapped-argument serialization/null assistant guards; unchanged no-tool chat rendering.',
            'f3ee548562d647b506a7b60a4cf0a955d1aab29a3f358a625ce721f325d06d44':
                "Pinned official tokenizer_config.json ordinary chat rendering and explicit <think> generation prefix. Tool-enabled chats use the pinned distilled tokenizer's supported Qwen XML call/result framing and no-thinking prefix, with native mapped-argument serialization/null guards. Byte-equivalent no-tool rendering; raw completion prefix unchanged.",
        }
        old_checksum = previous.get('chat_template', {}).get('sha256')
        adjusted = deepcopy(previous)
        adjusted['chat_template'] = bundled['chat_template']
        # A later bundled runtime can replace only this exact shipped pin.
        # Comparing the entire normalized manifest prevents accepting custom
        # repositories, features, assets or any other provenance changes.
        if previous.get('runtime', {}).get('commit') == 'fc3c3f5a043759076a4e9f2bb85bc665d50ab98c':
            adjusted['runtime']['commit'] = bundled['runtime']['commit']
        elif (previous.get('runtime', {}).get('commit'), previous.get('watermark_library', {}).get('commit')) == (
                '1d8dc794c66e5bf64fe2f4d08f469f8f36048f7b', 'b29462d634c007bef0083cbc6bc102d521d9f79f'):
            # Preserve the exact 0.1.0 migration when its original default
            # template is present too, with the same full-manifest/byte guards.
            adjusted['runtime']['commit'] = bundled['runtime']['commit']
            adjusted['watermark_library']['commit'] = bundled['watermark_library']['commit']
        old_descriptor = {'file': 'deepseek-chat.jinja', 'sha256': old_checksum,
                          'derivation': previous_derivations.get(old_checksum)}
        if (previous != bundled and old_checksum in previous_derivations
                and previous.get('chat_template') == old_descriptor and adjusted == bundled):
            actual_checksum = hashlib.sha256(template.read_bytes()).hexdigest() if template.is_file() else None
            if not template.exists() or actual_checksum in {old_checksum, bundled['chat_template']['sha256']}:
                # An absent default needs both files. An exact bundled template
                # can also finish a prior upgrade interrupted before sources
                # was replaced; leave that already-correct template untouched.
                if actual_checksum != bundled['chat_template']['sha256']:
                    from ai_lab.mcp_install import atomic_write
                    atomic_write(template, (RESOURCES / 'deepseek-chat.jinja').read_bytes())
                atomic_json(source, bundled)
    for name in ('sources.json', 'deepseek-chat.jinja', 'qwen-chat.jinja', 'offline.sb'):
        target = root / name
        if not target.exists() and not target.is_symlink():
            shutil.copy2(RESOURCES / name, target)
        elif name == 'sources.json' and not target.is_symlink():
            # Upgrade only the exact defaults shipped by 0.1.0; custom manifests
            # belong to the workspace owner and must remain unchanged.
            previous = json.loads(target.read_text())
            bundled = json.loads((RESOURCES / name).read_text())
            if (previous.get('runtime', {}).get('commit'), previous.get('watermark_library', {}).get('commit')) == (
                '1d8dc794c66e5bf64fe2f4d08f469f8f36048f7b',
                'b29462d634c007bef0083cbc6bc102d521d9f79f',
            ):
                previous['runtime']['commit'] = bundled['runtime']['commit']
                previous['watermark_library']['commit'] = bundled['watermark_library']['commit']
                # An absent default will be copied below. An existing template
                # must still match the declared bundled default; custom or
                # symlinked resources cannot authorize a provenance upgrade.
                default_template = root / 'deepseek-chat.jinja'
                unchanged_template = (not default_template.is_symlink() and
                    (not default_template.exists() or (default_template.is_file() and
                     hashlib.sha256(default_template.read_bytes()).hexdigest() == bundled['chat_template']['sha256'])))
                if previous == bundled and unchanged_template:
                    atomic_json(target, bundled)
    profiles = root / 'harness/models.json'
    if not profiles.exists():
        atomic_json(profiles, {'version': 1, 'models': []})


def doctor(root):
    source = root / 'sources.json'
    sources = json.loads((source if source.exists() else RESOURCES / 'sources.json').read_text())
    release = runtime.descriptor()
    from ai_lab.downloads import status
    weights = status(root, models=('deepseek',))[0]
    return {**weights, 'platform_supported': runtime.supported(release),
            'prerequisites': {}, 'minimum_macos': release['minimum_macos'],
            'runtime_distribution': 'prebuilt', 'runtime_download_bytes': release['bytes'],
            'runtime_matches_sources': runtime.compatible(sources, release),
            'runtime_build': (root / '.state/mistral-build.json').exists(),
            'source_repository': sources['runtime']['repository'],
            'setup_command': f'ai-lab --root {str(root)!r} setup install deepseek --yes'}


def repair_generation_runtime(root, family):
    """Repair just the published runtime; no weights/assets, build, or process stop."""
    from ai_lab.downloads import dependencies_ready, missing_weights_message, status
    root = Path(root).resolve()
    # Repair cannot initialize an escaping/custom managed path even temporarily.
    # Check before prepare(), which can create resources and chmod its cache.
    require_owned_path(root, '.state/ai-lab')
    require_owned_path(root, 'harness/models.json')
    build_file = root / '.state/mistral-build.json'
    managed = root / '.runtime/mistral/mistralrs'
    require_owned_path(root, '.state/mistral-build.json')
    require_owned_path(root, '.runtime/mistral/mistralrs')
    if (os.environ.get('MISTRAL_DIR') or (root / 'sources.json').is_symlink()
            or build_file.is_symlink() or not build_file.resolve().is_relative_to(root) or managed.is_symlink()
            or not managed.resolve().is_relative_to(root)):
        raise ValueError('Custom runtime/source override is preserved. Restore the published runtime configuration '
                         f'before using ai-lab setup repair-runtime --model {family} --yes.')
    prepare(root)
    row = status(root, models=(family,))[0]
    if not row['weights_present']:
        raise ValueError(missing_weights_message(root, family, row))
    if dependencies_ready(root, family):
        return {'repaired': False, 'reason': 'runtime-ready'}
    try:
        build = json.loads(build_file.read_text())
    except FileNotFoundError:
        build = None
    except (OSError, ValueError) as error:
        raise ValueError('Custom runtime provenance cannot be read; it was preserved. Restore a valid published runtime '
                         f'receipt before using ai-lab setup repair-runtime --model {family} --yes.') from error
    if build is not None and (not isinstance(build, dict) or build.get('distribution') != 'prebuilt'
                              or build.get('binary') != str(managed)):
        raise ValueError('Custom runtime provenance is preserved. Restore the published runtime configuration '
                         f'before using ai-lab setup repair-runtime --model {family} --yes.')
    result = runtime.install(root)  # Pin, HTTPS, archive and executable SHA checks.
    load_backend(root)
    import inference
    inference._verified = None
    return {'repaired': True, 'build': result}


async def retire_previous_runtime(root, inference, build):
    from ai_lab.coordination import WorkspaceLock
    # Wait for any completion to finish before replacing this workspace's server.
    async with WorkspaceLock(root):
        current = inference.owned_state()
        if current and current['build']['binary_sha256'] != build['binary_sha256']:
            inference.stop()


def setup(root, yes=False, use_local_source=False, build_from_source=False):
    build_from_source = build_from_source or use_local_source
    report = doctor(root)
    if not yes:
        if not sys.stdin.isatty():
            raise ValueError('Setup needs --yes in scripts. Run ai-lab setup --doctor --json to inspect prerequisites.')
        print(f"AI Lab · local DeepSeek setup\nData: {root}\nMissing model weights: {report['missing_bytes']/1e9:.2f} GB.")
        if build_from_source:
            print('Source build: requires Rust via rustup and Apple Command Line Tools.')
        else:
            print(f"Requires Apple Silicon and macOS {report['minimum_macos']}+. No Xcode or Rust needed.")
            print(f"Verified server download: {report['runtime_download_bytes']/1e6:.1f} MB.")
        if input('Download and set up local inference? [y/N] ').strip().lower() not in {'y', 'yes'}:
            return {'configured': False, 'reason': 'cancelled'}
    if not report['platform_supported']:
        raise ValueError(f"Local inference requires Apple Silicon and macOS {report['minimum_macos']} or newer.")
    prepare(root)
    load_backend(root)
    import inference
    try:
        inference.verify_installation()
    except (OSError, RuntimeError, KeyError, ValueError):
        if build_from_source:
            os.environ.setdefault('MISTRAL_DIR', str(root / '.runtime/sources/mistral'))
            Path(os.environ['MISTRAL_DIR']).parent.mkdir(parents=True, exist_ok=True)
            command = [sys.executable, str(RESOURCES / 'runtime_setup.py'), '--completion-only']
            if use_local_source:
                command.append('--use-local-source')
            subprocess.run(command, check=True, stdout=sys.stderr)
        else:
            runtime.install(root)
            import runtime_setup
            runtime_setup.download_assets()
        inference._verified = None
        inference.verify_installation()
    asyncio.run(retire_previous_runtime(root, inference, inference.verify_installation()))
    return {'configured': True, 'root': str(root), 'next': 'ai-lab web'}
