"""Optional Herdr lifecycle reporting and explicitly requested tab creation."""
import asyncio
from dataclasses import dataclass
import json
import os
from pathlib import Path
import shlex
import time
from typing import Awaitable, Callable, Mapping, Sequence


CommandRunner = Callable[[Sequence[str]], Awaitable[str | None]]


def _identifier(value):
    return isinstance(value, str) and bool(value.strip()) and not any(ord(c) < 32 for c in value)


@dataclass(frozen=True)
class HerdrContext:
    binary: str
    pane: str
    socket: str

    @classmethod
    def from_environment(cls, environment: Mapping[str, str]):
        if environment.get('HERDR_ENV') != '1':
            return None
        binary = environment.get('HERDR_BIN_PATH', '')
        pane = environment.get('HERDR_PANE_ID', '')
        socket = environment.get('HERDR_SOCKET_PATH', '')
        if not all(_identifier(value) for value in (binary, pane, socket)):
            return None
        try:
            if (not Path(binary).is_absolute() or not Path(binary).is_file()
                    or not os.access(binary, os.X_OK) or not Path(socket).is_absolute()
                    or not Path(socket).is_socket()):
                return None
        except OSError:
            return None
        return cls(binary, pane, socket)


async def _command(arguments, environment):
    """Run only this short-lived CLI child; cancellation never stops Herdr itself."""
    process = await asyncio.create_subprocess_exec(
        *arguments, env=environment, stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE)
    try:
        stdout, _ = await process.communicate()
        if process.returncode:
            raise RuntimeError(f'Herdr command exited with status {process.returncode}.')
        return stdout.decode('utf-8')
    finally:
        if process.returncode is None:
            try:
                process.kill()
            except ProcessLookupError:
                pass
            await process.wait()


class HerdrReporter:
    """Serialize semantic state reports; unavailable Herdr is a nonfatal diagnostic."""
    SOURCE = 'custom:ai-lab'
    LABEL = 'ai-lab'
    METADATA_SOURCE = 'custom:ai-lab-session'
    TOKEN_NAMES = ('ai_lab_protocol', 'ai_lab_session', 'ai_lab_pid', 'ai_lab_state', 'ai_lab_updated', 'ai_lab_input')

    def __init__(self, session_id, *, environment=None, runner: CommandRunner | None = None,
                 timeout=2.0):
        if not _identifier(session_id):
            raise ValueError('A conversation session ID is required.')
        if timeout <= 0:
            raise ValueError('Herdr timeout must be positive.')
        self.session_id = session_id
        self.environment = dict(os.environ if environment is None else environment)
        self.context = HerdrContext.from_environment(self.environment)
        self.runner = runner or (lambda arguments: _command(arguments, self.environment))
        self.timeout = timeout
        self.last_error = None
        self.sequence = time.time_ns()
        self._lock = asyncio.Lock()
        self._attempted = False
        self._closed = False
        self._state = 'unknown'
        self._heartbeat = None
        self.input_path = None

    @property
    def enabled(self):
        return self.context is not None and not self._closed

    def _arguments(self, command):
        self.sequence = max(self.sequence + 1, time.time_ns())
        return [self.context.binary, 'pane', command, self.context.pane,
                '--source', self.SOURCE, '--agent', self.LABEL, '--seq', str(self.sequence)]

    async def _send(self, arguments):
        try:
            await asyncio.wait_for(self.runner(arguments), self.timeout)
        except Exception as error:
            # CLI output and exception messages may contain private environment values.
            self.last_error = f'Herdr lifecycle reporting unavailable ({type(error).__name__}).'
            return False
        self.last_error = None
        return True

    async def report(self, state, *, message=None):
        if state not in {'idle', 'working', 'blocked', 'unknown'}:
            raise ValueError('Unknown Herdr lifecycle state.')
        if state == 'blocked' and (not isinstance(message, str) or not message.strip()):
            raise ValueError('Blocked state requires a user-decision message.')
        async with self._lock:
            if not self.enabled:
                return False
            self._attempted = True
            arguments = self._arguments('report-agent')
            arguments.extend(['--state', state, '--agent-session-id', self.session_id])
            if message is not None:
                arguments.extend(['--message', message])
            sent = await self._send(arguments)
            self._state = state
            if sent:
                sent = await self._metadata()
                if self._heartbeat is None:
                    self._heartbeat = asyncio.create_task(self._refresh())
            return sent

    async def _metadata(self, *, clear=False):
        arguments = self._arguments('report-metadata')
        arguments[arguments.index('--source') + 1] = self.METADATA_SOURCE
        if clear:
            for name in self.TOKEN_NAMES:
                arguments.extend(['--clear-token', name])
        else:
            arguments.extend(['--ttl-ms', '5000'])
            values = ('1', self.session_id, str(os.getpid()), self._state, str(time.time_ns()),
                      str(self.input_path or ''))
            for name, value in zip(self.TOKEN_NAMES, values):
                arguments.extend(['--token', f'{name}={value}'])
        return await self._send(arguments)

    async def _refresh(self):
        # Only custom session tokens expire/refresh; they never replace semantic state.
        try:
            while True:
                await asyncio.sleep(2)
                async with self._lock:
                    if not self.enabled:
                        return
                    await self._metadata()
        except asyncio.CancelledError:
            return

    async def close(self):
        if self._heartbeat is not None:
            self._heartbeat.cancel()
            await self._heartbeat
        async with self._lock:
            if self._closed:
                return
            self._closed = True
            if self.context and self._attempted:
                try:
                    await self._metadata(clear=True)
                finally:
                    await self._send(self._arguments('release-agent'))


@dataclass(frozen=True)
class HerdrTab:
    workspace_id: str
    tab_id: str
    pane_id: str


async def launch_herdr_tab(arguments, cwd, *, label='AI Lab agent', environment=None,
                          runner: CommandRunner | None = None, timeout=5.0):
    """Launch a command in one new tab; callers supply their already-resolved CLI argv."""
    environment = dict(os.environ if environment is None else environment)
    context = HerdrContext.from_environment(environment)
    workspace = environment.get('HERDR_WORKSPACE_ID')
    if context is None or not _identifier(workspace):
        raise ValueError('A valid current Herdr workspace is required to launch an agent tab.')
    if not arguments or not all(isinstance(arg, str) and '\x00' not in arg for arg in arguments):
        raise ValueError('Agent command arguments are required.')
    if timeout <= 0:
        raise ValueError('Herdr timeout must be positive.')
    cwd = Path(cwd).resolve(strict=True)
    if not cwd.is_dir():
        raise ValueError('Agent working directory must be a directory.')
    runner = runner or (lambda argv: _command(argv, environment))

    async def call(*argv):
        return await asyncio.wait_for(runner([context.binary, *argv]), timeout)

    created = await call('tab', 'create', '--workspace', workspace, '--cwd', str(cwd),
                         '--label', label, '--no-focus')
    try:
        result = json.loads(created)['result']
        tab, pane = result['tab']['tab_id'], result['root_pane']['pane_id']
        if not all(_identifier(value) for value in (tab, pane)):
            raise ValueError('Missing tab/pane identifiers.')
    except (TypeError, ValueError, KeyError) as error:
        raise RuntimeError('Herdr did not return the new agent tab identifiers; inspect its tabs before retrying.') from error
    try:
        await call('pane', 'run', pane, shlex.join(arguments))
    except BaseException as launch_error:
        # Only the tab successfully created by this request may be cleaned up.
        try:
            await call('tab', 'close', tab)
        except Exception as cleanup_error:
            launch_error.add_note(f'Could not close the created Herdr tab {tab} ({type(cleanup_error).__name__}).')
        raise
    return HerdrTab(workspace, tab, pane)
