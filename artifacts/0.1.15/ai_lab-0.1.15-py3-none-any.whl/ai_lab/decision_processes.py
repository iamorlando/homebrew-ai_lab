"""Local decision launch settings and durable, process-verified ownership receipts."""
import errno
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import time
from urllib.parse import urlsplit

from ai_lab.service import atomic_json

MODEL = 'Contrastive-LM/CLM-v0.1-8B'
STATE_NAME = 'decisions-mistral.json'
STATE_NAMES = {'contrastive': STATE_NAME, 'laya': 'laya-server.json'}
MODELS = {'contrastive': MODEL, 'laya': 'laya'}


def loopback(url, setting):
    message = f'{setting} must be a loopback HTTP origin.'
    try:
        parsed = urlsplit(url)
        port = parsed.port
    except (ValueError, TypeError):
        raise ValueError(message) from None
    if (parsed.scheme != 'http' or parsed.hostname not in {'127.0.0.1', 'localhost', '::1'}
            or parsed.path or parsed.query or parsed.fragment
            or parsed.username is not None or parsed.password is not None
            or parsed.geturl() != url or port == 0):
        raise ValueError(message)
    return parsed


def host_port(endpoint):
    parsed = loopback(endpoint, 'AI_LAB_DECISIONS_URL')
    return ('127.0.0.1' if parsed.hostname == 'localhost' else parsed.hostname, parsed.port or 80)


def binary(root):
    return Path(os.environ.get('AI_LAB_DECISIONS_BINARY', Path(root) / '.runtime/decisions/mistralrs')).expanduser().resolve()


def command(root, endpoint, executable=None, *, family='contrastive'):
    host, port = host_port(endpoint)
    if family == 'laya':
        if host != '127.0.0.1':
            raise ValueError('The managed Laya server binds IPv4 loopback. Set AI_LAB_LAYA_URL to a 127.0.0.1 or localhost HTTP origin.')
        from ai_lab.laya import server_command
        argv = server_command(Path(root).resolve(), port)
        argv[0] = str(Path(argv[0]).resolve()) if executable is None else str(executable)
        return argv
    if family != 'contrastive':
        raise ValueError('Unknown local decision service.')
    return [str(binary(root) if executable is None else executable), 'serve',
            '-m', str(Path(root).resolve() / '.models/clm-v0.1-8b'),
            '--host', host, '-p', str(port), '--token-source', 'none']


def port_available(endpoint):
    host, port = host_port(endpoint)
    with socket.socket(socket.AF_INET6 if ':' in host else socket.AF_INET) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind((host, port))
        except OSError as error:
            if error.errno != errno.EADDRINUSE:
                raise
            return False
    return True


def process_fingerprint(pid):
    """Bind a process group leader to its start time and actual command."""
    result = subprocess.run(['ps', '-p', str(pid), '-o', 'lstart=', '-o', 'pgid=',
                             '-o', 'command='], capture_output=True, text=True, timeout=2)
    fields = result.stdout.strip().split(None, 6)
    if result.returncode or len(fields) != 7 or not fields[5].isdigit() or int(fields[5]) != pid:
        return None
    return result.stdout.strip()


def state_path(root, *, family='contrastive'):
    return Path(root) / '.state' / STATE_NAMES[family]


def capture_process(root, endpoint, argv, process, *, family='contrastive'):
    """Read identity only; a cancelled worker cannot register a late receipt."""
    fingerprint = process_fingerprint(process.pid)
    if not fingerprint or fingerprint.split(None, 6)[6] != ' '.join(argv):
        raise ValueError('The local decision process identity could not be verified.')
    return {'pid': process.pid, 'family': family, 'root': str(Path(root).resolve()),
            'endpoint': endpoint, 'model': MODELS[family], 'command': argv,
            'fingerprint': fingerprint, 'started_at_ns': time.time_ns()}


def record_state(root, state, *, family='contrastive'):
    atomic_json(state_path(root, family=family), state)


def owned_state(root, fingerprint_fn=None, *, family='contrastive'):
    """Health alone never proves ownership, including at a configured endpoint."""
    try:
        path = state_path(root, family=family)
        if path.is_symlink():
            return None
        saved = json.loads(path.read_text())
        pid, argv, endpoint = saved['pid'], saved['command'], saved['endpoint']
        if (type(pid) is not int or pid <= 0 or saved['family'] != family
                or saved['root'] != str(Path(root).resolve()) or saved['model'] != MODELS[family]
                or not isinstance(argv, list) or not argv or not all(isinstance(arg, str) for arg in argv)
                or not Path(argv[0]).is_absolute() or argv != command(root, endpoint, argv[0], family=family)):
            return None
        fingerprint = (fingerprint_fn or process_fingerprint)(pid)
        if (fingerprint == saved['fingerprint'] and fingerprint
                and fingerprint.split(None, 6)[6] == ' '.join(argv)):
            return saved
    except (OSError, ValueError, KeyError, TypeError, IndexError, subprocess.SubprocessError):
        pass
    return None


def launch_matches(saved, root, endpoint, *, family='contrastive'):
    try:
        if family == 'contrastive':
            expected = command(root, endpoint)
            argv = saved.get('command', [])
            return (host_port(saved['endpoint']) == host_port(endpoint) and len(argv) == len(expected)
                    and Path(argv[0]).resolve() == Path(expected[0]).resolve()
                    and Path(argv[3]).resolve() == Path(expected[3]).resolve()
                    and argv[1:3] == expected[1:3] and argv[4:] == expected[4:])
        return saved.get('endpoint') == endpoint and saved.get('command') == command(root, endpoint, family=family)
    except (ValueError, KeyError, TypeError, IndexError):
        return False


def listener_owner(endpoint):
    """Return one same-user PID actually listening at the exact loopback origin."""
    host, port = host_port(endpoint)
    address = f'[{host}]:{port}' if ':' in host else f'{host}:{port}'
    try:
        result = subprocess.run(['lsof', '-nP', '-a', f'-iTCP:{port}', '-sTCP:LISTEN', '-Fpun'],
                                capture_output=True, text=True, timeout=2)
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode:
        return None
    processes, current = [], None
    for line in result.stdout.splitlines():
        if line.startswith('p'):
            current = {'pid': line[1:], 'uid': None, 'names': []}
            processes.append(current)
        elif current is not None and line.startswith('u'):
            current['uid'] = line[1:]
        elif current is not None and line.startswith('n'):
            current['names'].append(line[1:])
    matches = [row for row in processes if address in row['names']]
    if (len(matches) != 1 or not matches[0]['pid'].isdigit() or int(matches[0]['pid']) <= 0
            or matches[0]['uid'] != str(os.getuid())):
        return None
    return int(matches[0]['pid'])


def _native_root_safe(root):
    state = Path(root) / '.state'
    return not state.is_symlink() and state.resolve().is_relative_to(Path(root).resolve())


def runtime_mapped(pid, executable):
    """Verify the native image is mapped by this PID, rather than trusting argv[0]."""
    try:
        result = subprocess.run(['lsof', '-nP', '-a', '-p', str(pid), '-d', 'txt', '-Fpn'],
                                capture_output=True, text=True, timeout=2)
        if result.returncode:
            return False
        current = None
        for line in result.stdout.splitlines():
            if line.startswith('p'):
                current = line[1:]
            elif current == str(pid) and line.startswith('n'):
                if Path(line[1:]).resolve() == Path(executable).resolve():
                    return True
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    return False


def _legacy_native_command(root, endpoint, fingerprint):
    """Recognize the shipped old recipe, allowing only equivalent logical paths."""
    try:
        actual = fingerprint.split(None, 6)[6]
        match = re.fullmatch(r'(.+) serve -m (.+) --host (127\.0\.0\.1|::1) -p ([0-9]+) --token-source none', actual)
        if not match:
            return None
        executable, model, host, port = match.groups()
        expected_host, expected_port = host_port(endpoint)
        runtime = Path(root) / '.runtime/decisions/mistralrs'
        model_dir = Path(root) / '.models/clm-v0.1-8b'
        if (not Path(executable).is_absolute() or not Path(model).is_absolute()
                or Path(model).name != 'clm-v0.1-8b' or Path(model).parent.name != '.models'
                or Path(model).parent.parent.resolve() != Path(root).resolve()
                or Path(executable).resolve() != runtime.resolve() or Path(model).resolve() != model_dir.resolve()
                or (host, int(port)) != (expected_host, expected_port)):
            return None
        return [executable, 'serve', '-m', model, '--host', host, '-p', port, '--token-source', 'none']
    except (ValueError, TypeError, IndexError, OSError):
        return None


def native_state(root, endpoint, fingerprint_fn=None):
    """Read proven native ownership across supported roots, without adoption writes."""
    from ai_lab.paths import known_model_roots
    from ai_lab.runtime import published_decisions_ready
    root = Path(root).resolve()
    candidates = list(dict.fromkeys(Path(candidate).resolve() for candidate in
                                   [root, *known_model_roots(root)] if _native_root_safe(candidate)))
    for candidate in candidates:
        saved = owned_state(candidate, fingerprint_fn)
        if saved and (candidate == root or host_port(saved['endpoint']) == host_port(endpoint)):
            return saved
    pid = listener_owner(endpoint)
    if pid is None:
        return None
    fingerprint = (fingerprint_fn or process_fingerprint)(pid)
    fields = fingerprint.split(None, 6) if isinstance(fingerprint, str) else []
    if len(fields) != 7 or fields[5] != str(pid):
        return None
    for candidate in candidates:
        # An invalid/replaced modern receipt must not be bypassed by legacy
        # recovery. Only a genuinely receiptless old launcher is recoverable.
        receipt = state_path(candidate)
        if receipt.exists() or receipt.is_symlink():
            continue
        argv = _legacy_native_command(candidate, endpoint, fingerprint)
        if argv and published_decisions_ready(candidate) and runtime_mapped(pid, argv[0]):
            # No capture timestamp: rereads must describe exactly the same
            # verified process before Stop compares immutable identities.
            return {'pid': pid, 'family': 'contrastive', 'root': str(candidate), 'endpoint': endpoint,
                    'model': MODEL, 'command': argv, 'fingerprint': fingerprint, 'recovered': True}
    return None


def forget_state(root, saved, *, family='contrastive'):
    path = state_path(root, family=family)
    try:
        if not path.is_symlink() and json.loads(path.read_text()) == saved:
            path.unlink()
    except (OSError, ValueError):
        pass
