---
name: ai-lab
description: Use AI Lab CLI for local model chat, typed decisions, watermark decoding, and advanced completion sessions with native token and tournament traces.
---
