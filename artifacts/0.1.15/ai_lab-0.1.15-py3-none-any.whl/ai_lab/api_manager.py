"""Informational connection inventory. No probes, provisioning or lifecycle calls."""
import importlib
from pathlib import Path
import os
import sys

from ai_lab.credentials import JEV_ENV_NAMES, jev_key
from ai_lab.paths import RESOURCES


def _sources():
    # Installed backend files retain their established top-level import names.
    # Unlike load_backend, this does not change DEEPSEEK_ROOT or prepare a workspace.
    added = [str(path) for path in (RESOURCES, RESOURCES / 'harness') if str(path) not in sys.path]
    sys.path[:0] = added
    try:
        return importlib.import_module('generation_models'), importlib.import_module('decisions')
    finally:
        for path in added:
            sys.path.remove(path)


def _setting(name, purpose, *, required=False, one_of=None):
    return {'name': name, 'purpose': purpose, 'required': required,
            'required_one_of': one_of, 'configured': bool(os.environ.get(name, '').strip())}


def connections(root):
    """Return safe public data from generation identities and DecisionRuntime settings.

    Secrets are consumed only to determine availability, never returned. Invalid
    decision overrides are withheld in full, including userinfo, paths and queries.
    Provider reachability is deliberately unknown; settings do not imply a running API.
    """
    generation, decisions = _sources()
    rows = []
    for backend in generation.GENERATION_BACKENDS:
        rows.append({'name': backend.family, 'label': backend.label, 'kind': 'generation',
                     'hosted': False, 'endpoint': backend.base_url, 'endpoint_valid': True,
                     'configured': True, 'environment': [], 'auth_required': False,
                     'auth_configured': False, 'reachability': 'not_checked',
                     'source': 'generation_models.GENERATION_BACKENDS'})
    # These names correspond to DecisionRuntime.__init__ and its *_headers methods.
    for name, label, default, url_env, auth_env in (
            ('contrastive', 'Native Contrastive CLM', decisions.LOCAL_URL,
             'AI_LAB_DECISIONS_URL', 'AI_LAB_DECISIONS_API_KEY'),
            ('clm-upstream', 'Upstream Contrastive CLM', decisions.UPSTREAM_URL,
             'AI_LAB_CLM_UPSTREAM_URL', 'AI_LAB_CLM_UPSTREAM_API_KEY'),
            ('laya', 'Laya', decisions.LAYA_URL, 'AI_LAB_LAYA_URL', 'AI_LAB_LAYA_API_KEY')):
        endpoint = os.environ.get(url_env, default).rstrip('/')
        try:
            parsed = decisions.DecisionRuntime.loopback(endpoint, url_env)
            if parsed.username is not None or parsed.password is not None:
                raise ValueError('Embedded authentication is not a public origin.')
            # Explicitly force port validation as DecisionRuntime.__init__ does.
            port = parsed.port
            host = f'[{parsed.hostname}]' if parsed.hostname == '::1' else parsed.hostname
            endpoint = f'http://{host}' + (f':{port}' if port is not None else '')
            valid = True
        except (ValueError, TypeError):
            endpoint, valid = None, False
        environment = [_setting(url_env, 'Loopback HTTP origin override'),
                       _setting(auth_env, 'Optional bearer authentication')]
        if name == 'contrastive':
            environment.append(_setting('AI_LAB_DECISIONS_MODEL', 'Optional decision model selection'))
        rows.append({'name': name, 'label': label, 'kind': 'decision', 'hosted': False,
                     'endpoint': endpoint, 'endpoint_valid': valid, 'configured': valid,
                     'environment': environment, 'auth_required': False,
                     'auth_configured': environment[1]['configured'], 'reachability': 'not_checked',
                     'source': 'decisions.DecisionRuntime'})
    environment = [_setting(name, 'Hosted Jev authentication (either name)', one_of=list(JEV_ENV_NAMES))
                   for name in JEV_ENV_NAMES]
    # Honor the established privately synced workspace key before launch env.
    configured = bool(jev_key(Path(root)))
    rows.append({'name': 'jev', 'label': 'Jev / TypeSafe', 'kind': 'decision', 'hosted': True,
                 'endpoint': decisions.JEV_URL, 'endpoint_valid': True, 'configured': configured,
                 'environment': environment, 'auth_required': True, 'auth_configured': configured,
                 'reachability': 'not_checked', 'source': 'decisions.JEV_URL; credentials.jev_key'})
    return {'informational': True, 'reachability': 'not_checked', 'connections': rows}


def describe(snapshot):
    blocks = []
    for row in snapshot['connections']:
        state = 'configured' if row['configured'] else 'not configured'
        lines = [f"{row['label']} · {row['kind']} · {'hosted' if row['hosted'] else 'local'} · {state}",
                 row['endpoint'] or 'Invalid URL override; expected a loopback HTTP origin.']
        if row['auth_required']:
            lines.append('Authentication required: either environment key or the privately synced workspace key.')
        for setting in row['environment']:
            requirement = ('environment authentication: one of these names required; not needed with a saved key'
                           if setting['required_one_of'] else 'optional')
            lines.append(f"  {setting['name']}: {'configured' if setting['configured'] else 'not set'} ({requirement})")
            lines.append(f"    {setting['purpose']}")
        if not row['environment']:
            lines.append('  Fixed generation endpoint; no URL/auth environment overrides.')
        blocks.append('\n'.join(lines))
    return '\n\n'.join(blocks)
