"""Provision the independent Node / ONNX Laya server in a user workspace."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request

from ai_lab.paths import RESOURCES
from ai_lab.service import atomic_json
from ai_lab.download_ui import copy_download, phase, run_dependency

PACKAGE_VERSION = '0.1.2'
MODEL_REVISION = '68f27dfe5a27a54fb2b1fefc432f43f972e90868'
NODE_VERSION = 'v22.23.3'
NODE_SHA256 = '23b25245dcfb9af7262f8ff142e9e2e0af025368117329e7a7458a51e5922f53'


def installation(root):
    return Path(root) / '.runtime/decisions/laya'


def resource_digest():
    digest = hashlib.sha256()
    for name in ('package.json', 'package-lock.json', 'server.mjs'):
        digest.update((RESOURCES / 'harness/laya' / name).read_bytes())
    return digest.hexdigest()


def node_path(root):
    managed = Path(root) / '.runtime/node/bin/node'
    return managed if managed.is_file() else Path(shutil.which('node') or '/nonexistent/node')


def installed(root):
    target = installation(root)
    try:
        manifest = json.loads((target / 'manifest.json').read_text())
        return (manifest.get('resources_sha256') == resource_digest()
                and manifest.get('model_revision') == MODEL_REVISION
                and node_path(root).is_file()
                and (target / 'node_modules/@receptron/laya/dist/index.js').is_file()
                and (target / 'server.mjs').is_file()
                and all((Path(root) / '.models/laya' / name).is_file() for name in (
                    'laya.onnx', 'laya.onnx.data', 'laya_config.json',
                    'tokenizer/tokenizer.json', 'tokenizer/tokenizer_config.json')))
    except (OSError, ValueError):
        return False


def ensure_node(root):
    node = node_path(root)
    if node.is_file():
        try:
            version = subprocess.check_output([str(node), '--version'], text=True).strip()
            if int(version.lstrip('v').split('.')[0]) >= 20:
                npm = node.parent / 'npm'
                if npm.is_file():
                    return node, npm
        except (OSError, ValueError, subprocess.CalledProcessError):
            pass
    if platform.system() != 'Darwin' or platform.machine() != 'arm64':
        raise ValueError('Laya needs Node.js 20+ with npm. Automatic Node setup supports Apple Silicon.')
    parent = Path(root) / '.runtime'
    parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.node-', dir=parent) as temporary:
        stage = Path(temporary)
        archive = stage / 'node.tar.gz'
        name = f'node-{NODE_VERSION}-darwin-arm64'
        with urllib.request.urlopen(f'https://nodejs.org/dist/{NODE_VERSION}/{name}.tar.gz', timeout=60) as response, archive.open('wb') as target:
            copy_download(response, target, f'Node.js {NODE_VERSION}')
        phase('Verifying the Node.js runtime')
        if hashlib.sha256(archive.read_bytes()).hexdigest() != NODE_SHA256:
            raise ValueError('Pinned Node.js archive checksum mismatch.')
        with tarfile.open(archive) as bundle:
            bundle.extractall(stage, filter='data')
        target = parent / 'node'
        if target.exists():
            shutil.rmtree(target)
        (stage / name).replace(target)
    return target / 'bin/node', target / 'bin/npm'


def setup(root):
    if installed(root):
        return
    node, npm = ensure_node(root)
    target = installation(root)
    target.mkdir(parents=True, exist_ok=True)
    for name in ('package.json', 'package-lock.json', 'server.mjs'):
        shutil.copy2(RESOURCES / 'harness/laya' / name, target / name)
    env = os.environ.copy()
    for key in ('TYPESAFE_API_KEY', 'JEV_API_KEY', 'AI_LAB_LAYA_API_KEY'):
        env.pop(key, None)
    env['PATH'] = str(node.parent) + os.pathsep + env.get('PATH', '')
    run_dependency([str(npm), 'ci', '--omit=dev', '--no-audit', '--no-fund',
                    '--cache', str(Path(root) / '.runtime/npm-cache')], root,
                   'Installing Laya server dependencies', cwd=target, env=env)
    run_dependency([str(node), '--input-type=module', '-e',
                    "await import('@receptron/laya');"], root,
                   'Checking the Laya server', cwd=target, env=env)
    atomic_json(target / 'manifest.json', {'package': '@receptron/laya', 'version': PACKAGE_VERSION,
                'model_revision': MODEL_REVISION, 'resources_sha256': resource_digest(),
                'node_version': subprocess.check_output([str(node), '--version'], text=True).strip()})


def server_command(root, port):
    return [str(node_path(root)), str(installation(root) / 'server.mjs'),
            '--model-dir', str(Path(root) / '.models/laya'), '--root', str(root), '--port', str(port)]
