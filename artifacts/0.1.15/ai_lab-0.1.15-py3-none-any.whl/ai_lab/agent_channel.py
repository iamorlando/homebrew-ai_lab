"""A private, bounded input channel owned by one live chat session."""
import asyncio
import json
import os
from pathlib import Path
import tempfile


MAX_FRAME = 65536


class AgentInputChannel:
    def __init__(self, session_id, submit, state):
        self.session_id, self.submit, self.state = session_id, submit, state
        self.path = None
        self._directory = None
        self._server = None
        self._clients = set()
        self._writers = set()
        self._active = None
        self._closed = False
        self._seen = set()

    async def start(self):
        self._directory = Path(tempfile.mkdtemp(prefix='ai-lab-agent-', dir='/private/tmp'))
        self._directory.chmod(0o700)
        self.path = self._directory / 'input.sock'
        try:
            self._server = await asyncio.start_unix_server(self._connected, path=self.path,
                                                          limit=MAX_FRAME)
            self.path.chmod(0o600)
        except BaseException:
            await self.aclose()
            raise
        return self.path

    def publish(self, state):
        if self._active is None:
            return
        request, queue = self._active
        if state == 'working':
            request['observed_working'] = True
        status = {'idle': 'settled', 'blocked': 'blocked', 'working': 'working'}.get(state)
        if status:
            if queue is not None:
                if queue.full():
                    queue.get_nowait()
                queue.put_nowait({**request, 'status': status})
        if state == 'idle':
            self._active = None

    async def _connected(self, reader, writer):
        task = asyncio.current_task()
        self._clients.add(task)
        self._writers.add(writer)
        accepted = False
        request = None

        async def send(value):
            writer.write((json.dumps(value, ensure_ascii=False) + '\n').encode())
            await asyncio.wait_for(writer.drain(), 5)

        try:
            if self._closed or len(self._clients) > 4:
                await send({'status': 'rejected', 'code': 'agent_busy'})
                return
            raw = await asyncio.wait_for(reader.readline(), 5)
            value = json.loads(raw)
            prompt, request_id = value.get('prompt'), value.get('request_id')
            if (value.get('session_id') != self.session_id or value.get('op') != 'submit'
                    or not isinstance(request_id, str) or not 1 <= len(request_id) <= 64
                    or not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 24000
                    or len(raw) > MAX_FRAME):
                await send({'status': 'rejected', 'code': 'agent_not_ready'})
                return
            if request_id in self._seen:
                await send({'status': 'rejected', 'code': 'request_already_seen'})
                return
            if self.state() != 'idle' or self._active is not None:
                await send({'status': 'rejected', 'code': 'agent_blocked' if self.state() == 'blocked' else 'agent_busy'})
                return
            # A bounded replay fence: never silently evict accepted request IDs.
            if len(self._seen) >= 4096:
                await send({'status': 'rejected', 'code': 'session_request_limit'})
                return
            request = {'session_id': self.session_id, 'request_id': request_id,
                       'submitted': True, 'observed_working': False}
            queue = asyncio.Queue(maxsize=64)
            self._active = request, queue
            if not await self.submit(prompt):
                self._active = None
                await send({'status': 'rejected', 'code': 'agent_busy'})
                return
            accepted = True
            self._seen.add(request_id)
            await send({**request, 'status': 'accepted'})
            if not value.get('wait', False):
                return
            while True:
                event = await asyncio.wait_for(queue.get(), 300)
                await send(event)
                if event['status'] in {'settled', 'blocked'}:
                    return
        except (ValueError, TypeError, AttributeError, asyncio.TimeoutError, ConnectionError, OSError):
            # A disconnected caller never retries or cancels an accepted UI turn.
            if not accepted:
                if self._active is not None and self._active[0] is request:
                    self._active = None
        finally:
            if accepted and self._active is not None and self._active[0] is request:
                self._active = request, None
            writer.close()
            try:
                await writer.wait_closed()
            except (ConnectionError, OSError):
                pass
            self._writers.discard(writer)
            self._clients.discard(task)

    async def aclose(self):
        if self._closed:
            return
        self._closed = True
        if self._server is not None:
            self._server.close()
        for writer in tuple(self._writers):
            writer.close()
        for task in tuple(self._clients):
            task.cancel()
        if self._clients:
            await asyncio.gather(*tuple(self._clients), return_exceptions=True)
        if self._server is not None:
            await self._server.wait_closed()
        if self.path is not None:
            self.path.unlink(missing_ok=True)
        if self._directory is not None:
            self._directory.rmdir()
