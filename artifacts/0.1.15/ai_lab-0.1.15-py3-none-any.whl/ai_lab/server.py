"""Daemon entry point. The Unix socket is accessible only to the current user."""
import asyncio
import argparse
import os

from ai_lab.client import Client, LabError, lock_file, socket_path
from ai_lab.paths import load_backend, root_path, state_path


def run(root):
    import uvicorn
    load_backend(root)
    from ai_lab.service import create_app
    state = state_path(root)
    path = socket_path(root)
    try:
        with lock_file(state / 'server.lock', blocking=False):
            try:
                Client(root).connect(start=False)
            except LabError:
                pass
            else:
                return
            path.unlink(missing_ok=True)
            os.umask(0o077)
            app = create_app(root)
            server = uvicorn.Server(uvicorn.Config(app, uds=str(path), log_level='warning'))
            @app.post('/api/lab/shutdown')
            async def shutdown():
                app.state.ai_lab.idle()
                asyncio.get_running_loop().call_later(.1, setattr, server, 'should_exit', True)
                return {'stopping': True}
            try:
                server.run()
            finally:
                path.unlink(missing_ok=True)
    except BlockingIOError:
        return


def main(argv=None):
    """Private helper entrypoint used by Client, never a public CLI command."""
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--root')
    args = parser.parse_args(argv)
    from ai_lab.setup import prepare
    root = root_path(args.root)
    prepare(root)
    run(root)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
