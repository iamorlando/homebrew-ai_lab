"""Private daemon discovery and a single machine-friendly HTTP transport."""
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import httpx

from ai_lab.paths import state_path


class LabError(Exception):
    def __init__(self, message, code='request_failed', status=None):
        super().__init__(message)
        self.code, self.status = code, status


def socket_path(root):
    path = state_path(root) / 'api.sock'
    if len(os.fsencode(path)) >= 100:
        suffix = hashlib.sha256(str(root).encode()).hexdigest()[:16]
        directory = Path('/tmp') / f'ai-lab-{os.getuid()}-{suffix}'
        directory.mkdir(mode=0o700, exist_ok=True)
        if directory.is_symlink() or directory.stat().st_uid != os.getuid():
            raise LabError('Unsafe socket directory ownership.', 'socket_directory')
        directory.chmod(0o700)
        path = directory / 'api.sock'
    return path


@contextmanager
def lock_file(path, blocking=True):
    with path.open('a') as stream:
        fcntl.flock(stream, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        try:
            yield
        finally:
            fcntl.flock(stream, fcntl.LOCK_UN)


class Client:
    def __init__(self, root, server=None):
        self.root = Path(root).resolve()
        self.server = server or os.environ.get('AI_LAB_SERVER')
        self.socket = None
        self.explicit_server = self.server
        self.connected = False
        self.reconnecting = False

    def http(self, timeout=35):
        transport = httpx.HTTPTransport(uds=str(self.socket)) if self.socket else None
        return httpx.Client(base_url=self.server or 'http://localhost', transport=transport, timeout=timeout, trust_env=False)

    def request(self, method, path, body=None, **kwargs):
        try:
            with self.http() as client:
                response = client.request(method, path, json=body, **kwargs)
            if response.is_error:
                try:
                    detail = response.json().get('detail', response.text)
                except ValueError:
                    detail = response.text
                raise LabError(str(detail), 'api_error', response.status_code)
            return response.json()
        except httpx.HTTPError as error:
            if method == 'GET' and self.connected and not self.reconnecting:
                # Reads are safe to retry after a service transition. Mutations are not.
                self.reconnecting = True
                try:
                    self.connected = False
                    self.server, self.socket = self.explicit_server, None
                    self.connect()
                    return self.request(method, path, body, **kwargs)
                finally:
                    self.reconnecting = False
            raise LabError(f'AI Lab service unavailable: {error}', 'service_unavailable') from error

    def health(self):
        # Startup polls before the private helper has bound its socket. Avoid
        # opening a transport for a path that cannot yet accept connections.
        if self.socket and not self.socket.exists():
            return None
        try:
            result = self.request('GET', '/api/lab/health')
            return result if result.get('application') == 'ai-lab' and result.get('api_version') == 1 and result.get('root') == str(self.root) else None
        except LabError:
            return None

    def connect(self, start=True):
        if self.server:
            if not self.server.startswith(('http://127.0.0.1:', 'http://localhost:')):
                raise LabError('AI_LAB_SERVER must be a loopback HTTP URL.', 'invalid_server')
            if not self.health():
                raise LabError('Server identity, workspace root, or API version does not match.', 'server_mismatch')
            self.connected = True
            return self
        # Prefer the website: its configuration and generation locks are authoritative.
        try:
            with httpx.Client(timeout=.6, trust_env=False) as probe:
                response = probe.get('http://127.0.0.1:8080/api/workspace')
                workspace = response.json() if response.status_code == 200 else {}
            if workspace.get('kind') == 'deepseek-comparison' and workspace.get('root') == str(self.root):
                self.server = 'http://127.0.0.1:8080'
                if not self.health():
                    raise LabError('Restart the website server to load AI Lab support, then retry.', 'website_needs_restart')
                self.connected = True
                return self
        except (httpx.HTTPError, ValueError):
            pass
        self.socket = socket_path(self.root)
        if self.health():
            self.connected = True
            return self
        if not start:
            raise LabError('AI Lab service is stopped.', 'service_stopped')
        state = state_path(self.root)
        with lock_file(state / 'start.lock'):
            if self.health():
                self.connected = True
                return self
            env = os.environ.copy()
            package_parent = str(Path(__file__).resolve().parent.parent)
            env['PYTHONPATH'] = package_parent + os.pathsep + env.get('PYTHONPATH', '')
            with (state / 'server.log').open('a') as log:
                process = subprocess.Popen([sys.executable, '-m', 'ai_lab.server', '--root', str(self.root)],
                    env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                if self.health():
                    self.connected = True
                    return self
                if process.poll() is not None:
                    try:
                        existing = Client(self.root, self.explicit_server).connect(start=False)
                    except LabError:
                        break
                    self.server, self.socket = existing.server, existing.socket
                    self.connected = True
                    return self
                time.sleep(.1)
        raise LabError(f'AI Lab could not start. See {state / "server.log"}.', 'startup_failed')

    def wait(self, session, timeout=1200, on_update=None):
        deadline, revision = time.monotonic() + timeout, -1
        while time.monotonic() < deadline:
            result = self.request('GET', f'/api/lab/sessions/{session}', params={'after': revision, 'timeout': min(10, max(0, deadline-time.monotonic()))})
            if result['revision'] != revision and on_update:
                on_update(result)
            revision = result['revision']
            if result['status'] != 'running':
                if result['status'] == 'error':
                    raise LabError(result['error'], 'generation_failed')
                return result
        raise LabError('Wait timed out; generation continues. Use ai-lab completion --session-action get --session ID, or use --session-action stop to cancel.', 'timeout')
