"""UI-independent generation callback contracts for Python clients."""
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

Message = dict[str, Any]


@dataclass
class TurnResult:
    assistant_text: str
    messages: list[Message] = field(default_factory=list)


@dataclass(frozen=True)
class TurnEvents:
    text: Callable[[str], None]
    status: Callable[[str], None]
    approve: Callable[[str], Awaitable[bool]]
    tool_choice: str | None = None


TurnCallback = Callable[[list[Message], TurnEvents], Awaitable[TurnResult]]
