#!/usr/bin/env python3
"""Generate a checksum-pinned tap formula from the exact built release archive."""
import argparse
import hashlib
from pathlib import Path
import re
from urllib.parse import urlparse


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('archive',type=Path)
    p.add_argument('--version',required=True)
    p.add_argument('--revision',type=int,default=0,help='Homebrew packaging revision (default: 0)')
    p.add_argument('--url',help='Published artifact URL; file:// is accepted for local install verification')
    p.add_argument('--output',type=Path,default=Path('dist/homebrew/ai_lab.rb'))
    args=p.parse_args()
    if not re.fullmatch(r'\d+\.\d+\.\d+(?:[a-zA-Z0-9.-]*)',args.version):
        p.error('Invalid version')
    if args.revision < 0:
        p.error('Revision must be nonnegative')
    url=args.url or f'https://github.com/iamorlando/homebrew-ai_lab/releases/download/ai_lab-v{args.version}/{args.archive.name}'
    if urlparse(url).scheme not in {'https','file'} or any(c in url for c in ('"','\n','\r','\\','#')):
        p.error('Use an HTTPS release URL or local file URL without Ruby metacharacters')
    template=Path(__file__).with_name('ai_lab.rb.in').read_text()
    digest=hashlib.sha256(args.archive.read_bytes()).hexdigest()
    rendered=template.replace('@URL@',url).replace('@VERSION@',args.version).replace('@SHA256@',digest)
    rendered=rendered.replace('@REVISION@',f'  revision {args.revision}' if args.revision else '')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(rendered)
    print(args.output)

if __name__=='__main__': main()
